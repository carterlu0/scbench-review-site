/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001
`resetall
`timescale 1ns / 1ps
`default_nettype none

/* Xilinx UltraScale PCIe interface adapter (Requester reQuest) */
module pcie_us_if_rq #
(
    parameter AXIS_PCIE_DATA_WIDTH = 256,
    parameter AXIS_PCIE_KEEP_WIDTH = AXIS_PCIE_DATA_WIDTH/32,
    parameter AXIS_PCIE_RQ_USER_WIDTH = AXIS_PCIE_DATA_WIDTH < 512 ? 60 : 137,
    parameter RQ_SEQ_NUM_WIDTH = AXIS_PCIE_RQ_USER_WIDTH == 60 ? 4 : 6,
    parameter TLP_DATA_WIDTH = AXIS_PCIE_DATA_WIDTH,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter TLP_SEG_COUNT = AXIS_PCIE_DATA_WIDTH < 512 ? 1 : 2,
    parameter TX_SEQ_NUM_COUNT = AXIS_PCIE_DATA_WIDTH < 512 ? 1 : 2,
    parameter TX_SEQ_NUM_WIDTH = RQ_SEQ_NUM_WIDTH-1
)
(
    input  wire                                          clk,
    input  wire                                          rst,
    output wire [AXIS_PCIE_DATA_WIDTH-1:0]               m_axis_rq_tdata,
    output wire [AXIS_PCIE_KEEP_WIDTH-1:0]               m_axis_rq_tkeep,
    output wire                                          m_axis_rq_tvalid,
    input  wire                                          m_axis_rq_tready,
    output wire                                          m_axis_rq_tlast,
    output wire [AXIS_PCIE_RQ_USER_WIDTH-1:0]            m_axis_rq_tuser,
    input  wire [RQ_SEQ_NUM_WIDTH-1:0]                   s_axis_rq_seq_num_0,
    input  wire                                          s_axis_rq_seq_num_valid_0,
    input  wire [RQ_SEQ_NUM_WIDTH-1:0]                   s_axis_rq_seq_num_1,
    input  wire                                          s_axis_rq_seq_num_valid_1,
    input  wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]        tx_rd_req_tlp_hdr,
    input  wire [TLP_SEG_COUNT*TX_SEQ_NUM_WIDTH-1:0]     tx_rd_req_tlp_seq,
    input  wire [TLP_SEG_COUNT-1:0]                      tx_rd_req_tlp_valid,
    input  wire [TLP_SEG_COUNT-1:0]                      tx_rd_req_tlp_sop,
    input  wire [TLP_SEG_COUNT-1:0]                      tx_rd_req_tlp_eop,
    output wire                                          tx_rd_req_tlp_ready,
    output wire [TX_SEQ_NUM_COUNT*TX_SEQ_NUM_WIDTH-1:0]  m_axis_rd_req_tx_seq_num,
    output wire [TX_SEQ_NUM_COUNT-1:0]                   m_axis_rd_req_tx_seq_num_valid,
    input  wire [TLP_DATA_WIDTH-1:0]                     tx_wr_req_tlp_data,
    input  wire [TLP_STRB_WIDTH-1:0]                     tx_wr_req_tlp_strb,
    input  wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]        tx_wr_req_tlp_hdr,
    input  wire [TLP_SEG_COUNT*TX_SEQ_NUM_WIDTH-1:0]     tx_wr_req_tlp_seq,
    input  wire [TLP_SEG_COUNT-1:0]                      tx_wr_req_tlp_valid,
    input  wire [TLP_SEG_COUNT-1:0]                      tx_wr_req_tlp_sop,
    input  wire [TLP_SEG_COUNT-1:0]                      tx_wr_req_tlp_eop,
    output wire                                          tx_wr_req_tlp_ready,
    output wire [TX_SEQ_NUM_COUNT*TX_SEQ_NUM_WIDTH-1:0]  m_axis_wr_req_tx_seq_num,
    output wire [TX_SEQ_NUM_COUNT-1:0]                   m_axis_wr_req_tx_seq_num_valid
);

localparam AXI_WORDS = AXIS_PCIE_DATA_WIDTH/32;
localparam SEG_WORDS = TLP_DATA_WIDTH/TLP_SEG_COUNT/32;
localparam SEG_STRB_WIDTH = TLP_STRB_WIDTH/TLP_SEG_COUNT;
localparam WORK_WIDTH = AXIS_PCIE_DATA_WIDTH < 128 ? 128 : AXIS_PCIE_DATA_WIDTH;

initial begin
    if (AXIS_PCIE_DATA_WIDTH != 64 && AXIS_PCIE_DATA_WIDTH != 128 &&
            AXIS_PCIE_DATA_WIDTH != 256 && AXIS_PCIE_DATA_WIDTH != 512) begin
        $error("Error: PCIe interface width must be 64, 128, 256, or 512 (instance %m)");
        $finish;
    end
    if (AXIS_PCIE_KEEP_WIDTH != AXI_WORDS || TLP_DATA_WIDTH != AXIS_PCIE_DATA_WIDTH ||
            TLP_STRB_WIDTH != AXI_WORDS || TLP_HDR_WIDTH != 128 ||
            TLP_SEG_COUNT < 1 || TLP_DATA_WIDTH % (TLP_SEG_COUNT*32) != 0) begin
        $error("Error: invalid segmented TLP configuration (instance %m)");
        $finish;
    end
    if ((AXIS_PCIE_DATA_WIDTH == 512 && AXIS_PCIE_RQ_USER_WIDTH != 137) ||
            (AXIS_PCIE_DATA_WIDTH < 512 && AXIS_PCIE_RQ_USER_WIDTH != 60 && AXIS_PCIE_RQ_USER_WIDTH != 62)) begin
        $error("Error: invalid RQ tuser width (instance %m)");
        $finish;
    end
    if ((AXIS_PCIE_RQ_USER_WIDTH == 60 && RQ_SEQ_NUM_WIDTH != 4) ||
            (AXIS_PCIE_RQ_USER_WIDTH != 60 && RQ_SEQ_NUM_WIDTH != 6) ||
            TX_SEQ_NUM_WIDTH != RQ_SEQ_NUM_WIDTH-1) begin
        $error("Error: invalid RQ sequence number width (instance %m)");
        $finish;
    end
end

localparam [3:0] REQ_MEM_READ = 4'b0000, REQ_MEM_WRITE = 4'b0001,
    REQ_IO_READ = 4'b0010, REQ_IO_WRITE = 4'b0011;

function [127:0] make_descriptor;
    input [127:0] h;
    input is_write;
    reg [127:0] d;
    begin
        d = 0;
        d[1:0] = h[107:106];
        d[63:2] = h[63:2];
        d[74:64] = h[105:96] != 0 ? h[105:96] : 11'd1024;
        if (h[124:120] == 5'h02) begin
            d[78:75] = is_write ? REQ_IO_WRITE : REQ_IO_READ;
        end else begin
            d[78:75] = is_write ? REQ_MEM_WRITE : REQ_MEM_READ;
        end
        d[79] = h[110];
        d[95:80] = h[95:80];
        d[103:96] = h[79:72];
        d[123:121] = h[118:116];
        d[126:124] = {h[114], h[109:108]};
        make_descriptor = d;
    end
endfunction

function [AXIS_PCIE_RQ_USER_WIDTH-1:0] make_user;
    input [127:0] h;
    input [RQ_SEQ_NUM_WIDTH-1:0] seq;
    reg [AXIS_PCIE_RQ_USER_WIDTH-1:0] u;
    begin
        u = 0;
        if (AXIS_PCIE_DATA_WIDTH == 512) begin
            u[3:0] = h[67:64];
            u[11:8] = h[71:68];
            u[19:16] = 0;
            u[66:61] = seq;
        end else begin
            u[3:0] = h[67:64];
            u[7:4] = h[71:68];
            u[10:8] = 0;
            u[27:24] = seq[3:0];
            if (AXIS_PCIE_RQ_USER_WIDTH == 62) begin
                u[61:60] = seq[5:4];
            end
        end
        make_user = u;
    end
endfunction

wire [TLP_SEG_COUNT*RQ_SEQ_NUM_WIDTH-1:0] rd_seq_int;
wire [TLP_SEG_COUNT*RQ_SEQ_NUM_WIDTH-1:0] wr_seq_int;
genvar sg;
generate
    for (sg = 0; sg < TLP_SEG_COUNT; sg = sg+1) begin : seq_expand
        assign rd_seq_int[sg*RQ_SEQ_NUM_WIDTH +: RQ_SEQ_NUM_WIDTH] =
            {1'b1, tx_rd_req_tlp_seq[sg*TX_SEQ_NUM_WIDTH +: TX_SEQ_NUM_WIDTH]};
        assign wr_seq_int[sg*RQ_SEQ_NUM_WIDTH +: RQ_SEQ_NUM_WIDTH] =
            {1'b0, tx_wr_req_tlp_seq[sg*TX_SEQ_NUM_WIDTH +: TX_SEQ_NUM_WIDTH]};
    end
endgenerate

assign m_axis_rd_req_tx_seq_num[0 +: TX_SEQ_NUM_WIDTH] = s_axis_rq_seq_num_0[TX_SEQ_NUM_WIDTH-1:0];
assign m_axis_rd_req_tx_seq_num_valid[0] = s_axis_rq_seq_num_valid_0 && s_axis_rq_seq_num_0[RQ_SEQ_NUM_WIDTH-1];
assign m_axis_wr_req_tx_seq_num[0 +: TX_SEQ_NUM_WIDTH] = s_axis_rq_seq_num_0[TX_SEQ_NUM_WIDTH-1:0];
assign m_axis_wr_req_tx_seq_num_valid[0] = s_axis_rq_seq_num_valid_0 && !s_axis_rq_seq_num_0[RQ_SEQ_NUM_WIDTH-1];
generate
    if (TX_SEQ_NUM_COUNT > 1) begin : seq_1
        assign m_axis_rd_req_tx_seq_num[TX_SEQ_NUM_WIDTH +: TX_SEQ_NUM_WIDTH] = s_axis_rq_seq_num_1[TX_SEQ_NUM_WIDTH-1:0];
        assign m_axis_rd_req_tx_seq_num_valid[1] = s_axis_rq_seq_num_valid_1 && s_axis_rq_seq_num_1[RQ_SEQ_NUM_WIDTH-1];
        assign m_axis_wr_req_tx_seq_num[TX_SEQ_NUM_WIDTH +: TX_SEQ_NUM_WIDTH] = s_axis_rq_seq_num_1[TX_SEQ_NUM_WIDTH-1:0];
        assign m_axis_wr_req_tx_seq_num_valid[1] = s_axis_rq_seq_num_valid_1 && !s_axis_rq_seq_num_1[RQ_SEQ_NUM_WIDTH-1];
    end
endgenerate

reg [31:0] accept_order_reg = 0;
reg [5:0] rd_sop_count, wr_sop_count;
integer order_i;
always @* begin
    rd_sop_count = 0;
    wr_sop_count = 0;
    for (order_i = 0; order_i < TLP_SEG_COUNT; order_i = order_i+1) begin
        if (tx_rd_req_tlp_ready && tx_rd_req_tlp_valid[order_i] && tx_rd_req_tlp_sop[order_i]) begin
            rd_sop_count = rd_sop_count+1'b1;
        end
        if (tx_wr_req_tlp_ready && tx_wr_req_tlp_valid[order_i] && tx_wr_req_tlp_sop[order_i]) begin
            wr_sop_count = wr_sop_count+1'b1;
        end
    end
end
always @(posedge clk) begin
    accept_order_reg <= accept_order_reg+rd_sop_count+wr_sop_count;
    if (rst) begin
        accept_order_reg <= 0;
    end
end

wire [SEG_WORDS*32-1:0] rd_ser_data, wr_ser_data;
wire [SEG_STRB_WIDTH-1:0] rd_ser_strb, wr_ser_strb;
wire [127:0] rd_ser_hdr, wr_ser_hdr;
wire [RQ_SEQ_NUM_WIDTH-1:0] rd_ser_seq, wr_ser_seq;
wire [31:0] rd_ser_order, wr_ser_order;
wire rd_ser_valid, wr_ser_valid, rd_ser_sop, wr_ser_sop, rd_ser_eop, wr_ser_eop;
reg ser_done_reg = 1'b0;
reg source_write_reg = 1'b0;
wire select_read_oldest = rd_ser_valid && (!wr_ser_valid || rd_ser_order <= wr_ser_order);
wire selected_write = ser_done_reg || packet_active_reg ? source_write_reg : !select_read_oldest;

pcie_us_if_rq_seg_fifo #(
    .TLP_DATA_WIDTH(TLP_DATA_WIDTH), .TLP_STRB_WIDTH(TLP_STRB_WIDTH),
    .TLP_SEG_COUNT(TLP_SEG_COUNT), .SEQ_NUM_WIDTH(RQ_SEQ_NUM_WIDTH)
) rd_seg_fifo_inst (
    .clk(clk), .rst(rst),
    .in_tlp_data({TLP_DATA_WIDTH{1'b0}}), .in_tlp_strb({TLP_STRB_WIDTH{1'b0}}),
    .in_tlp_hdr(tx_rd_req_tlp_hdr), .in_tlp_seq(rd_seq_int),
    .in_tlp_order(accept_order_reg),
    .in_tlp_valid(tx_rd_req_tlp_valid), .in_tlp_sop(tx_rd_req_tlp_sop),
    .in_tlp_eop(tx_rd_req_tlp_eop), .in_tlp_ready(tx_rd_req_tlp_ready),
    .out_tlp_data(rd_ser_data), .out_tlp_strb(rd_ser_strb), .out_tlp_hdr(rd_ser_hdr),
    .out_tlp_seq(rd_ser_seq), .out_tlp_order(rd_ser_order),
    .out_tlp_valid(rd_ser_valid), .out_tlp_sop(rd_ser_sop),
    .out_tlp_eop(rd_ser_eop), .out_tlp_ready(ser_done_reg && !source_write_reg)
);

pcie_us_if_rq_seg_fifo #(
    .TLP_DATA_WIDTH(TLP_DATA_WIDTH), .TLP_STRB_WIDTH(TLP_STRB_WIDTH),
    .TLP_SEG_COUNT(TLP_SEG_COUNT), .SEQ_NUM_WIDTH(RQ_SEQ_NUM_WIDTH)
) wr_seg_fifo_inst (
    .clk(clk), .rst(rst),
    .in_tlp_data(tx_wr_req_tlp_data), .in_tlp_strb(tx_wr_req_tlp_strb),
    .in_tlp_hdr(tx_wr_req_tlp_hdr), .in_tlp_seq(wr_seq_int),
    .in_tlp_order(accept_order_reg+rd_sop_count),
    .in_tlp_valid(tx_wr_req_tlp_valid), .in_tlp_sop(tx_wr_req_tlp_sop),
    .in_tlp_eop(tx_wr_req_tlp_eop), .in_tlp_ready(tx_wr_req_tlp_ready),
    .out_tlp_data(wr_ser_data), .out_tlp_strb(wr_ser_strb), .out_tlp_hdr(wr_ser_hdr),
    .out_tlp_seq(wr_ser_seq), .out_tlp_order(wr_ser_order),
    .out_tlp_valid(wr_ser_valid), .out_tlp_sop(wr_ser_sop),
    .out_tlp_eop(wr_ser_eop), .out_tlp_ready(ser_done_reg && source_write_reg)
);

wire [SEG_WORDS*32-1:0] sel_data = selected_write ? wr_ser_data : rd_ser_data;
wire [SEG_STRB_WIDTH-1:0] sel_strb = selected_write ? wr_ser_strb : rd_ser_strb;
wire [127:0] sel_hdr = selected_write ? wr_ser_hdr : rd_ser_hdr;
wire [RQ_SEQ_NUM_WIDTH-1:0] sel_seq = selected_write ? wr_ser_seq : rd_ser_seq;
wire sel_valid = selected_write ? wr_ser_valid : rd_ser_valid;
wire sel_eop = selected_write ? wr_ser_eop : rd_ser_eop;

reg [AXIS_PCIE_DATA_WIDTH-1:0] out_data_reg = 0;
reg [AXIS_PCIE_KEEP_WIDTH-1:0] out_keep_reg = 0;
reg out_valid_reg = 1'b0;
reg out_last_reg = 1'b0;
reg [AXIS_PCIE_RQ_USER_WIDTH-1:0] out_user_reg = 0;
assign m_axis_rq_tdata = out_data_reg;
assign m_axis_rq_tkeep = out_keep_reg;
assign m_axis_rq_tvalid = out_valid_reg;
assign m_axis_rq_tlast = out_last_reg;
assign m_axis_rq_tuser = out_user_reg;

reg [AXIS_PCIE_DATA_WIDTH-1:0] assembly_data_reg = 0;
reg [AXIS_PCIE_RQ_USER_WIDTH-1:0] packet_user_reg = 0;
integer assembly_count_reg = 0;
integer record_offset_reg = 0;
reg packet_active_reg = 1'b0;
reg packet_end_reg = 1'b0;
reg assembly_sop_reg = 1'b0;

reg [WORK_WIDTH-1:0] work_data;
reg [AXIS_PCIE_RQ_USER_WIDTH-1:0] work_user;
reg [AXIS_PCIE_RQ_USER_WIDTH-1:0] emit_user;
integer work_count;
integer work_offset;
integer record_words;
integer i;
reg work_sop;
reg record_done;
reg finish_packet;

always @(posedge clk) begin
    if (out_valid_reg && m_axis_rq_tready) begin
        out_valid_reg <= 1'b0;
        out_last_reg <= 1'b0;
    end

    if (ser_done_reg) begin
        ser_done_reg <= 1'b0;
        record_offset_reg <= 0;
    end

    if (((sel_valid && !ser_done_reg && !(packet_end_reg && assembly_count_reg > 0)) ||
            (packet_active_reg && assembly_count_reg > 0 &&
                (!sel_valid || ser_done_reg || packet_end_reg))) &&
            (!out_valid_reg || m_axis_rq_tready)) begin
        work_data = assembly_data_reg;
        work_user = packet_user_reg;
        work_count = assembly_count_reg;
        work_offset = ser_done_reg ? 0 : record_offset_reg;
        work_sop = assembly_sop_reg;
        record_done = 1'b0;
        record_words = 0;

        if (sel_valid && !ser_done_reg && !(packet_end_reg && assembly_count_reg > 0)) begin
            if (!packet_active_reg) begin
                work_data = 0;
                work_data[127:0] = make_descriptor(sel_hdr, selected_write);
                work_user = make_user(sel_hdr, sel_seq);
                work_count = 4;
                work_offset = 0;
                work_sop = 1'b1;
                source_write_reg <= selected_write;
                assembly_sop_reg <= 1'b1;
                packet_user_reg <= work_user;
            end

            for (i = 0; i < SEG_STRB_WIDTH; i = i+1) begin
                if (sel_strb[i]) begin
                    record_words = i+1;
                end
            end
            for (i = 0; i < SEG_WORDS; i = i+1) begin
                if (i >= work_offset && i < record_words && work_count < AXI_WORDS) begin
                    work_data[work_count*32 +: 32] = sel_data[i*32 +: 32];
                    work_count = work_count+1;
                    work_offset = i+1;
                end
            end
            record_done = work_offset >= record_words;
        end

        if (record_done && sel_eop) begin
            packet_end_reg <= 1'b1;
        end
        finish_packet = (packet_end_reg || (record_done && sel_eop)) && work_count <= AXI_WORDS;
        assembly_data_reg <= work_data;
        assembly_count_reg <= work_count;
        record_offset_reg <= work_offset;
        packet_active_reg <= 1'b1;
        if (record_done) begin
            ser_done_reg <= 1'b1;
        end

        if (finish_packet || work_count >= AXI_WORDS) begin
            emit_user = work_user;
            if (AXIS_PCIE_DATA_WIDTH == 512) begin
                emit_user[21:20] = work_sop ? 2'b01 : 2'b00;
                emit_user[23:22] = 0;
                emit_user[25:24] = 0;
                emit_user[27:26] = finish_packet ? 2'b01 : 2'b00;
                emit_user[31:28] = work_count-1;
                emit_user[35:32] = 0;
                emit_user[36] = 1'b0;
            end
            out_data_reg <= work_data;
            out_keep_reg <= work_count >= AXI_WORDS ? {AXIS_PCIE_KEEP_WIDTH{1'b1}} :
                ({AXIS_PCIE_KEEP_WIDTH{1'b1}} >> (AXIS_PCIE_KEEP_WIDTH-work_count));
            out_user_reg <= emit_user;
            out_valid_reg <= 1'b1;
            out_last_reg <= finish_packet;
            assembly_sop_reg <= 1'b0;
            if (work_count > AXI_WORDS) begin
                assembly_data_reg <= work_data >> AXIS_PCIE_DATA_WIDTH;
                assembly_count_reg <= work_count-AXI_WORDS;
                packet_active_reg <= 1'b1;
            end else begin
                assembly_data_reg <= 0;
                assembly_count_reg <= 0;
                packet_active_reg <= !finish_packet;
                if (finish_packet) begin
                    packet_end_reg <= 1'b0;
                end
            end
        end
    end

    if (rst) begin
        out_data_reg <= 0;
        out_keep_reg <= 0;
        out_valid_reg <= 1'b0;
        out_last_reg <= 1'b0;
        out_user_reg <= 0;
        assembly_data_reg <= 0;
        packet_user_reg <= 0;
        assembly_count_reg <= 0;
        record_offset_reg <= 0;
        packet_active_reg <= 1'b0;
        packet_end_reg <= 1'b0;
        assembly_sop_reg <= 1'b0;
        source_write_reg <= 1'b0;
        ser_done_reg <= 1'b0;
    end
end

endmodule

/* Per-segment buffering and SOP-ordered serialization for the RQ packer. */
module pcie_us_if_rq_seg_fifo #
(
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_SEG_COUNT = 1,
    parameter SEQ_NUM_WIDTH = 4,
    parameter DEPTH = 32
)
(
    input wire clk,
    input wire rst,
    input wire [TLP_DATA_WIDTH-1:0] in_tlp_data,
    input wire [TLP_STRB_WIDTH-1:0] in_tlp_strb,
    input wire [TLP_SEG_COUNT*128-1:0] in_tlp_hdr,
    input wire [TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0] in_tlp_seq,
    input wire [31:0] in_tlp_order,
    input wire [TLP_SEG_COUNT-1:0] in_tlp_valid,
    input wire [TLP_SEG_COUNT-1:0] in_tlp_sop,
    input wire [TLP_SEG_COUNT-1:0] in_tlp_eop,
    output wire in_tlp_ready,
    output wire [(TLP_DATA_WIDTH/TLP_SEG_COUNT)-1:0] out_tlp_data,
    output wire [(TLP_STRB_WIDTH/TLP_SEG_COUNT)-1:0] out_tlp_strb,
    output wire [127:0] out_tlp_hdr,
    output wire [SEQ_NUM_WIDTH-1:0] out_tlp_seq,
    output wire [31:0] out_tlp_order,
    output wire out_tlp_valid,
    output wire out_tlp_sop,
    output wire out_tlp_eop,
    input wire out_tlp_ready
);

localparam SEG_DATA_WIDTH = TLP_DATA_WIDTH/TLP_SEG_COUNT;
localparam SEG_STRB_WIDTH = TLP_STRB_WIDTH/TLP_SEG_COUNT;
localparam PTR_WIDTH = $clog2(DEPTH);
localparam COUNT_WIDTH = $clog2(DEPTH+1);
localparam CL_SEG = TLP_SEG_COUNT <= 1 ? 1 : $clog2(TLP_SEG_COUNT);
localparam TOKEN_DEPTH = 64;
localparam TOKEN_PTR_WIDTH = $clog2(TOKEN_DEPTH);
localparam TOKEN_COUNT_WIDTH = $clog2(TOKEN_DEPTH+1);

wire [TLP_SEG_COUNT-1:0] lane_ready;
reg [TLP_SEG_COUNT-1:0] lane_pop;
wire [TLP_DATA_WIDTH-1:0] lane_data;
wire [TLP_STRB_WIDTH-1:0] lane_strb;
wire [TLP_SEG_COUNT*128-1:0] lane_hdr;
wire [TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0] lane_seq;
wire [TLP_SEG_COUNT-1:0] lane_valid, lane_sop, lane_eop;

reg [CL_SEG-1:0] token_mem[TOKEN_DEPTH-1:0];
reg [31:0] order_mem[TOKEN_DEPTH-1:0];
reg [TOKEN_PTR_WIDTH-1:0] token_wr_ptr = 0, token_rd_ptr = 0;
reg [TOKEN_COUNT_WIDTH-1:0] token_count = 0;
integer token_push_count;
integer token_write_index;
integer ti;
always @* begin
    token_push_count = 0;
    for (ti = 0; ti < TLP_SEG_COUNT; ti = ti+1) begin
        if (in_tlp_valid[ti] && in_tlp_sop[ti]) begin
            token_push_count = token_push_count+1;
        end
    end
end
wire token_push = in_tlp_ready && token_push_count != 0;
wire token_pop = out_tlp_valid && out_tlp_ready && out_tlp_eop;
assign in_tlp_ready = !rst && &lane_ready && token_count <= TOKEN_DEPTH-TLP_SEG_COUNT;

always @(posedge clk) begin
    if (token_push) begin
        token_write_index = 0;
        for (ti = 0; ti < TLP_SEG_COUNT; ti = ti+1) begin
            if (in_tlp_valid[ti] && in_tlp_sop[ti]) begin
                token_mem[token_wr_ptr+token_write_index] <= ti;
                order_mem[token_wr_ptr+token_write_index] <= in_tlp_order+token_write_index;
                token_write_index = token_write_index+1;
            end
        end
        token_wr_ptr <= token_wr_ptr+token_push_count;
    end
    if (token_pop) begin
        token_rd_ptr <= token_rd_ptr+1'b1;
    end
    case ({token_push, token_pop})
        2'b10: token_count <= token_count+token_push_count;
        2'b01: token_count <= token_count-1'b1;
        2'b11: token_count <= token_count+token_push_count-1'b1;
        default: token_count <= token_count;
    endcase
    if (rst) begin
        token_wr_ptr <= 0;
        token_rd_ptr <= 0;
        token_count <= 0;
    end
end

genvar g;
generate
    for (g = 0; g < TLP_SEG_COUNT; g = g+1) begin : lanes
        reg [SEG_DATA_WIDTH-1:0] data_mem[DEPTH-1:0];
        reg [SEG_STRB_WIDTH-1:0] strb_mem[DEPTH-1:0];
        reg [127:0] hdr_mem[DEPTH-1:0];
        reg [SEQ_NUM_WIDTH-1:0] seq_mem[DEPTH-1:0];
        reg sop_mem[DEPTH-1:0];
        reg eop_mem[DEPTH-1:0];
        reg [PTR_WIDTH-1:0] wr_ptr = 0, rd_ptr = 0;
        reg [COUNT_WIDTH-1:0] count = 0;
        wire push = in_tlp_ready && in_tlp_valid[g];
        wire pop = lane_pop[g] && count != 0;
        assign lane_ready[g] = count < DEPTH;
        assign lane_data[g*SEG_DATA_WIDTH +: SEG_DATA_WIDTH] = data_mem[rd_ptr];
        assign lane_strb[g*SEG_STRB_WIDTH +: SEG_STRB_WIDTH] = strb_mem[rd_ptr];
        assign lane_hdr[g*128 +: 128] = hdr_mem[rd_ptr];
        assign lane_seq[g*SEQ_NUM_WIDTH +: SEQ_NUM_WIDTH] = seq_mem[rd_ptr];
        assign lane_valid[g] = count != 0;
        assign lane_sop[g] = sop_mem[rd_ptr];
        assign lane_eop[g] = eop_mem[rd_ptr];
        always @(posedge clk) begin
            if (push) begin
                data_mem[wr_ptr] <= in_tlp_data[g*SEG_DATA_WIDTH +: SEG_DATA_WIDTH];
                strb_mem[wr_ptr] <= in_tlp_strb[g*SEG_STRB_WIDTH +: SEG_STRB_WIDTH];
                hdr_mem[wr_ptr] <= in_tlp_hdr[g*128 +: 128];
                seq_mem[wr_ptr] <= in_tlp_seq[g*SEQ_NUM_WIDTH +: SEQ_NUM_WIDTH];
                sop_mem[wr_ptr] <= in_tlp_sop[g];
                eop_mem[wr_ptr] <= in_tlp_eop[g];
                wr_ptr <= wr_ptr+1'b1;
            end
            if (pop) begin
                rd_ptr <= rd_ptr+1'b1;
            end
            case ({push, pop})
                2'b10: count <= count+1'b1;
                2'b01: count <= count-1'b1;
                default: count <= count;
            endcase
            if (rst) begin
                wr_ptr <= 0;
                rd_ptr <= 0;
                count <= 0;
            end
        end
    end
endgenerate

reg active_reg = 1'b0;
reg [CL_SEG-1:0] active_lane_reg = 0;
wire [CL_SEG-1:0] current_lane = active_reg ? active_lane_reg : token_mem[token_rd_ptr];
wire current_lane_valid = active_reg || token_count != 0;
assign out_tlp_data = lane_data[current_lane*SEG_DATA_WIDTH +: SEG_DATA_WIDTH];
assign out_tlp_strb = lane_strb[current_lane*SEG_STRB_WIDTH +: SEG_STRB_WIDTH];
assign out_tlp_hdr = lane_hdr[current_lane*128 +: 128];
assign out_tlp_seq = lane_seq[current_lane*SEQ_NUM_WIDTH +: SEQ_NUM_WIDTH];
assign out_tlp_order = order_mem[token_rd_ptr];
assign out_tlp_valid = current_lane_valid && lane_valid[current_lane];
assign out_tlp_sop = lane_sop[current_lane];
assign out_tlp_eop = lane_eop[current_lane];
always @* begin
    lane_pop = 0;
    if (out_tlp_valid && out_tlp_ready) begin
        lane_pop[current_lane] = 1'b1;
    end
end
always @(posedge clk) begin
    if (out_tlp_valid && out_tlp_ready) begin
        if (out_tlp_eop) begin
            active_reg <= 1'b0;
        end else begin
            active_reg <= 1'b1;
            active_lane_reg <= current_lane;
        end
    end
    if (rst) begin
        active_reg <= 1'b0;
        active_lane_reg <= 0;
    end
end

endmodule
`resetall
