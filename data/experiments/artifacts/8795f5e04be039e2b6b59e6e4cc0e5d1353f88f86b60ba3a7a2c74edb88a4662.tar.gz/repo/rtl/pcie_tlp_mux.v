/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * PCIe TLP multiplexer
 *
 * Arbitration is performed once per group of segmented packets.  The grant
 * is held until every active segment has transferred its EOP, so segments
 * from different input ports can never be interleaved.
 */
module pcie_tlp_mux #
(
    parameter PORTS = 2,
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter SEQ_NUM_WIDTH = 6,
    parameter TLP_SEG_COUNT = 1,
    parameter ARB_TYPE_ROUND_ROBIN = 0,
    parameter ARB_LSB_HIGH_PRIORITY = 1
)
(
    input  wire                                          clk,
    input  wire                                          rst,

    input  wire [PORTS*TLP_DATA_WIDTH-1:0]               in_tlp_data,
    input  wire [PORTS*TLP_STRB_WIDTH-1:0]               in_tlp_strb,
    input  wire [PORTS*TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]  in_tlp_hdr,
    input  wire [PORTS*TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]  in_tlp_seq,
    input  wire [PORTS*TLP_SEG_COUNT*3-1:0]              in_tlp_bar_id,
    input  wire [PORTS*TLP_SEG_COUNT*8-1:0]              in_tlp_func_num,
    input  wire [PORTS*TLP_SEG_COUNT*4-1:0]              in_tlp_error,
    input  wire [PORTS*TLP_SEG_COUNT-1:0]                in_tlp_valid,
    input  wire [PORTS*TLP_SEG_COUNT-1:0]                in_tlp_sop,
    input  wire [PORTS*TLP_SEG_COUNT-1:0]                in_tlp_eop,
    output wire [PORTS-1:0]                              in_tlp_ready,

    output wire [TLP_DATA_WIDTH-1:0]                     out_tlp_data,
    output wire [TLP_STRB_WIDTH-1:0]                     out_tlp_strb,
    output wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]        out_tlp_hdr,
    output wire [TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]        out_tlp_seq,
    output wire [TLP_SEG_COUNT*3-1:0]                    out_tlp_bar_id,
    output wire [TLP_SEG_COUNT*8-1:0]                    out_tlp_func_num,
    output wire [TLP_SEG_COUNT*4-1:0]                    out_tlp_error,
    output wire [TLP_SEG_COUNT-1:0]                      out_tlp_valid,
    output wire [TLP_SEG_COUNT-1:0]                      out_tlp_sop,
    output wire [TLP_SEG_COUNT-1:0]                      out_tlp_eop,
    input  wire                                          out_tlp_ready,

    output wire [PORTS*TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]  sel_tlp_seq,
    output wire [PORTS*TLP_SEG_COUNT-1:0]                sel_tlp_seq_valid
);

localparam CL_PORTS = PORTS <= 1 ? 1 : $clog2(PORTS);

initial begin
    if (PORTS < 1 || TLP_SEG_COUNT < 1) begin
        $error("Error: PORTS and TLP_SEG_COUNT must be positive (instance %m)");
        $finish;
    end
    if (TLP_STRB_WIDTH*32 != TLP_DATA_WIDTH ||
            TLP_DATA_WIDTH % TLP_SEG_COUNT != 0 ||
            (TLP_DATA_WIDTH/TLP_SEG_COUNT) % 32 != 0) begin
        $error("Error: each segment must contain an integral number of dwords (instance %m)");
        $finish;
    end
end

reg grant_valid_reg = 1'b0;
reg [CL_PORTS-1:0] grant_reg = 0;
reg [CL_PORTS-1:0] last_grant_reg = 0;
reg [TLP_SEG_COUNT-1:0] active_seg_reg = 0;

reg grant_valid_cmb;
reg [CL_PORTS-1:0] grant_cmb;
integer i;
integer index;

always @* begin
    grant_valid_cmb = 1'b0;
    grant_cmb = 0;

    if (ARB_TYPE_ROUND_ROBIN) begin
        for (i = 0; i < PORTS; i = i+1) begin
            index = last_grant_reg+i+1;
            if (index >= PORTS) begin
                index = index-PORTS;
            end
            if (!grant_valid_cmb && in_tlp_valid[index*TLP_SEG_COUNT +: TLP_SEG_COUNT] != 0) begin
                grant_valid_cmb = 1'b1;
                grant_cmb = index;
            end
        end
    end else if (ARB_LSB_HIGH_PRIORITY) begin
        for (i = PORTS-1; i >= 0; i = i-1) begin
            if (in_tlp_valid[i*TLP_SEG_COUNT +: TLP_SEG_COUNT] != 0) begin
                grant_valid_cmb = 1'b1;
                grant_cmb = i;
            end
        end
    end else begin
        for (i = 0; i < PORTS; i = i+1) begin
            if (in_tlp_valid[i*TLP_SEG_COUNT +: TLP_SEG_COUNT] != 0) begin
                grant_valid_cmb = 1'b1;
                grant_cmb = i;
            end
        end
    end
end

wire transfer = grant_valid_reg && out_tlp_ready &&
    (in_tlp_valid[grant_reg*TLP_SEG_COUNT +: TLP_SEG_COUNT] != 0);
wire [TLP_SEG_COUNT-1:0] current_valid = in_tlp_valid[grant_reg*TLP_SEG_COUNT +: TLP_SEG_COUNT];
wire [TLP_SEG_COUNT-1:0] current_eop = in_tlp_eop[grant_reg*TLP_SEG_COUNT +: TLP_SEG_COUNT];
wire [TLP_SEG_COUNT-1:0] active_seg_next = (active_seg_reg | current_valid) & ~(current_valid & current_eop);

always @(posedge clk) begin
    if (!grant_valid_reg && grant_valid_cmb) begin
        grant_valid_reg <= 1'b1;
        grant_reg <= grant_cmb;
        active_seg_reg <= 0;
    end else if (transfer) begin
        active_seg_reg <= active_seg_next;
        if (active_seg_next == 0) begin
            grant_valid_reg <= 1'b0;
            last_grant_reg <= grant_reg;
        end
    end

    if (rst) begin
        grant_valid_reg <= 1'b0;
        grant_reg <= 0;
        last_grant_reg <= 0;
        active_seg_reg <= 0;
    end
end

assign in_tlp_ready = grant_valid_reg && out_tlp_ready ? ({{PORTS-1{1'b0}}, 1'b1} << grant_reg) : {PORTS{1'b0}};

assign out_tlp_data = in_tlp_data[grant_reg*TLP_DATA_WIDTH +: TLP_DATA_WIDTH];
assign out_tlp_strb = in_tlp_strb[grant_reg*TLP_STRB_WIDTH +: TLP_STRB_WIDTH];
assign out_tlp_hdr = in_tlp_hdr[grant_reg*TLP_SEG_COUNT*TLP_HDR_WIDTH +: TLP_SEG_COUNT*TLP_HDR_WIDTH];
assign out_tlp_seq = in_tlp_seq[grant_reg*TLP_SEG_COUNT*SEQ_NUM_WIDTH +: TLP_SEG_COUNT*SEQ_NUM_WIDTH];
assign out_tlp_bar_id = in_tlp_bar_id[grant_reg*TLP_SEG_COUNT*3 +: TLP_SEG_COUNT*3];
assign out_tlp_func_num = in_tlp_func_num[grant_reg*TLP_SEG_COUNT*8 +: TLP_SEG_COUNT*8];
assign out_tlp_error = in_tlp_error[grant_reg*TLP_SEG_COUNT*4 +: TLP_SEG_COUNT*4];
assign out_tlp_valid = grant_valid_reg ? current_valid : {TLP_SEG_COUNT{1'b0}};
assign out_tlp_sop = in_tlp_sop[grant_reg*TLP_SEG_COUNT +: TLP_SEG_COUNT];
assign out_tlp_eop = current_eop;

genvar p;
generate
    for (p = 0; p < PORTS; p = p+1) begin : sequence_outputs
        assign sel_tlp_seq[p*TLP_SEG_COUNT*SEQ_NUM_WIDTH +: TLP_SEG_COUNT*SEQ_NUM_WIDTH] = out_tlp_seq;
        assign sel_tlp_seq_valid[p*TLP_SEG_COUNT +: TLP_SEG_COUNT] =
            (out_tlp_valid & out_tlp_sop) & {TLP_SEG_COUNT{grant_valid_reg && grant_reg == p}};
    end
endgenerate

endmodule

`resetall
