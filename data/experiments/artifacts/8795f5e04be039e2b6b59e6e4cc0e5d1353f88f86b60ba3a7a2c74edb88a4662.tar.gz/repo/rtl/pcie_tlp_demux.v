/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/* PCIe TLP demultiplexer */
module pcie_tlp_demux #
(
    parameter PORTS = 2,
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter SEQ_NUM_WIDTH = 6,
    parameter IN_TLP_SEG_COUNT = 1,
    parameter OUT_TLP_SEG_COUNT = IN_TLP_SEG_COUNT,
    parameter FIFO_ENABLE = 0,
    parameter FIFO_DEPTH = 4096,
    parameter FIFO_WATERMARK = FIFO_DEPTH/2
)
(
    input  wire                                               clk,
    input  wire                                               rst,

    input  wire [TLP_DATA_WIDTH-1:0]                          in_tlp_data,
    input  wire [TLP_STRB_WIDTH-1:0]                          in_tlp_strb,
    input  wire [IN_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]          in_tlp_hdr,
    input  wire [IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]          in_tlp_seq,
    input  wire [IN_TLP_SEG_COUNT*3-1:0]                      in_tlp_bar_id,
    input  wire [IN_TLP_SEG_COUNT*8-1:0]                      in_tlp_func_num,
    input  wire [IN_TLP_SEG_COUNT*4-1:0]                      in_tlp_error,
    input  wire [IN_TLP_SEG_COUNT-1:0]                        in_tlp_valid,
    input  wire [IN_TLP_SEG_COUNT-1:0]                        in_tlp_sop,
    input  wire [IN_TLP_SEG_COUNT-1:0]                        in_tlp_eop,
    output wire                                               in_tlp_ready,

    output wire [PORTS*TLP_DATA_WIDTH-1:0]                    out_tlp_data,
    output wire [PORTS*TLP_STRB_WIDTH-1:0]                    out_tlp_strb,
    output wire [PORTS*OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]   out_tlp_hdr,
    output wire [PORTS*OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]   out_tlp_seq,
    output wire [PORTS*OUT_TLP_SEG_COUNT*3-1:0]               out_tlp_bar_id,
    output wire [PORTS*OUT_TLP_SEG_COUNT*8-1:0]               out_tlp_func_num,
    output wire [PORTS*OUT_TLP_SEG_COUNT*4-1:0]               out_tlp_error,
    output wire [PORTS*OUT_TLP_SEG_COUNT-1:0]                 out_tlp_valid,
    output wire [PORTS*OUT_TLP_SEG_COUNT-1:0]                 out_tlp_sop,
    output wire [PORTS*OUT_TLP_SEG_COUNT-1:0]                 out_tlp_eop,
    input  wire [PORTS-1:0]                                   out_tlp_ready,

    output wire [IN_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]          match_tlp_hdr,
    output wire [IN_TLP_SEG_COUNT*3-1:0]                      match_tlp_bar_id,
    output wire [IN_TLP_SEG_COUNT*8-1:0]                      match_tlp_func_num,

    input  wire                                               enable,
    input  wire [IN_TLP_SEG_COUNT-1:0]                        drop,
    input  wire [PORTS*IN_TLP_SEG_COUNT-1:0]                  select,
    output wire [PORTS-1:0]                                   fifo_half_full,
    output wire [PORTS-1:0]                                   fifo_watermark
);

localparam COUNT_WIDTH = $clog2(FIFO_DEPTH+1);

initial begin
    if (PORTS < 1 || IN_TLP_SEG_COUNT < 1 || OUT_TLP_SEG_COUNT < 1) begin
        $error("Error: port and segment counts must be positive (instance %m)");
        $finish;
    end
    if (FIFO_DEPTH < 2) begin
        $error("Error: FIFO_DEPTH must be at least two (instance %m)");
        $finish;
    end
end

assign match_tlp_hdr = in_tlp_hdr;
assign match_tlp_bar_id = in_tlp_bar_id;
assign match_tlp_func_num = in_tlp_func_num;

reg [IN_TLP_SEG_COUNT-1:0] route_active_reg = 0;
reg [PORTS*IN_TLP_SEG_COUNT-1:0] route_select_reg = 0;
reg [IN_TLP_SEG_COUNT-1:0] route_drop_reg = 0;

wire [PORTS*IN_TLP_SEG_COUNT-1:0] route_select;
wire [IN_TLP_SEG_COUNT-1:0] route_drop;
wire [PORTS-1:0] port_in_ready;
wire all_ports_ready;

genvar s, p;
generate
    for (s = 0; s < IN_TLP_SEG_COUNT; s = s+1) begin : routing
        assign route_select[s*PORTS +: PORTS] = route_active_reg[s] ?
            route_select_reg[s*PORTS +: PORTS] : select[s*PORTS +: PORTS];
        assign route_drop[s] = route_active_reg[s] ? route_drop_reg[s] :
            (drop[s] || select[s*PORTS +: PORTS] == 0);
    end
endgenerate

reg ready_cmb;
integer rs, rp;
always @* begin
    ready_cmb = enable && !rst;
    for (rs = 0; rs < IN_TLP_SEG_COUNT; rs = rs+1) begin
        if (in_tlp_valid[rs] && !route_drop[rs]) begin
            for (rp = 0; rp < PORTS; rp = rp+1) begin
                if (route_select[rs*PORTS+rp] && !port_in_ready[rp]) begin
                    ready_cmb = 1'b0;
                end
            end
        end
    end
end
assign in_tlp_ready = ready_cmb;
assign all_ports_ready = ready_cmb;

integer s2;
always @(posedge clk) begin
    for (s2 = 0; s2 < IN_TLP_SEG_COUNT; s2 = s2+1) begin
        if (in_tlp_valid[s2] && in_tlp_ready) begin
            if (in_tlp_sop[s2] && !in_tlp_eop[s2]) begin
                route_active_reg[s2] <= 1'b1;
                route_select_reg[s2*PORTS +: PORTS] <= select[s2*PORTS +: PORTS];
                route_drop_reg[s2] <= drop[s2] || select[s2*PORTS +: PORTS] == 0;
            end else if (in_tlp_eop[s2]) begin
                route_active_reg[s2] <= 1'b0;
                route_drop_reg[s2] <= 1'b0;
            end
        end
    end
    if (rst) begin
        route_active_reg <= 0;
        route_select_reg <= 0;
        route_drop_reg <= 0;
    end
end

wire [PORTS*IN_TLP_SEG_COUNT-1:0] port_in_valid;
wire [PORTS*TLP_DATA_WIDTH-1:0] port_out_data;
wire [PORTS*TLP_STRB_WIDTH-1:0] port_out_strb;
assign out_tlp_data = port_out_data;
assign out_tlp_strb = port_out_strb;
generate
    for (p = 0; p < PORTS; p = p+1) begin : outputs
        for (s = 0; s < IN_TLP_SEG_COUNT; s = s+1) begin : valid_mapping
            assign port_in_valid[p*IN_TLP_SEG_COUNT+s] = enable && all_ports_ready &&
                in_tlp_valid[s] && route_select[s*PORTS+p] && !route_drop[s];
        end

        if (FIFO_ENABLE || IN_TLP_SEG_COUNT != OUT_TLP_SEG_COUNT) begin : buffered
            wire [COUNT_WIDTH-1:0] count;
            pcie_tlp_fifo #(
                .DEPTH(FIFO_DEPTH),
                .TLP_DATA_WIDTH(TLP_DATA_WIDTH),
                .TLP_STRB_WIDTH(TLP_STRB_WIDTH),
                .TLP_HDR_WIDTH(TLP_HDR_WIDTH),
                .SEQ_NUM_WIDTH(SEQ_NUM_WIDTH),
                .IN_TLP_SEG_COUNT(IN_TLP_SEG_COUNT),
                .OUT_TLP_SEG_COUNT(OUT_TLP_SEG_COUNT)
            ) fifo_inst (
                .clk(clk), .rst(rst),
                .in_tlp_data(in_tlp_data), .in_tlp_strb(in_tlp_strb),
                .in_tlp_hdr(in_tlp_hdr), .in_tlp_seq(in_tlp_seq),
                .in_tlp_bar_id(in_tlp_bar_id), .in_tlp_func_num(in_tlp_func_num),
                .in_tlp_error(in_tlp_error),
                .in_tlp_valid(port_in_valid[p*IN_TLP_SEG_COUNT +: IN_TLP_SEG_COUNT]),
                .in_tlp_sop(in_tlp_sop), .in_tlp_eop(in_tlp_eop),
                .in_tlp_ready(port_in_ready[p]),
                .out_tlp_data(port_out_data[p*TLP_DATA_WIDTH +: TLP_DATA_WIDTH]),
                .out_tlp_strb(port_out_strb[p*TLP_STRB_WIDTH +: TLP_STRB_WIDTH]),
                .out_tlp_hdr(out_tlp_hdr[p*OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH +: OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH]),
                .out_tlp_seq(out_tlp_seq[p*OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH +: OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH]),
                .out_tlp_bar_id(out_tlp_bar_id[p*OUT_TLP_SEG_COUNT*3 +: OUT_TLP_SEG_COUNT*3]),
                .out_tlp_func_num(out_tlp_func_num[p*OUT_TLP_SEG_COUNT*8 +: OUT_TLP_SEG_COUNT*8]),
                .out_tlp_error(out_tlp_error[p*OUT_TLP_SEG_COUNT*4 +: OUT_TLP_SEG_COUNT*4]),
                .out_tlp_valid(out_tlp_valid[p*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT]),
                .out_tlp_sop(out_tlp_sop[p*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT]),
                .out_tlp_eop(out_tlp_eop[p*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT]),
                .out_tlp_ready(out_tlp_ready[p]), .status_count(count)
            );
            assign fifo_half_full[p] = count >= FIFO_DEPTH/2;
            assign fifo_watermark[p] = FIFO_WATERMARK > 0 && count >= FIFO_WATERMARK;
        end else begin : direct
            assign port_in_ready[p] = out_tlp_ready[p];
            assign port_out_data[p*TLP_DATA_WIDTH +: TLP_DATA_WIDTH] = in_tlp_data;
            assign port_out_strb[p*TLP_STRB_WIDTH +: TLP_STRB_WIDTH] = in_tlp_strb;
            assign out_tlp_hdr[p*OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH +: OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH] = in_tlp_hdr;
            assign out_tlp_seq[p*OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH +: OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH] = in_tlp_seq;
            assign out_tlp_bar_id[p*OUT_TLP_SEG_COUNT*3 +: OUT_TLP_SEG_COUNT*3] = in_tlp_bar_id;
            assign out_tlp_func_num[p*OUT_TLP_SEG_COUNT*8 +: OUT_TLP_SEG_COUNT*8] = in_tlp_func_num;
            assign out_tlp_error[p*OUT_TLP_SEG_COUNT*4 +: OUT_TLP_SEG_COUNT*4] = in_tlp_error;
            assign out_tlp_valid[p*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT] = port_in_valid[p*IN_TLP_SEG_COUNT +: IN_TLP_SEG_COUNT];
            assign out_tlp_sop[p*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT] = in_tlp_sop;
            assign out_tlp_eop[p*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT] = in_tlp_eop;
            assign fifo_half_full[p] = 1'b0;
            assign fifo_watermark[p] = 1'b0;
        end
    end
endgenerate

endmodule

`resetall
