/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001
`resetall
`timescale 1ns / 1ps
`default_nettype none

/* Xilinx UltraScale PCIe interface adapter (Requester Completion) */
module pcie_us_if_rc #
(
    parameter AXIS_PCIE_DATA_WIDTH = 256,
    parameter AXIS_PCIE_KEEP_WIDTH = AXIS_PCIE_DATA_WIDTH/32,
    parameter AXIS_PCIE_RC_USER_WIDTH = AXIS_PCIE_DATA_WIDTH < 512 ? 75 : 161,
    parameter TLP_DATA_WIDTH = AXIS_PCIE_DATA_WIDTH,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter TLP_SEG_COUNT = AXIS_PCIE_DATA_WIDTH < 512 ? 1 : 2
)
(
    input  wire                                    clk,
    input  wire                                    rst,
    input  wire [AXIS_PCIE_DATA_WIDTH-1:0]         s_axis_rc_tdata,
    input  wire [AXIS_PCIE_KEEP_WIDTH-1:0]         s_axis_rc_tkeep,
    input  wire                                    s_axis_rc_tvalid,
    output wire                                    s_axis_rc_tready,
    input  wire                                    s_axis_rc_tlast,
    input  wire [AXIS_PCIE_RC_USER_WIDTH-1:0]      s_axis_rc_tuser,
    output wire [TLP_DATA_WIDTH-1:0]               rx_cpl_tlp_data,
    output wire [TLP_STRB_WIDTH-1:0]               rx_cpl_tlp_strb,
    output wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]  rx_cpl_tlp_hdr,
    output wire [TLP_SEG_COUNT*4-1:0]              rx_cpl_tlp_error,
    output wire [TLP_SEG_COUNT-1:0]                rx_cpl_tlp_valid,
    output wire [TLP_SEG_COUNT-1:0]                rx_cpl_tlp_sop,
    output wire [TLP_SEG_COUNT-1:0]                rx_cpl_tlp_eop,
    input  wire                                    rx_cpl_tlp_ready
);

localparam AXI_WORDS = AXIS_PCIE_DATA_WIDTH/32;
localparam SEG_WORDS = TLP_DATA_WIDTH/TLP_SEG_COUNT/32;
localparam SEG_STRB_WIDTH = TLP_STRB_WIDTH/TLP_SEG_COUNT;
localparam PTR_WIDTH = AXI_WORDS <= 1 ? 1 : $clog2(AXI_WORDS);

initial begin
    if (AXIS_PCIE_DATA_WIDTH != 64 && AXIS_PCIE_DATA_WIDTH != 128 &&
            AXIS_PCIE_DATA_WIDTH != 256 && AXIS_PCIE_DATA_WIDTH != 512) begin
        $error("Error: PCIe interface width must be 64, 128, 256, or 512 (instance %m)");
        $finish;
    end
    if (AXIS_PCIE_KEEP_WIDTH != AXI_WORDS || TLP_DATA_WIDTH != AXIS_PCIE_DATA_WIDTH ||
            TLP_STRB_WIDTH != AXI_WORDS || TLP_HDR_WIDTH != 128 ||
            TLP_SEG_COUNT < 1 || TLP_DATA_WIDTH % (TLP_SEG_COUNT*32) != 0) begin
        $error("Error: invalid segmented TLP configuration (instance %m)");
        $finish;
    end
    if ((AXIS_PCIE_DATA_WIDTH == 512 && AXIS_PCIE_RC_USER_WIDTH != 161) ||
            (AXIS_PCIE_DATA_WIDTH < 512 && AXIS_PCIE_RC_USER_WIDTH != 75)) begin
        $error("Error: invalid RC tuser width (instance %m)");
        $finish;
    end
end

localparam [3:0]
    RC_ERROR_NORMAL_TERMINATION = 4'b0000, RC_ERROR_POISONED = 4'b0001,
    RC_ERROR_BAD_STATUS = 4'b0010, RC_ERROR_INVALID_LENGTH = 4'b0011,
    RC_ERROR_MISMATCH = 4'b0100, RC_ERROR_INVALID_ADDRESS = 4'b0101,
    RC_ERROR_INVALID_TAG = 4'b0110, RC_ERROR_FLR = 4'b1000,
    RC_ERROR_TIMEOUT = 4'b1001;
localparam [3:0]
    PCIE_ERROR_NONE = 4'd0, PCIE_ERROR_POISONED = 4'd1,
    PCIE_ERROR_BAD_STATUS = 4'd2, PCIE_ERROR_MISMATCH = 4'd3,
    PCIE_ERROR_INVALID_LEN = 4'd4, PCIE_ERROR_INVALID_ADDR = 4'd5,
    PCIE_ERROR_INVALID_TAG = 4'd6, PCIE_ERROR_FLR = 4'd8,
    PCIE_ERROR_TIMEOUT = 4'd15;

function [127:0] make_header;
    input [95:0] d;
    reg [127:0] h;
    begin
        h = 0;
        h[127:125] = d[42:32] != 0 ? 3'b010 : 3'b000;
        h[124:120] = {4'b0101, d[29]};
        h[118:116] = d[91:89];
        h[114] = d[94];
        h[110] = d[46];
        h[109:108] = d[93:92];
        h[105:96] = d[42:32];
        h[95:80] = d[87:72];
        h[79:77] = d[45:43];
        h[75:64] = d[28:16];
        h[63:48] = d[63:48];
        h[47:40] = d[71:64];
        h[38:32] = d[6:0];
        make_header = h;
    end
endfunction

function [3:0] make_error;
    input [3:0] e;
    begin
        case (e)
            RC_ERROR_NORMAL_TERMINATION: make_error = PCIE_ERROR_NONE;
            RC_ERROR_POISONED:           make_error = PCIE_ERROR_POISONED;
            RC_ERROR_BAD_STATUS:         make_error = PCIE_ERROR_BAD_STATUS;
            RC_ERROR_INVALID_LENGTH:     make_error = PCIE_ERROR_INVALID_LEN;
            RC_ERROR_MISMATCH:           make_error = PCIE_ERROR_MISMATCH;
            RC_ERROR_INVALID_ADDRESS:    make_error = PCIE_ERROR_INVALID_ADDR;
            RC_ERROR_INVALID_TAG:        make_error = PCIE_ERROR_INVALID_TAG;
            RC_ERROR_FLR:                make_error = PCIE_ERROR_FLR;
            RC_ERROR_TIMEOUT:            make_error = PCIE_ERROR_TIMEOUT;
            default:                     make_error = PCIE_ERROR_NONE;
        endcase
    end
endfunction

reg [TLP_DATA_WIDTH-1:0] data_reg = 0;
reg [TLP_STRB_WIDTH-1:0] strb_reg = 0;
reg [TLP_SEG_COUNT*128-1:0] hdr_reg = 0;
reg [TLP_SEG_COUNT*4-1:0] error_reg = 0;
reg [TLP_SEG_COUNT-1:0] valid_reg = 0, sop_reg = 0, eop_reg = 0;
assign rx_cpl_tlp_data = data_reg;
assign rx_cpl_tlp_strb = strb_reg;
assign rx_cpl_tlp_hdr = hdr_reg;
assign rx_cpl_tlp_error = error_reg;
assign rx_cpl_tlp_valid = valid_reg;
assign rx_cpl_tlp_sop = sop_reg;
assign rx_cpl_tlp_eop = eop_reg;

reg [AXIS_PCIE_DATA_WIDTH-1:0] beat_data_reg = 0;
reg [AXIS_PCIE_KEEP_WIDTH-1:0] beat_keep_reg = 0;
reg [AXIS_PCIE_RC_USER_WIDTH-1:0] beat_user_reg = 0;
reg beat_valid_reg = 1'b0;
reg beat_second_reg = 1'b0;
reg [PTR_WIDTH:0] cur_ptr_reg = 0;
reg cur_eop_valid_reg = 1'b0;
reg [PTR_WIDTH-1:0] cur_eop_ptr_reg = 0;
reg packet_active_reg = 1'b0;
reg packet_straddled_reg = 1'b0;
reg need_header_reg = 1'b0;
reg sop_pending_reg = 1'b0;
reg [127:0] packet_hdr_reg = 0;
reg [95:0] header_acc_reg = 0;
integer header_offset_reg = 0;
reg [3:0] packet_error_reg = 0;
reg [SEG_WORDS*32-1:0] acc_data_reg = 0;
reg [SEG_STRB_WIDTH-1:0] acc_strb_reg = 0;
integer acc_count_reg = 0;

assign s_axis_rc_tready = !rst && !beat_valid_reg;

reg [95:0] descriptor;
reg [95:0] work_header;
reg [SEG_WORDS*32-1:0] work_data;
reg [SEG_STRB_WIDTH-1:0] work_strb;
integer work_count;
integer work_ptr;
integer header_work_offset;
integer i;
integer last_ptr;
reg finish_packet;
reg start_second;

always @(posedge clk) begin
    if (valid_reg != 0 && rx_cpl_tlp_ready) begin
        valid_reg <= 0;
        sop_reg <= 0;
        eop_reg <= 0;
    end

    if (!beat_valid_reg && s_axis_rc_tvalid && s_axis_rc_tready) begin
        beat_data_reg <= s_axis_rc_tdata;
        beat_keep_reg <= s_axis_rc_tkeep;
        beat_user_reg <= s_axis_rc_tuser;
        beat_valid_reg <= 1'b1;
        beat_second_reg <= 1'b0;
        need_header_reg <= !packet_active_reg || header_offset_reg != 0;
        if (!packet_active_reg) begin
            packet_active_reg <= 1'b1;
            header_acc_reg <= 0;
            header_offset_reg <= 0;
            packet_straddled_reg <= AXIS_PCIE_DATA_WIDTH == 512 &&
                (s_axis_rc_tuser[7:6] != 0 || s_axis_rc_tuser[1:0] != 0);
            sop_pending_reg <= 1'b1;
        end
        last_ptr = AXI_WORDS-1;
        for (i = 0; i < AXI_WORDS; i = i+1) begin
            if (s_axis_rc_tkeep[i]) begin
                last_ptr = i;
            end
        end
        if (AXIS_PCIE_DATA_WIDTH == 512) begin
            cur_ptr_reg <= !packet_active_reg && s_axis_rc_tuser[1:0] != 0 ? s_axis_rc_tuser[3:2] : 0;
            cur_eop_valid_reg <= (packet_active_reg ? packet_straddled_reg :
                (s_axis_rc_tuser[7:6] != 0 || s_axis_rc_tuser[1:0] != 0)) ?
                (s_axis_rc_tuser[6] || s_axis_rc_tlast) : s_axis_rc_tlast;
            cur_eop_ptr_reg <= (packet_active_reg ? packet_straddled_reg :
                (s_axis_rc_tuser[7:6] != 0 || s_axis_rc_tuser[1:0] != 0)) &&
                s_axis_rc_tuser[6] ? s_axis_rc_tuser[11:8] : last_ptr;
        end else begin
            cur_ptr_reg <= 0;
            cur_eop_valid_reg <= s_axis_rc_tlast;
            cur_eop_ptr_reg <= last_ptr;
        end
    end

    if (beat_valid_reg && (valid_reg == 0 || rx_cpl_tlp_ready)) begin
        if (need_header_reg) begin
            work_header = header_acc_reg;
            work_ptr = cur_ptr_reg;
            header_work_offset = header_offset_reg;
            for (i = 0; i < 3; i = i+1) begin
                if (header_work_offset < 3 && work_ptr < AXI_WORDS) begin
                    work_header[header_work_offset*32 +: 32] = beat_data_reg[work_ptr*32 +: 32];
                    header_work_offset = header_work_offset+1;
                    work_ptr = work_ptr+1;
                end
            end
            header_acc_reg <= work_header;
            header_offset_reg <= header_work_offset;
            if (header_work_offset == 3) begin
                packet_hdr_reg <= make_header(work_header);
                packet_error_reg <= make_error(work_header[15:12]);
                cur_ptr_reg <= work_ptr;
                header_offset_reg <= 0;
                need_header_reg <= 1'b0;
            end else begin
                beat_valid_reg <= 1'b0;
            end
        end else if (packet_active_reg) begin
            work_data = acc_data_reg;
            work_strb = acc_strb_reg;
            work_count = acc_count_reg;
            work_ptr = cur_ptr_reg;
            for (i = 0; i < SEG_WORDS; i = i+1) begin
                if (work_count < SEG_WORDS && work_ptr < AXI_WORDS &&
                        (!cur_eop_valid_reg || work_ptr <= cur_eop_ptr_reg)) begin
                    work_data[work_count*32 +: 32] = beat_data_reg[work_ptr*32 +: 32];
                    work_strb[work_count] = beat_keep_reg[work_ptr];
                    work_count = work_count+1;
                    work_ptr = work_ptr+1;
                end
            end
            finish_packet = cur_eop_valid_reg && work_ptr > cur_eop_ptr_reg;
            start_second = finish_packet && !beat_second_reg && packet_straddled_reg &&
                beat_user_reg[6] && beat_user_reg[1] && beat_user_reg[5:4] > cur_eop_ptr_reg;

            if (work_count == SEG_WORDS || finish_packet) begin
                data_reg <= 0;
                strb_reg <= 0;
                hdr_reg <= 0;
                error_reg <= 0;
                valid_reg <= 0;
                sop_reg <= 0;
                eop_reg <= 0;
                data_reg[0 +: SEG_WORDS*32] <= work_data;
                strb_reg[0 +: SEG_STRB_WIDTH] <= work_strb;
                hdr_reg[0 +: 128] <= packet_hdr_reg;
                error_reg[0 +: 4] <= packet_error_reg;
                valid_reg[0] <= 1'b1;
                sop_reg[0] <= sop_pending_reg;
                eop_reg[0] <= finish_packet;
                acc_data_reg <= 0;
                acc_strb_reg <= 0;
                acc_count_reg <= 0;
                sop_pending_reg <= 1'b0;
            end else begin
                acc_data_reg <= work_data;
                acc_strb_reg <= work_strb;
                acc_count_reg <= work_count;
            end

            if (finish_packet) begin
                if (start_second) begin
                    beat_second_reg <= 1'b1;
                    cur_ptr_reg <= beat_user_reg[5:4];
                    cur_eop_valid_reg <= beat_user_reg[7];
                    cur_eop_ptr_reg <= beat_user_reg[15:12];
                    need_header_reg <= 1'b1;
                    packet_active_reg <= 1'b1;
                    sop_pending_reg <= 1'b1;
                end else begin
                    beat_valid_reg <= 1'b0;
                    packet_active_reg <= 1'b0;
                    need_header_reg <= 1'b0;
                end
            end else if (work_ptr >= AXI_WORDS) begin
                beat_valid_reg <= 1'b0;
                cur_ptr_reg <= 0;
            end else begin
                cur_ptr_reg <= work_ptr;
            end
        end
    end

    if (rst) begin
        data_reg <= 0;
        strb_reg <= 0;
        hdr_reg <= 0;
        error_reg <= 0;
        valid_reg <= 0;
        sop_reg <= 0;
        eop_reg <= 0;
        beat_valid_reg <= 1'b0;
        beat_second_reg <= 1'b0;
        cur_ptr_reg <= 0;
        cur_eop_valid_reg <= 1'b0;
        cur_eop_ptr_reg <= 0;
        packet_active_reg <= 1'b0;
        packet_straddled_reg <= 1'b0;
        header_acc_reg <= 0;
        header_offset_reg <= 0;
        need_header_reg <= 1'b0;
        sop_pending_reg <= 1'b0;
        acc_data_reg <= 0;
        acc_strb_reg <= 0;
        acc_count_reg <= 0;
    end
end

endmodule
`resetall
