/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001
`resetall
`timescale 1ns / 1ps
`default_nettype none

/* Xilinx UltraScale PCIe interface adapter (Completer reQuest) */
module pcie_us_if_cq #
(
    parameter AXIS_PCIE_DATA_WIDTH = 256,
    parameter AXIS_PCIE_KEEP_WIDTH = AXIS_PCIE_DATA_WIDTH/32,
    parameter AXIS_PCIE_CQ_USER_WIDTH = AXIS_PCIE_DATA_WIDTH < 512 ? 85 : 183,
    parameter TLP_DATA_WIDTH = AXIS_PCIE_DATA_WIDTH,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter TLP_SEG_COUNT = AXIS_PCIE_DATA_WIDTH < 512 ? 1 : 2
)
(
    input  wire                                         clk,
    input  wire                                         rst,
    input  wire [AXIS_PCIE_DATA_WIDTH-1:0]              s_axis_cq_tdata,
    input  wire [AXIS_PCIE_KEEP_WIDTH-1:0]              s_axis_cq_tkeep,
    input  wire                                         s_axis_cq_tvalid,
    output wire                                         s_axis_cq_tready,
    input  wire                                         s_axis_cq_tlast,
    input  wire [AXIS_PCIE_CQ_USER_WIDTH-1:0]           s_axis_cq_tuser,
    output wire [TLP_DATA_WIDTH-1:0]                    rx_req_tlp_data,
    output wire [TLP_STRB_WIDTH-1:0]                    rx_req_tlp_strb,
    output wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]       rx_req_tlp_hdr,
    output wire [TLP_SEG_COUNT*3-1:0]                   rx_req_tlp_bar_id,
    output wire [TLP_SEG_COUNT*8-1:0]                   rx_req_tlp_func_num,
    output wire [TLP_SEG_COUNT-1:0]                     rx_req_tlp_valid,
    output wire [TLP_SEG_COUNT-1:0]                     rx_req_tlp_sop,
    output wire [TLP_SEG_COUNT-1:0]                     rx_req_tlp_eop,
    input  wire                                         rx_req_tlp_ready
);

localparam AXI_WORDS = AXIS_PCIE_DATA_WIDTH/32;
localparam SEG_WORDS = TLP_DATA_WIDTH/TLP_SEG_COUNT/32;
localparam SEG_STRB_WIDTH = TLP_STRB_WIDTH/TLP_SEG_COUNT;
localparam PTR_WIDTH = AXI_WORDS <= 1 ? 1 : $clog2(AXI_WORDS);

initial begin
    if (AXIS_PCIE_DATA_WIDTH != 64 && AXIS_PCIE_DATA_WIDTH != 128 &&
            AXIS_PCIE_DATA_WIDTH != 256 && AXIS_PCIE_DATA_WIDTH != 512) begin
        $error("Error: PCIe interface width must be 64, 128, 256, or 512 (instance %m)");
        $finish;
    end
    if (AXIS_PCIE_KEEP_WIDTH != AXI_WORDS || TLP_DATA_WIDTH != AXIS_PCIE_DATA_WIDTH ||
            TLP_STRB_WIDTH != AXI_WORDS || TLP_HDR_WIDTH != 128 ||
            TLP_SEG_COUNT < 1 || TLP_DATA_WIDTH % (TLP_SEG_COUNT*32) != 0) begin
        $error("Error: invalid segmented TLP configuration (instance %m)");
        $finish;
    end
    if ((AXIS_PCIE_DATA_WIDTH == 512 && AXIS_PCIE_CQ_USER_WIDTH != 183) ||
            (AXIS_PCIE_DATA_WIDTH < 512 && AXIS_PCIE_CQ_USER_WIDTH != 85 && AXIS_PCIE_CQ_USER_WIDTH != 88)) begin
        $error("Error: invalid CQ tuser width (instance %m)");
        $finish;
    end
end

localparam [2:0] TLP_FMT_4DW = 3'b001, TLP_FMT_4DW_DATA = 3'b011;
localparam [3:0]
    REQ_MEM_READ = 4'b0000, REQ_MEM_WRITE = 4'b0001,
    REQ_IO_READ = 4'b0010, REQ_IO_WRITE = 4'b0011,
    REQ_MEM_FETCH_ADD = 4'b0100, REQ_MEM_SWAP = 4'b0101,
    REQ_MEM_CAS = 4'b0110, REQ_MEM_READ_LOCKED = 4'b0111,
    REQ_MSG = 4'b1100, REQ_MSG_VENDOR = 4'b1101, REQ_MSG_ATS = 4'b1110;

function [127:0] make_header;
    input [127:0] d;
    input [AXIS_PCIE_CQ_USER_WIDTH-1:0] u;
    input second;
    reg [127:0] h;
    begin
        h = 0;
        case (d[78:75])
            REQ_MEM_READ:         begin h[127:125] = TLP_FMT_4DW;      h[124:120] = 5'b00000; end
            REQ_MEM_WRITE:        begin h[127:125] = TLP_FMT_4DW_DATA; h[124:120] = 5'b00000; end
            REQ_IO_READ:          begin h[127:125] = TLP_FMT_4DW;      h[124:120] = 5'b00010; end
            REQ_IO_WRITE:         begin h[127:125] = TLP_FMT_4DW_DATA; h[124:120] = 5'b00010; end
            REQ_MEM_FETCH_ADD:    begin h[127:125] = TLP_FMT_4DW_DATA; h[124:120] = 5'b01100; end
            REQ_MEM_SWAP:         begin h[127:125] = TLP_FMT_4DW_DATA; h[124:120] = 5'b01101; end
            REQ_MEM_CAS:          begin h[127:125] = TLP_FMT_4DW_DATA; h[124:120] = 5'b01110; end
            REQ_MEM_READ_LOCKED:  begin h[127:125] = TLP_FMT_4DW;      h[124:120] = 5'b00001; end
            REQ_MSG, REQ_MSG_VENDOR, REQ_MSG_ATS: begin
                h[127:125] = d[74:64] != 0 ? TLP_FMT_4DW_DATA : TLP_FMT_4DW;
                h[124:120] = {2'b10, d[114:112]};
            end
            default:              begin h[127:125] = TLP_FMT_4DW;      h[124:120] = 5'b00000; end
        endcase
        h[118:116] = d[123:121];
        h[114] = d[126];
        h[110] = d[79];
        h[109:108] = d[125:124];
        h[107:106] = d[1:0];
        h[105:96] = d[74:64];
        h[95:80] = d[95:80];
        h[79:72] = d[103:96];
        if (AXIS_PCIE_DATA_WIDTH == 512) begin
            h[71:68] = second ? u[15:12] : u[11:8];
            h[67:64] = second ? u[7:4] : u[3:0];
        end else begin
            h[71:68] = u[7:4];
            h[67:64] = u[3:0];
        end
        h[63:2] = d[63:2];
        make_header = h;
    end
endfunction

reg [TLP_DATA_WIDTH-1:0] data_reg = 0;
reg [TLP_STRB_WIDTH-1:0] strb_reg = 0;
reg [TLP_SEG_COUNT*128-1:0] hdr_reg = 0;
reg [TLP_SEG_COUNT*3-1:0] bar_reg = 0;
reg [TLP_SEG_COUNT*8-1:0] func_reg = 0;
reg [TLP_SEG_COUNT-1:0] valid_reg = 0, sop_reg = 0, eop_reg = 0;
assign rx_req_tlp_data = data_reg;
assign rx_req_tlp_strb = strb_reg;
assign rx_req_tlp_hdr = hdr_reg;
assign rx_req_tlp_bar_id = bar_reg;
assign rx_req_tlp_func_num = func_reg;
assign rx_req_tlp_valid = valid_reg;
assign rx_req_tlp_sop = sop_reg;
assign rx_req_tlp_eop = eop_reg;

reg [AXIS_PCIE_DATA_WIDTH-1:0] beat_data_reg = 0;
reg [AXIS_PCIE_KEEP_WIDTH-1:0] beat_keep_reg = 0;
reg [AXIS_PCIE_CQ_USER_WIDTH-1:0] beat_user_reg = 0;
reg beat_valid_reg = 1'b0;
reg beat_second_reg = 1'b0;
reg [PTR_WIDTH:0] cur_ptr_reg = 0;
reg cur_eop_valid_reg = 1'b0;
reg [PTR_WIDTH-1:0] cur_eop_ptr_reg = 0;
reg packet_active_reg = 1'b0;
reg packet_straddled_reg = 1'b0;
reg need_header_reg = 1'b0;
reg sop_pending_reg = 1'b0;
reg [127:0] packet_hdr_reg = 0;
reg [127:0] header_acc_reg = 0;
reg [AXIS_PCIE_CQ_USER_WIDTH-1:0] packet_user_reg = 0;
integer header_offset_reg = 0;
reg [2:0] packet_bar_reg = 0;
reg [7:0] packet_func_reg = 0;
reg [SEG_WORDS*32-1:0] acc_data_reg = 0;
reg [SEG_STRB_WIDTH-1:0] acc_strb_reg = 0;
integer acc_count_reg = 0;

assign s_axis_cq_tready = !rst && !beat_valid_reg;

reg [127:0] descriptor;
reg [127:0] work_header;
reg [SEG_WORDS*32-1:0] work_data;
reg [SEG_STRB_WIDTH-1:0] work_strb;
integer work_count;
integer work_ptr;
integer header_work_offset;
integer i;
integer last_ptr;
reg finish_packet;
reg start_second;

always @(posedge clk) begin
    if (valid_reg != 0 && rx_req_tlp_ready) begin
        valid_reg <= 0;
        sop_reg <= 0;
        eop_reg <= 0;
    end

    if (!beat_valid_reg && s_axis_cq_tvalid && s_axis_cq_tready) begin
        beat_data_reg <= s_axis_cq_tdata;
        beat_keep_reg <= s_axis_cq_tkeep;
        beat_user_reg <= s_axis_cq_tuser;
        beat_valid_reg <= 1'b1;
        beat_second_reg <= 1'b0;
        need_header_reg <= !packet_active_reg || header_offset_reg != 0;
        if (!packet_active_reg) begin
            packet_active_reg <= 1'b1;
            packet_user_reg <= s_axis_cq_tuser;
            header_acc_reg <= 0;
            header_offset_reg <= 0;
            packet_straddled_reg <= AXIS_PCIE_DATA_WIDTH == 512 &&
                (s_axis_cq_tuser[27:26] != 0 || s_axis_cq_tuser[21:20] != 0);
            sop_pending_reg <= 1'b1;
        end
        last_ptr = AXI_WORDS-1;
        for (i = 0; i < AXI_WORDS; i = i+1) begin
            if (s_axis_cq_tkeep[i]) begin
                last_ptr = i;
            end
        end
        if (AXIS_PCIE_DATA_WIDTH == 512) begin
            cur_ptr_reg <= !packet_active_reg && s_axis_cq_tuser[21:20] != 0 ? s_axis_cq_tuser[23:22] : 0;
            cur_eop_valid_reg <= (packet_active_reg ? packet_straddled_reg :
                (s_axis_cq_tuser[27:26] != 0 || s_axis_cq_tuser[21:20] != 0)) ?
                (s_axis_cq_tuser[26] || s_axis_cq_tlast) : s_axis_cq_tlast;
            cur_eop_ptr_reg <= (packet_active_reg ? packet_straddled_reg :
                (s_axis_cq_tuser[27:26] != 0 || s_axis_cq_tuser[21:20] != 0)) &&
                s_axis_cq_tuser[26] ? s_axis_cq_tuser[31:28] : last_ptr;
        end else begin
            cur_ptr_reg <= 0;
            cur_eop_valid_reg <= s_axis_cq_tlast;
            cur_eop_ptr_reg <= last_ptr;
        end
    end

    if (beat_valid_reg && (valid_reg == 0 || rx_req_tlp_ready)) begin
        if (need_header_reg) begin
            work_header = header_acc_reg;
            work_ptr = cur_ptr_reg;
            header_work_offset = header_offset_reg;
            for (i = 0; i < 4; i = i+1) begin
                if (header_work_offset < 4 && work_ptr < AXI_WORDS) begin
                    work_header[header_work_offset*32 +: 32] = beat_data_reg[work_ptr*32 +: 32];
                    header_work_offset = header_work_offset+1;
                    work_ptr = work_ptr+1;
                end
            end
            header_acc_reg <= work_header;
            header_offset_reg <= header_work_offset;
            if (header_work_offset == 4) begin
                packet_hdr_reg <= make_header(work_header, packet_user_reg, beat_second_reg);
                packet_bar_reg <= work_header[114:112];
                packet_func_reg <= work_header[111:104];
                cur_ptr_reg <= work_ptr;
                header_offset_reg <= 0;
                need_header_reg <= 1'b0;
            end else begin
                beat_valid_reg <= 1'b0;
            end
        end else if (packet_active_reg) begin
            work_data = acc_data_reg;
            work_strb = acc_strb_reg;
            work_count = acc_count_reg;
            work_ptr = cur_ptr_reg;
            for (i = 0; i < SEG_WORDS; i = i+1) begin
                if (work_count < SEG_WORDS && work_ptr < AXI_WORDS &&
                        (!cur_eop_valid_reg || work_ptr <= cur_eop_ptr_reg)) begin
                    work_data[work_count*32 +: 32] = beat_data_reg[work_ptr*32 +: 32];
                    work_strb[work_count] = beat_keep_reg[work_ptr];
                    work_count = work_count+1;
                    work_ptr = work_ptr+1;
                end
            end
            finish_packet = cur_eop_valid_reg && work_ptr > cur_eop_ptr_reg;
            start_second = finish_packet && !beat_second_reg && packet_straddled_reg &&
                beat_user_reg[26] && beat_user_reg[21] && beat_user_reg[25:24] > cur_eop_ptr_reg;

            if (work_count == SEG_WORDS || finish_packet) begin
                data_reg <= 0;
                strb_reg <= 0;
                hdr_reg <= 0;
                bar_reg <= 0;
                func_reg <= 0;
                valid_reg <= 0;
                sop_reg <= 0;
                eop_reg <= 0;
                data_reg[0 +: SEG_WORDS*32] <= work_data;
                strb_reg[0 +: SEG_STRB_WIDTH] <= work_strb;
                hdr_reg[0 +: 128] <= packet_hdr_reg;
                bar_reg[0 +: 3] <= packet_bar_reg;
                func_reg[0 +: 8] <= packet_func_reg;
                valid_reg[0] <= 1'b1;
                sop_reg[0] <= sop_pending_reg;
                eop_reg[0] <= finish_packet;
                acc_data_reg <= 0;
                acc_strb_reg <= 0;
                acc_count_reg <= 0;
                sop_pending_reg <= 1'b0;
            end else begin
                acc_data_reg <= work_data;
                acc_strb_reg <= work_strb;
                acc_count_reg <= work_count;
            end

            if (finish_packet) begin
                if (start_second) begin
                    beat_second_reg <= 1'b1;
                    cur_ptr_reg <= beat_user_reg[25:24];
                    cur_eop_valid_reg <= beat_user_reg[27];
                    cur_eop_ptr_reg <= beat_user_reg[35:32];
                    need_header_reg <= 1'b1;
                    packet_active_reg <= 1'b1;
                    sop_pending_reg <= 1'b1;
                end else begin
                    beat_valid_reg <= 1'b0;
                    packet_active_reg <= 1'b0;
                    need_header_reg <= 1'b0;
                end
            end else if (work_ptr >= AXI_WORDS) begin
                beat_valid_reg <= 1'b0;
                cur_ptr_reg <= 0;
            end else begin
                cur_ptr_reg <= work_ptr;
            end
        end
    end

    if (rst) begin
        data_reg <= 0;
        strb_reg <= 0;
        hdr_reg <= 0;
        bar_reg <= 0;
        func_reg <= 0;
        valid_reg <= 0;
        sop_reg <= 0;
        eop_reg <= 0;
        beat_valid_reg <= 1'b0;
        beat_second_reg <= 1'b0;
        cur_ptr_reg <= 0;
        cur_eop_valid_reg <= 1'b0;
        cur_eop_ptr_reg <= 0;
        packet_active_reg <= 1'b0;
        packet_straddled_reg <= 1'b0;
        header_acc_reg <= 0;
        packet_user_reg <= 0;
        header_offset_reg <= 0;
        need_header_reg <= 1'b0;
        sop_pending_reg <= 1'b0;
        acc_data_reg <= 0;
        acc_strb_reg <= 0;
        acc_count_reg <= 0;
    end
end

endmodule
`resetall
