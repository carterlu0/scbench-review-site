/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001
`resetall
`timescale 1ns / 1ps
`default_nettype none

/* Xilinx UltraScale PCIe interface adapter (Completer Completion) */
module pcie_us_if_cc #
(
    parameter AXIS_PCIE_DATA_WIDTH = 256,
    parameter AXIS_PCIE_KEEP_WIDTH = AXIS_PCIE_DATA_WIDTH/32,
    parameter AXIS_PCIE_CC_USER_WIDTH = AXIS_PCIE_DATA_WIDTH < 512 ? 33 : 81,
    parameter TLP_DATA_WIDTH = AXIS_PCIE_DATA_WIDTH,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter TLP_SEG_COUNT = AXIS_PCIE_DATA_WIDTH < 512 ? 1 : 2
)
(
    input  wire                                    clk,
    input  wire                                    rst,
    output wire [AXIS_PCIE_DATA_WIDTH-1:0]         m_axis_cc_tdata,
    output wire [AXIS_PCIE_KEEP_WIDTH-1:0]         m_axis_cc_tkeep,
    output wire                                    m_axis_cc_tvalid,
    input  wire                                    m_axis_cc_tready,
    output wire                                    m_axis_cc_tlast,
    output wire [AXIS_PCIE_CC_USER_WIDTH-1:0]      m_axis_cc_tuser,
    input  wire [TLP_DATA_WIDTH-1:0]               tx_cpl_tlp_data,
    input  wire [TLP_STRB_WIDTH-1:0]               tx_cpl_tlp_strb,
    input  wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]  tx_cpl_tlp_hdr,
    input  wire [TLP_SEG_COUNT-1:0]                tx_cpl_tlp_valid,
    input  wire [TLP_SEG_COUNT-1:0]                tx_cpl_tlp_sop,
    input  wire [TLP_SEG_COUNT-1:0]                tx_cpl_tlp_eop,
    output wire                                    tx_cpl_tlp_ready
);

localparam AXI_WORDS = AXIS_PCIE_DATA_WIDTH/32;
localparam SEG_WORDS = TLP_DATA_WIDTH/TLP_SEG_COUNT/32;
localparam SEG_STRB_WIDTH = TLP_STRB_WIDTH/TLP_SEG_COUNT;
localparam WORK_WIDTH = AXIS_PCIE_DATA_WIDTH < 128 ? 128 : AXIS_PCIE_DATA_WIDTH;

initial begin
    if (AXIS_PCIE_DATA_WIDTH != 64 && AXIS_PCIE_DATA_WIDTH != 128 &&
            AXIS_PCIE_DATA_WIDTH != 256 && AXIS_PCIE_DATA_WIDTH != 512) begin
        $error("Error: PCIe interface width must be 64, 128, 256, or 512 (instance %m)");
        $finish;
    end
    if (AXIS_PCIE_KEEP_WIDTH != AXI_WORDS || TLP_DATA_WIDTH != AXIS_PCIE_DATA_WIDTH ||
            TLP_STRB_WIDTH != AXI_WORDS || TLP_HDR_WIDTH != 128 ||
            TLP_SEG_COUNT < 1 || TLP_DATA_WIDTH % (TLP_SEG_COUNT*32) != 0) begin
        $error("Error: invalid segmented TLP configuration (instance %m)");
        $finish;
    end
    if ((AXIS_PCIE_DATA_WIDTH == 512 && AXIS_PCIE_CC_USER_WIDTH != 81) ||
            (AXIS_PCIE_DATA_WIDTH < 512 && AXIS_PCIE_CC_USER_WIDTH != 33)) begin
        $error("Error: invalid CC tuser width (instance %m)");
        $finish;
    end
end

function [95:0] make_descriptor;
    input [127:0] h;
    reg [95:0] d;
    begin
        d = 0;
        d[6:0] = h[38:32];
        d[9:8] = h[107:106];
        d[28:16] = h[75:64];
        d[42:32] = h[105:96];
        d[45:43] = h[79:77];
        d[46] = h[110];
        d[63:48] = h[63:48];
        d[71:64] = h[47:40];
        d[87:72] = h[95:80];
        d[91:89] = h[118:116];
        d[94:92] = h[114] ? 3'b100 : {1'b0, h[109:108]};
        make_descriptor = d;
    end
endfunction

wire [SEG_WORDS*32-1:0] ser_data;
wire [SEG_STRB_WIDTH-1:0] ser_strb;
wire [127:0] ser_hdr;
wire ser_valid, ser_sop, ser_eop;
reg ser_done_reg = 1'b0;

pcie_us_if_cc_seg_fifo #(
    .TLP_DATA_WIDTH(TLP_DATA_WIDTH),
    .TLP_STRB_WIDTH(TLP_STRB_WIDTH),
    .TLP_SEG_COUNT(TLP_SEG_COUNT)
) seg_fifo_inst (
    .clk(clk), .rst(rst),
    .in_tlp_data(tx_cpl_tlp_data), .in_tlp_strb(tx_cpl_tlp_strb),
    .in_tlp_hdr(tx_cpl_tlp_hdr), .in_tlp_valid(tx_cpl_tlp_valid),
    .in_tlp_sop(tx_cpl_tlp_sop), .in_tlp_eop(tx_cpl_tlp_eop),
    .in_tlp_ready(tx_cpl_tlp_ready),
    .out_tlp_data(ser_data), .out_tlp_strb(ser_strb), .out_tlp_hdr(ser_hdr),
    .out_tlp_valid(ser_valid), .out_tlp_sop(ser_sop), .out_tlp_eop(ser_eop),
    .out_tlp_ready(ser_done_reg)
);

reg [AXIS_PCIE_DATA_WIDTH-1:0] out_data_reg = 0;
reg [AXIS_PCIE_KEEP_WIDTH-1:0] out_keep_reg = 0;
reg out_valid_reg = 1'b0;
reg out_last_reg = 1'b0;
reg [AXIS_PCIE_CC_USER_WIDTH-1:0] out_user_reg = 0;
assign m_axis_cc_tdata = out_data_reg;
assign m_axis_cc_tkeep = out_keep_reg;
assign m_axis_cc_tvalid = out_valid_reg;
assign m_axis_cc_tlast = out_last_reg;
assign m_axis_cc_tuser = out_user_reg;

reg [AXIS_PCIE_DATA_WIDTH-1:0] assembly_data_reg = 0;
reg [AXIS_PCIE_CC_USER_WIDTH-1:0] packet_user_reg = 0;
integer assembly_count_reg = 0;
integer record_offset_reg = 0;
reg packet_active_reg = 1'b0;
reg packet_end_reg = 1'b0;
reg assembly_sop_reg = 1'b0;

reg [WORK_WIDTH-1:0] work_data;
reg [AXIS_PCIE_CC_USER_WIDTH-1:0] work_user;
reg [AXIS_PCIE_CC_USER_WIDTH-1:0] emit_user;
integer work_count;
integer work_offset;
integer record_words;
integer i;
reg work_sop;
reg record_done;
reg finish_packet;

always @(posedge clk) begin
    if (out_valid_reg && m_axis_cc_tready) begin
        out_valid_reg <= 1'b0;
        out_last_reg <= 1'b0;
    end

    if (ser_done_reg) begin
        ser_done_reg <= 1'b0;
        record_offset_reg <= 0;
    end

    if (((ser_valid && !ser_done_reg && !(packet_end_reg && assembly_count_reg > 0)) ||
            (packet_active_reg && assembly_count_reg > 0 &&
                (!ser_valid || ser_done_reg || packet_end_reg))) &&
            (!out_valid_reg || m_axis_cc_tready)) begin
        work_data = assembly_data_reg;
        work_user = packet_user_reg;
        work_count = assembly_count_reg;
        work_offset = ser_done_reg ? 0 : record_offset_reg;
        work_sop = assembly_sop_reg;
        record_done = 1'b0;
        record_words = 0;

        if (ser_valid && !ser_done_reg && !(packet_end_reg && assembly_count_reg > 0)) begin
            if (!packet_active_reg) begin
                work_data = 0;
                work_data[95:0] = make_descriptor(ser_hdr);
                work_user = 0;
                work_count = 3;
                work_offset = 0;
                work_sop = 1'b1;
                assembly_sop_reg <= 1'b1;
                packet_user_reg <= work_user;
            end

            for (i = 0; i < SEG_STRB_WIDTH; i = i+1) begin
                if (ser_strb[i]) begin
                    record_words = i+1;
                end
            end
            for (i = 0; i < SEG_WORDS; i = i+1) begin
                if (i >= work_offset && i < record_words && work_count < AXI_WORDS) begin
                    work_data[work_count*32 +: 32] = ser_data[i*32 +: 32];
                    work_count = work_count+1;
                    work_offset = i+1;
                end
            end
            record_done = work_offset >= record_words;
        end

        if (record_done && ser_eop) begin
            packet_end_reg <= 1'b1;
        end
        finish_packet = (packet_end_reg || (record_done && ser_eop)) && work_count <= AXI_WORDS;
        assembly_data_reg <= work_data;
        assembly_count_reg <= work_count;
        record_offset_reg <= work_offset;
        packet_active_reg <= 1'b1;

        if (record_done) begin
            ser_done_reg <= 1'b1;
        end

        if (finish_packet || work_count >= AXI_WORDS) begin
            emit_user = work_user;
            if (AXIS_PCIE_DATA_WIDTH == 512) begin
                emit_user[1:0] = work_sop ? 2'b01 : 2'b00;
                emit_user[3:2] = 0;
                emit_user[5:4] = 0;
                emit_user[7:6] = finish_packet ? 2'b01 : 2'b00;
                emit_user[11:8] = work_count-1;
                emit_user[15:12] = 0;
                emit_user[16] = 1'b0;
            end
            out_data_reg <= work_data;
            out_keep_reg <= work_count >= AXI_WORDS ? {AXIS_PCIE_KEEP_WIDTH{1'b1}} :
                ({AXIS_PCIE_KEEP_WIDTH{1'b1}} >> (AXIS_PCIE_KEEP_WIDTH-work_count));
            out_user_reg <= emit_user;
            out_valid_reg <= 1'b1;
            out_last_reg <= finish_packet;
            assembly_sop_reg <= 1'b0;
            if (work_count > AXI_WORDS) begin
                assembly_data_reg <= work_data >> AXIS_PCIE_DATA_WIDTH;
                assembly_count_reg <= work_count-AXI_WORDS;
                packet_active_reg <= 1'b1;
            end else begin
                assembly_data_reg <= 0;
                assembly_count_reg <= 0;
                packet_active_reg <= !finish_packet;
                if (finish_packet) begin
                    packet_end_reg <= 1'b0;
                end
            end
        end
    end

    if (rst) begin
        out_data_reg <= 0;
        out_keep_reg <= 0;
        out_valid_reg <= 1'b0;
        out_last_reg <= 1'b0;
        out_user_reg <= 0;
        assembly_data_reg <= 0;
        packet_user_reg <= 0;
        assembly_count_reg <= 0;
        record_offset_reg <= 0;
        packet_active_reg <= 1'b0;
        packet_end_reg <= 1'b0;
        assembly_sop_reg <= 1'b0;
        ser_done_reg <= 1'b0;
    end
end

endmodule

/* Per-segment buffering and SOP-ordered serialization for the CC packer. */
module pcie_us_if_cc_seg_fifo #
(
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_SEG_COUNT = 1,
    parameter DEPTH = 32
)
(
    input wire clk,
    input wire rst,
    input wire [TLP_DATA_WIDTH-1:0] in_tlp_data,
    input wire [TLP_STRB_WIDTH-1:0] in_tlp_strb,
    input wire [TLP_SEG_COUNT*128-1:0] in_tlp_hdr,
    input wire [TLP_SEG_COUNT-1:0] in_tlp_valid,
    input wire [TLP_SEG_COUNT-1:0] in_tlp_sop,
    input wire [TLP_SEG_COUNT-1:0] in_tlp_eop,
    output wire in_tlp_ready,
    output wire [(TLP_DATA_WIDTH/TLP_SEG_COUNT)-1:0] out_tlp_data,
    output wire [(TLP_STRB_WIDTH/TLP_SEG_COUNT)-1:0] out_tlp_strb,
    output wire [127:0] out_tlp_hdr,
    output wire out_tlp_valid,
    output wire out_tlp_sop,
    output wire out_tlp_eop,
    input wire out_tlp_ready
);

localparam SEG_DATA_WIDTH = TLP_DATA_WIDTH/TLP_SEG_COUNT;
localparam SEG_STRB_WIDTH = TLP_STRB_WIDTH/TLP_SEG_COUNT;
localparam PTR_WIDTH = $clog2(DEPTH);
localparam COUNT_WIDTH = $clog2(DEPTH+1);
localparam CL_SEG = TLP_SEG_COUNT <= 1 ? 1 : $clog2(TLP_SEG_COUNT);
localparam TOKEN_DEPTH = 64;
localparam TOKEN_PTR_WIDTH = $clog2(TOKEN_DEPTH);
localparam TOKEN_COUNT_WIDTH = $clog2(TOKEN_DEPTH+1);

wire [TLP_SEG_COUNT-1:0] lane_ready;
reg [TLP_SEG_COUNT-1:0] lane_pop;
wire [TLP_DATA_WIDTH-1:0] lane_data;
wire [TLP_STRB_WIDTH-1:0] lane_strb;
wire [TLP_SEG_COUNT*128-1:0] lane_hdr;
wire [TLP_SEG_COUNT-1:0] lane_valid, lane_sop, lane_eop;

reg [CL_SEG-1:0] token_mem[TOKEN_DEPTH-1:0];
reg [TOKEN_PTR_WIDTH-1:0] token_wr_ptr = 0, token_rd_ptr = 0;
reg [TOKEN_COUNT_WIDTH-1:0] token_count = 0;
integer token_push_count;
integer token_write_index;
integer ti;
always @* begin
    token_push_count = 0;
    for (ti = 0; ti < TLP_SEG_COUNT; ti = ti+1) begin
        if (in_tlp_valid[ti] && in_tlp_sop[ti]) begin
            token_push_count = token_push_count+1;
        end
    end
end
wire token_push = in_tlp_ready && token_push_count != 0;
wire token_pop = out_tlp_valid && out_tlp_ready && out_tlp_eop;
assign in_tlp_ready = !rst && &lane_ready && token_count <= TOKEN_DEPTH-TLP_SEG_COUNT;

always @(posedge clk) begin
    if (token_push) begin
        token_write_index = 0;
        for (ti = 0; ti < TLP_SEG_COUNT; ti = ti+1) begin
            if (in_tlp_valid[ti] && in_tlp_sop[ti]) begin
                token_mem[token_wr_ptr+token_write_index] <= ti;
                token_write_index = token_write_index+1;
            end
        end
        token_wr_ptr <= token_wr_ptr+token_push_count;
    end
    if (token_pop) begin
        token_rd_ptr <= token_rd_ptr+1'b1;
    end
    case ({token_push, token_pop})
        2'b10: token_count <= token_count+token_push_count;
        2'b01: token_count <= token_count-1'b1;
        2'b11: token_count <= token_count+token_push_count-1'b1;
        default: token_count <= token_count;
    endcase
    if (rst) begin
        token_wr_ptr <= 0;
        token_rd_ptr <= 0;
        token_count <= 0;
    end
end

genvar g;
generate
    for (g = 0; g < TLP_SEG_COUNT; g = g+1) begin : lanes
        reg [SEG_DATA_WIDTH-1:0] data_mem[DEPTH-1:0];
        reg [SEG_STRB_WIDTH-1:0] strb_mem[DEPTH-1:0];
        reg [127:0] hdr_mem[DEPTH-1:0];
        reg sop_mem[DEPTH-1:0];
        reg eop_mem[DEPTH-1:0];
        reg [PTR_WIDTH-1:0] wr_ptr = 0, rd_ptr = 0;
        reg [COUNT_WIDTH-1:0] count = 0;
        wire push = in_tlp_ready && in_tlp_valid[g];
        wire pop = lane_pop[g] && count != 0;
        assign lane_ready[g] = count < DEPTH;
        assign lane_data[g*SEG_DATA_WIDTH +: SEG_DATA_WIDTH] = data_mem[rd_ptr];
        assign lane_strb[g*SEG_STRB_WIDTH +: SEG_STRB_WIDTH] = strb_mem[rd_ptr];
        assign lane_hdr[g*128 +: 128] = hdr_mem[rd_ptr];
        assign lane_valid[g] = count != 0;
        assign lane_sop[g] = sop_mem[rd_ptr];
        assign lane_eop[g] = eop_mem[rd_ptr];
        always @(posedge clk) begin
            if (push) begin
                data_mem[wr_ptr] <= in_tlp_data[g*SEG_DATA_WIDTH +: SEG_DATA_WIDTH];
                strb_mem[wr_ptr] <= in_tlp_strb[g*SEG_STRB_WIDTH +: SEG_STRB_WIDTH];
                hdr_mem[wr_ptr] <= in_tlp_hdr[g*128 +: 128];
                sop_mem[wr_ptr] <= in_tlp_sop[g];
                eop_mem[wr_ptr] <= in_tlp_eop[g];
                wr_ptr <= wr_ptr+1'b1;
            end
            if (pop) begin
                rd_ptr <= rd_ptr+1'b1;
            end
            case ({push, pop})
                2'b10: count <= count+1'b1;
                2'b01: count <= count-1'b1;
                default: count <= count;
            endcase
            if (rst) begin
                wr_ptr <= 0;
                rd_ptr <= 0;
                count <= 0;
            end
        end
    end
endgenerate

reg active_reg = 1'b0;
reg [CL_SEG-1:0] active_lane_reg = 0;
wire [CL_SEG-1:0] current_lane = active_reg ? active_lane_reg : token_mem[token_rd_ptr];
wire current_lane_valid = active_reg || token_count != 0;
assign out_tlp_data = lane_data[current_lane*SEG_DATA_WIDTH +: SEG_DATA_WIDTH];
assign out_tlp_strb = lane_strb[current_lane*SEG_STRB_WIDTH +: SEG_STRB_WIDTH];
assign out_tlp_hdr = lane_hdr[current_lane*128 +: 128];
assign out_tlp_valid = current_lane_valid && lane_valid[current_lane];
assign out_tlp_sop = lane_sop[current_lane];
assign out_tlp_eop = lane_eop[current_lane];
always @* begin
    lane_pop = 0;
    if (out_tlp_valid && out_tlp_ready) begin
        lane_pop[current_lane] = 1'b1;
    end
end
always @(posedge clk) begin
    if (out_tlp_valid && out_tlp_ready) begin
        if (out_tlp_eop) begin
            active_reg <= 1'b0;
        end else begin
            active_reg <= 1'b1;
            active_lane_reg <= current_lane;
        end
    end
    if (rst) begin
        active_reg <= 1'b0;
        active_lane_reg <= 0;
    end
end

endmodule
`resetall
