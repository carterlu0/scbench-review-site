#!/bin/sh
set -eu

if [ "$#" -ne 1 ] || [ "$1" != "checkpoint_2" ]; then
    echo "Usage: bash build_checkpoint.sh checkpoint_2" >&2
    exit 1
fi

repo_dir="$PWD/repo"
if [ ! -d "$repo_dir" ]; then
    echo "Error: staged repository not found at $repo_dir" >&2
    exit 1
fi

for file in \
    rtl/pcie_tlp_fifo.v \
    rtl/pcie_tlp_fifo_raw.v \
    rtl/dma_if_pcie_rd.v \
    rtl/pcie_tlp_demux.v \
    rtl/pcie_tlp_demux_bar.v \
    SNAPSHOT.json
do
    if [ ! -f "$repo_dir/$file" ]; then
        echo "Error: required checkpoint file is missing: $repo_dir/$file" >&2
        exit 1
    fi
done
