/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * PCIe TLP FIFO with independent input and output segment counts
 */
module pcie_tlp_fifo #
(
    parameter DEPTH = 4096,
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter SEQ_NUM_WIDTH = 6,
    parameter IN_TLP_SEG_COUNT = 1,
    parameter OUT_TLP_SEG_COUNT = IN_TLP_SEG_COUNT
)
(
    input  wire                                            clk,
    input  wire                                            rst,

    input  wire [TLP_DATA_WIDTH-1:0]                       in_tlp_data,
    input  wire [TLP_STRB_WIDTH-1:0]                       in_tlp_strb,
    input  wire [IN_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]       in_tlp_hdr,
    input  wire [IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]       in_tlp_seq,
    input  wire [IN_TLP_SEG_COUNT*3-1:0]                   in_tlp_bar_id,
    input  wire [IN_TLP_SEG_COUNT*8-1:0]                   in_tlp_func_num,
    input  wire [IN_TLP_SEG_COUNT*4-1:0]                   in_tlp_error,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_valid,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_sop,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_eop,
    output wire                                            in_tlp_ready,

    output wire [TLP_DATA_WIDTH-1:0]                       out_tlp_data,
    output wire [TLP_STRB_WIDTH-1:0]                       out_tlp_strb,
    output wire [OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]      out_tlp_hdr,
    output wire [OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]      out_tlp_seq,
    output wire [OUT_TLP_SEG_COUNT*3-1:0]                  out_tlp_bar_id,
    output wire [OUT_TLP_SEG_COUNT*8-1:0]                  out_tlp_func_num,
    output wire [OUT_TLP_SEG_COUNT*4-1:0]                  out_tlp_error,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_valid,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_sop,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_eop,
    input  wire                                            out_tlp_ready
);

initial begin
    if (DEPTH < 2) begin
        $error("Error: DEPTH must be at least 2 (instance %m)");
        $finish;
    end
    if (TLP_DATA_WIDTH < 32 || TLP_STRB_WIDTH*32 != TLP_DATA_WIDTH) begin
        $error("Error: PCIe interface requires dword (32-bit) granularity (instance %m)");
        $finish;
    end
    if (IN_TLP_SEG_COUNT < 1 || OUT_TLP_SEG_COUNT < 1 ||
            TLP_DATA_WIDTH % IN_TLP_SEG_COUNT != 0 ||
            TLP_DATA_WIDTH % OUT_TLP_SEG_COUNT != 0 ||
            (TLP_DATA_WIDTH/IN_TLP_SEG_COUNT) % 32 != 0 ||
            (TLP_DATA_WIDTH/OUT_TLP_SEG_COUNT) % 32 != 0) begin
        $error("Error: each segment must contain an integral number of dwords (instance %m)");
        $finish;
    end
end

generate
    if (IN_TLP_SEG_COUNT == OUT_TLP_SEG_COUNT) begin : same_segment_count
        pcie_tlp_fifo_raw #(
            .DEPTH(DEPTH),
            .TLP_DATA_WIDTH(TLP_DATA_WIDTH),
            .TLP_STRB_WIDTH(TLP_STRB_WIDTH),
            .TLP_HDR_WIDTH(TLP_HDR_WIDTH),
            .SEQ_NUM_WIDTH(SEQ_NUM_WIDTH),
            .TLP_SEG_COUNT(IN_TLP_SEG_COUNT)
        )
        pcie_tlp_fifo_raw_inst (
            .clk(clk),
            .rst(rst),
            .in_tlp_data(in_tlp_data),
            .in_tlp_strb(in_tlp_strb),
            .in_tlp_hdr(in_tlp_hdr),
            .in_tlp_seq(in_tlp_seq),
            .in_tlp_bar_id(in_tlp_bar_id),
            .in_tlp_func_num(in_tlp_func_num),
            .in_tlp_error(in_tlp_error),
            .in_tlp_valid(in_tlp_valid),
            .in_tlp_sop(in_tlp_sop),
            .in_tlp_eop(in_tlp_eop),
            .in_tlp_ready(in_tlp_ready),
            .out_tlp_data(out_tlp_data),
            .out_tlp_strb(out_tlp_strb),
            .out_tlp_hdr(out_tlp_hdr),
            .out_tlp_seq(out_tlp_seq),
            .out_tlp_bar_id(out_tlp_bar_id),
            .out_tlp_func_num(out_tlp_func_num),
            .out_tlp_error(out_tlp_error),
            .out_tlp_valid(out_tlp_valid),
            .out_tlp_sop(out_tlp_sop),
            .out_tlp_eop(out_tlp_eop),
            .out_tlp_ready(out_tlp_ready)
        );
    end else begin : convert_segment_count
        pcie_tlp_fifo_convert #(
            .DEPTH(DEPTH),
            .TLP_DATA_WIDTH(TLP_DATA_WIDTH),
            .TLP_STRB_WIDTH(TLP_STRB_WIDTH),
            .TLP_HDR_WIDTH(TLP_HDR_WIDTH),
            .SEQ_NUM_WIDTH(SEQ_NUM_WIDTH),
            .IN_TLP_SEG_COUNT(IN_TLP_SEG_COUNT),
            .OUT_TLP_SEG_COUNT(OUT_TLP_SEG_COUNT)
        )
        pcie_tlp_fifo_convert_inst (
            .clk(clk),
            .rst(rst),
            .in_tlp_data(in_tlp_data),
            .in_tlp_strb(in_tlp_strb),
            .in_tlp_hdr(in_tlp_hdr),
            .in_tlp_seq(in_tlp_seq),
            .in_tlp_bar_id(in_tlp_bar_id),
            .in_tlp_func_num(in_tlp_func_num),
            .in_tlp_error(in_tlp_error),
            .in_tlp_valid(in_tlp_valid),
            .in_tlp_sop(in_tlp_sop),
            .in_tlp_eop(in_tlp_eop),
            .in_tlp_ready(in_tlp_ready),
            .out_tlp_data(out_tlp_data),
            .out_tlp_strb(out_tlp_strb),
            .out_tlp_hdr(out_tlp_hdr),
            .out_tlp_seq(out_tlp_seq),
            .out_tlp_bar_id(out_tlp_bar_id),
            .out_tlp_func_num(out_tlp_func_num),
            .out_tlp_error(out_tlp_error),
            .out_tlp_valid(out_tlp_valid),
            .out_tlp_sop(out_tlp_sop),
            .out_tlp_eop(out_tlp_eop),
            .out_tlp_ready(out_tlp_ready)
        );
    end
endgenerate

endmodule

/*
 * Segment count converter.  Valid input segments are divided into chunks of
 * the greatest common divisor of the input and output segment widths.  The
 * output assembler joins chunks only within one TLP, so SOP/EOP boundaries
 * are never merged across packets.
 */
module pcie_tlp_fifo_convert #
(
    parameter DEPTH = 4096,
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter SEQ_NUM_WIDTH = 6,
    parameter IN_TLP_SEG_COUNT = 1,
    parameter OUT_TLP_SEG_COUNT = 2
)
(
    input  wire                                            clk,
    input  wire                                            rst,

    input  wire [TLP_DATA_WIDTH-1:0]                       in_tlp_data,
    input  wire [TLP_STRB_WIDTH-1:0]                       in_tlp_strb,
    input  wire [IN_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]       in_tlp_hdr,
    input  wire [IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]       in_tlp_seq,
    input  wire [IN_TLP_SEG_COUNT*3-1:0]                   in_tlp_bar_id,
    input  wire [IN_TLP_SEG_COUNT*8-1:0]                   in_tlp_func_num,
    input  wire [IN_TLP_SEG_COUNT*4-1:0]                   in_tlp_error,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_valid,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_sop,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_eop,
    output wire                                            in_tlp_ready,

    output wire [TLP_DATA_WIDTH-1:0]                       out_tlp_data,
    output wire [TLP_STRB_WIDTH-1:0]                       out_tlp_strb,
    output wire [OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]      out_tlp_hdr,
    output wire [OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]      out_tlp_seq,
    output wire [OUT_TLP_SEG_COUNT*3-1:0]                  out_tlp_bar_id,
    output wire [OUT_TLP_SEG_COUNT*8-1:0]                  out_tlp_func_num,
    output wire [OUT_TLP_SEG_COUNT*4-1:0]                  out_tlp_error,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_valid,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_sop,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_eop,
    input  wire                                            out_tlp_ready
);

function integer gcd;
    input integer a;
    input integer b;
    integer temp;
    begin
        while (b != 0) begin
            temp = a % b;
            a = b;
            b = temp;
        end
        gcd = a;
    end
endfunction

localparam IN_SEG_DATA_WIDTH = TLP_DATA_WIDTH/IN_TLP_SEG_COUNT;
localparam OUT_SEG_DATA_WIDTH = TLP_DATA_WIDTH/OUT_TLP_SEG_COUNT;
localparam CHUNK_DATA_WIDTH = gcd(IN_SEG_DATA_WIDTH, OUT_SEG_DATA_WIDTH);
localparam IN_CHUNKS = IN_SEG_DATA_WIDTH/CHUNK_DATA_WIDTH;
localparam OUT_CHUNKS = OUT_SEG_DATA_WIDTH/CHUNK_DATA_WIDTH;
localparam IN_SEG_STRB_WIDTH = IN_SEG_DATA_WIDTH/32;
localparam OUT_SEG_STRB_WIDTH = OUT_SEG_DATA_WIDTH/32;
localparam CHUNK_STRB_WIDTH = CHUNK_DATA_WIDTH/32;
localparam MAX_PUSH = IN_TLP_SEG_COUNT*IN_CHUNKS;
localparam PTR_WIDTH = $clog2(DEPTH);
localparam COUNT_WIDTH = $clog2(DEPTH+1);

reg [CHUNK_DATA_WIDTH-1:0] data_mem[DEPTH-1:0];
reg [CHUNK_STRB_WIDTH-1:0] strb_mem[DEPTH-1:0];
reg [TLP_HDR_WIDTH-1:0] hdr_mem[DEPTH-1:0];
reg [SEQ_NUM_WIDTH-1:0] seq_mem[DEPTH-1:0];
reg [2:0] bar_id_mem[DEPTH-1:0];
reg [7:0] func_num_mem[DEPTH-1:0];
reg [3:0] error_mem[DEPTH-1:0];
reg sop_mem[DEPTH-1:0];
reg eop_mem[DEPTH-1:0];

reg [PTR_WIDTH-1:0] wr_ptr_reg = 0;
reg [PTR_WIDTH-1:0] rd_ptr_reg = 0;
reg [COUNT_WIDTH-1:0] count_reg = 0;

reg [CHUNK_DATA_WIDTH-1:0] push_data[MAX_PUSH-1:0];
reg [CHUNK_STRB_WIDTH-1:0] push_strb[MAX_PUSH-1:0];
reg [TLP_HDR_WIDTH-1:0] push_hdr[MAX_PUSH-1:0];
reg [SEQ_NUM_WIDTH-1:0] push_seq[MAX_PUSH-1:0];
reg [2:0] push_bar_id[MAX_PUSH-1:0];
reg [7:0] push_func_num[MAX_PUSH-1:0];
reg [3:0] push_error[MAX_PUSH-1:0];
reg push_sop[MAX_PUSH-1:0];
reg push_eop[MAX_PUSH-1:0];
reg [COUNT_WIDTH-1:0] push_count;

reg [TLP_DATA_WIDTH-1:0] out_tlp_data_reg = 0;
reg [TLP_STRB_WIDTH-1:0] out_tlp_strb_reg = 0;
reg [OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0] out_tlp_hdr_reg = 0;
reg [OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0] out_tlp_seq_reg = 0;
reg [OUT_TLP_SEG_COUNT*3-1:0] out_tlp_bar_id_reg = 0;
reg [OUT_TLP_SEG_COUNT*8-1:0] out_tlp_func_num_reg = 0;
reg [OUT_TLP_SEG_COUNT*4-1:0] out_tlp_error_reg = 0;
reg [OUT_TLP_SEG_COUNT-1:0] out_tlp_valid_reg = 0;
reg [OUT_TLP_SEG_COUNT-1:0] out_tlp_sop_reg = 0;
reg [OUT_TLP_SEG_COUNT-1:0] out_tlp_eop_reg = 0;

reg [TLP_DATA_WIDTH-1:0] out_tlp_data_next;
reg [TLP_STRB_WIDTH-1:0] out_tlp_strb_next;
reg [OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0] out_tlp_hdr_next;
reg [OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0] out_tlp_seq_next;
reg [OUT_TLP_SEG_COUNT*3-1:0] out_tlp_bar_id_next;
reg [OUT_TLP_SEG_COUNT*8-1:0] out_tlp_func_num_next;
reg [OUT_TLP_SEG_COUNT*4-1:0] out_tlp_error_next;
reg [OUT_TLP_SEG_COUNT-1:0] out_tlp_valid_next;
reg [OUT_TLP_SEG_COUNT-1:0] out_tlp_sop_next;
reg [OUT_TLP_SEG_COUNT-1:0] out_tlp_eop_next;
reg [COUNT_WIDTH-1:0] pop_count;

integer i;
integer j;
integer k;
integer a;
integer b;
integer seg_chunks;
integer out_offset;
integer lane_start;
integer lane_chunks;
reg lane_done;
reg assembling;

function [PTR_WIDTH-1:0] wrapped_ptr;
    input integer value;
    begin
        if (value >= DEPTH) begin
            wrapped_ptr = value-DEPTH;
        end else begin
            wrapped_ptr = value;
        end
    end
endfunction

assign in_tlp_ready = !rst && count_reg <= DEPTH-MAX_PUSH;

assign out_tlp_data = out_tlp_data_reg;
assign out_tlp_strb = out_tlp_strb_reg;
assign out_tlp_hdr = out_tlp_hdr_reg;
assign out_tlp_seq = out_tlp_seq_reg;
assign out_tlp_bar_id = out_tlp_bar_id_reg;
assign out_tlp_func_num = out_tlp_func_num_reg;
assign out_tlp_error = out_tlp_error_reg;
assign out_tlp_valid = out_tlp_valid_reg;
assign out_tlp_sop = out_tlp_sop_reg;
assign out_tlp_eop = out_tlp_eop_reg;

/* Build the ordered list of chunks accepted from the current input beat. */
always @* begin
    push_count = 0;
    seg_chunks = 1;
    for (a = 0; a < MAX_PUSH; a = a + 1) begin
        push_data[a] = 0;
        push_strb[a] = 0;
        push_hdr[a] = 0;
        push_seq[a] = 0;
        push_bar_id[a] = 0;
        push_func_num[a] = 0;
        push_error[a] = 0;
        push_sop[a] = 0;
        push_eop[a] = 0;
    end

    for (a = 0; a < IN_TLP_SEG_COUNT; a = a + 1) begin
        if (in_tlp_valid[a]) begin
            seg_chunks = 1;
            for (b = CHUNK_STRB_WIDTH; b < IN_SEG_STRB_WIDTH; b = b + 1) begin
                if (in_tlp_strb[a*IN_SEG_STRB_WIDTH+b]) begin
                    seg_chunks = b/CHUNK_STRB_WIDTH+1;
                end
            end
            for (b = 0; b < IN_CHUNKS; b = b + 1) begin
                if (b < seg_chunks) begin
                    push_data[push_count] = in_tlp_data[a*IN_SEG_DATA_WIDTH+b*CHUNK_DATA_WIDTH +: CHUNK_DATA_WIDTH];
                    push_strb[push_count] = in_tlp_strb[a*IN_SEG_STRB_WIDTH+b*CHUNK_STRB_WIDTH +: CHUNK_STRB_WIDTH];
                    push_hdr[push_count] = in_tlp_hdr[a*TLP_HDR_WIDTH +: TLP_HDR_WIDTH];
                    push_seq[push_count] = in_tlp_seq[a*SEQ_NUM_WIDTH +: SEQ_NUM_WIDTH];
                    push_bar_id[push_count] = in_tlp_bar_id[a*3 +: 3];
                    push_func_num[push_count] = in_tlp_func_num[a*8 +: 8];
                    push_error[push_count] = in_tlp_error[a*4 +: 4];
                    push_sop[push_count] = in_tlp_sop[a] && b == 0;
                    push_eop[push_count] = in_tlp_eop[a] && b == seg_chunks-1;
                    push_count = push_count + 1'b1;
                end
            end
        end
    end
end

/* Assemble as many complete output segments as the queued chunks permit. */
always @* begin
    out_tlp_data_next = 0;
    out_tlp_strb_next = 0;
    out_tlp_hdr_next = 0;
    out_tlp_seq_next = 0;
    out_tlp_bar_id_next = 0;
    out_tlp_func_num_next = 0;
    out_tlp_error_next = 0;
    out_tlp_valid_next = 0;
    out_tlp_sop_next = 0;
    out_tlp_eop_next = 0;

    out_offset = 0;
    lane_start = 0;
    lane_chunks = 0;
    lane_done = 0;
    assembling = 1;

    for (i = 0; i < OUT_TLP_SEG_COUNT; i = i + 1) begin
        lane_start = out_offset;
        lane_chunks = 0;
        lane_done = 0;
        if (assembling && out_offset < count_reg) begin
            for (j = 0; j < OUT_CHUNKS; j = j + 1) begin
                if (!lane_done && out_offset < count_reg) begin
                    if (lane_chunks > 0 && sop_mem[wrapped_ptr(rd_ptr_reg+out_offset)]) begin
                        lane_done = 1;
                    end else begin
                        if (lane_chunks == 0) begin
                            out_tlp_hdr_next[i*TLP_HDR_WIDTH +: TLP_HDR_WIDTH] = hdr_mem[wrapped_ptr(rd_ptr_reg+out_offset)];
                            out_tlp_seq_next[i*SEQ_NUM_WIDTH +: SEQ_NUM_WIDTH] = seq_mem[wrapped_ptr(rd_ptr_reg+out_offset)];
                            out_tlp_bar_id_next[i*3 +: 3] = bar_id_mem[wrapped_ptr(rd_ptr_reg+out_offset)];
                            out_tlp_func_num_next[i*8 +: 8] = func_num_mem[wrapped_ptr(rd_ptr_reg+out_offset)];
                            out_tlp_error_next[i*4 +: 4] = error_mem[wrapped_ptr(rd_ptr_reg+out_offset)];
                        end
                        out_tlp_data_next[i*OUT_SEG_DATA_WIDTH+lane_chunks*CHUNK_DATA_WIDTH +: CHUNK_DATA_WIDTH] = data_mem[wrapped_ptr(rd_ptr_reg+out_offset)];
                        out_tlp_strb_next[i*OUT_SEG_STRB_WIDTH+lane_chunks*CHUNK_STRB_WIDTH +: CHUNK_STRB_WIDTH] = strb_mem[wrapped_ptr(rd_ptr_reg+out_offset)];
                        out_tlp_sop_next[i] = out_tlp_sop_next[i] | sop_mem[wrapped_ptr(rd_ptr_reg+out_offset)];
                        out_tlp_eop_next[i] = out_tlp_eop_next[i] | eop_mem[wrapped_ptr(rd_ptr_reg+out_offset)];
                        out_offset = out_offset + 1;
                        lane_chunks = lane_chunks + 1;
                        if (eop_mem[wrapped_ptr(rd_ptr_reg+out_offset-1)] || lane_chunks == OUT_CHUNKS) begin
                            lane_done = 1;
                        end
                    end
                end
            end
            if (lane_done) begin
                out_tlp_valid_next[i] = 1'b1;
            end else begin
                out_offset = lane_start;
                assembling = 0;
            end
        end
    end
    pop_count = out_offset;
end

wire write = in_tlp_valid != 0 && in_tlp_ready;
wire load_output = out_tlp_ready || out_tlp_valid_reg == 0;
wire read = count_reg != 0 && load_output && pop_count != 0;

always @(posedge clk) begin
    if (write) begin
        for (k = 0; k < MAX_PUSH; k = k + 1) begin
            if (k < push_count) begin
                data_mem[wrapped_ptr(wr_ptr_reg+k)] <= push_data[k];
                strb_mem[wrapped_ptr(wr_ptr_reg+k)] <= push_strb[k];
                hdr_mem[wrapped_ptr(wr_ptr_reg+k)] <= push_hdr[k];
                seq_mem[wrapped_ptr(wr_ptr_reg+k)] <= push_seq[k];
                bar_id_mem[wrapped_ptr(wr_ptr_reg+k)] <= push_bar_id[k];
                func_num_mem[wrapped_ptr(wr_ptr_reg+k)] <= push_func_num[k];
                error_mem[wrapped_ptr(wr_ptr_reg+k)] <= push_error[k];
                sop_mem[wrapped_ptr(wr_ptr_reg+k)] <= push_sop[k];
                eop_mem[wrapped_ptr(wr_ptr_reg+k)] <= push_eop[k];
            end
        end
        if (wr_ptr_reg+push_count >= DEPTH) begin
            wr_ptr_reg <= wr_ptr_reg+push_count-DEPTH;
        end else begin
            wr_ptr_reg <= wr_ptr_reg+push_count;
        end
    end

    if (load_output) begin
        out_tlp_data_reg <= out_tlp_data_next;
        out_tlp_strb_reg <= out_tlp_strb_next;
        out_tlp_hdr_reg <= out_tlp_hdr_next;
        out_tlp_seq_reg <= out_tlp_seq_next;
        out_tlp_bar_id_reg <= out_tlp_bar_id_next;
        out_tlp_func_num_reg <= out_tlp_func_num_next;
        out_tlp_error_reg <= out_tlp_error_next;
        out_tlp_valid_reg <= out_tlp_valid_next;
        out_tlp_sop_reg <= out_tlp_sop_next;
        out_tlp_eop_reg <= out_tlp_eop_next;
    end

    if (read) begin
        if (rd_ptr_reg+pop_count >= DEPTH) begin
            rd_ptr_reg <= rd_ptr_reg+pop_count-DEPTH;
        end else begin
            rd_ptr_reg <= rd_ptr_reg+pop_count;
        end
    end

    case ({write, read})
        2'b10: count_reg <= count_reg+push_count;
        2'b01: count_reg <= count_reg-pop_count;
        2'b11: count_reg <= count_reg+push_count-pop_count;
        default: count_reg <= count_reg;
    endcase

    if (rst) begin
        wr_ptr_reg <= 0;
        rd_ptr_reg <= 0;
        count_reg <= 0;
        out_tlp_valid_reg <= 0;
        out_tlp_sop_reg <= 0;
        out_tlp_eop_reg <= 0;
    end
end

endmodule

`resetall
