/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * PCIe TLP demultiplexer
 */
module pcie_tlp_demux #
(
    parameter PORTS = 2,
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter SEQ_NUM_WIDTH = 6,
    parameter TLP_SEG_COUNT = 1
)
(
    input  wire                                          clk,
    input  wire                                          rst,

    input  wire [TLP_DATA_WIDTH-1:0]                     in_tlp_data,
    input  wire [TLP_STRB_WIDTH-1:0]                     in_tlp_strb,
    input  wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]        in_tlp_hdr,
    input  wire [TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]        in_tlp_seq,
    input  wire [TLP_SEG_COUNT*3-1:0]                    in_tlp_bar_id,
    input  wire [TLP_SEG_COUNT*8-1:0]                    in_tlp_func_num,
    input  wire [TLP_SEG_COUNT*4-1:0]                    in_tlp_error,
    input  wire [TLP_SEG_COUNT-1:0]                      in_tlp_valid,
    input  wire [TLP_SEG_COUNT-1:0]                      in_tlp_sop,
    input  wire [TLP_SEG_COUNT-1:0]                      in_tlp_eop,
    output wire                                          in_tlp_ready,

    output wire [PORTS*TLP_DATA_WIDTH-1:0]               out_tlp_data,
    output wire [PORTS*TLP_STRB_WIDTH-1:0]               out_tlp_strb,
    output wire [PORTS*TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]  out_tlp_hdr,
    output wire [PORTS*TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]  out_tlp_seq,
    output wire [PORTS*TLP_SEG_COUNT*3-1:0]              out_tlp_bar_id,
    output wire [PORTS*TLP_SEG_COUNT*8-1:0]              out_tlp_func_num,
    output wire [PORTS*TLP_SEG_COUNT*4-1:0]              out_tlp_error,
    output wire [PORTS*TLP_SEG_COUNT-1:0]                out_tlp_valid,
    output wire [PORTS*TLP_SEG_COUNT-1:0]                out_tlp_sop,
    output wire [PORTS*TLP_SEG_COUNT-1:0]                out_tlp_eop,
    input  wire [PORTS-1:0]                              out_tlp_ready,

    output wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]        match_tlp_hdr,
    output wire [TLP_SEG_COUNT*3-1:0]                    match_tlp_bar_id,
    output wire [TLP_SEG_COUNT*8-1:0]                    match_tlp_func_num,

    input  wire                                          enable,
    input  wire [TLP_SEG_COUNT-1:0]                      drop,
    input  wire [TLP_SEG_COUNT*PORTS-1:0]                select
);

localparam CL_PORTS = $clog2(PORTS);

initial begin
    if (TLP_HDR_WIDTH != 128) begin
        $error("Error: TLP segment header width must be 128 (instance %m)");
        $finish;
    end
    if (TLP_STRB_WIDTH*32 != TLP_DATA_WIDTH) begin
        $error("Error: PCIe interface requires dword (32-bit) granularity (instance %m)");
        $finish;
    end
end

reg [CL_PORTS-1:0] select_reg[TLP_SEG_COUNT-1:0];
reg [CL_PORTS-1:0] select_ctl[TLP_SEG_COUNT-1:0];
reg [CL_PORTS-1:0] select_next[TLP_SEG_COUNT-1:0];
reg [TLP_SEG_COUNT-1:0] drop_reg = 0;
reg [TLP_SEG_COUNT-1:0] drop_ctl;
reg [TLP_SEG_COUNT-1:0] drop_next;
reg [TLP_SEG_COUNT-1:0] frame_reg = 0;
reg [TLP_SEG_COUNT-1:0] frame_ctl;
reg [TLP_SEG_COUNT-1:0] frame_next;

reg [PORTS*TLP_SEG_COUNT-1:0] out_tlp_valid_int;
reg [PORTS-1:0] port_used;
reg route_ready;

reg [TLP_DATA_WIDTH-1:0] out_tlp_data_reg[PORTS-1:0];
reg [TLP_STRB_WIDTH-1:0] out_tlp_strb_reg[PORTS-1:0];
reg [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0] out_tlp_hdr_reg[PORTS-1:0];
reg [TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0] out_tlp_seq_reg[PORTS-1:0];
reg [TLP_SEG_COUNT*3-1:0] out_tlp_bar_id_reg[PORTS-1:0];
reg [TLP_SEG_COUNT*8-1:0] out_tlp_func_num_reg[PORTS-1:0];
reg [TLP_SEG_COUNT*4-1:0] out_tlp_error_reg[PORTS-1:0];
reg [TLP_SEG_COUNT-1:0] out_tlp_valid_reg[PORTS-1:0];
reg [TLP_SEG_COUNT-1:0] out_tlp_sop_reg[PORTS-1:0];
reg [TLP_SEG_COUNT-1:0] out_tlp_eop_reg[PORTS-1:0];

assign match_tlp_hdr = in_tlp_hdr;
assign match_tlp_bar_id = in_tlp_bar_id;
assign match_tlp_func_num = in_tlp_func_num;
assign in_tlp_ready = enable && route_ready && !rst;

integer i;
integer j;
integer k;

initial begin
    for (k = 0; k < TLP_SEG_COUNT; k = k + 1) begin
        select_reg[k] = 0;
    end
    for (k = 0; k < PORTS; k = k + 1) begin
        out_tlp_valid_reg[k] = 0;
    end
end

/* Determine a route for every valid segment.  A route is held until EOP. */
always @* begin
    out_tlp_valid_int = 0;
    port_used = 0;
    drop_next = drop_reg;
    frame_next = frame_reg;

    for (i = 0; i < TLP_SEG_COUNT; i = i + 1) begin
        select_ctl[i] = select_reg[i];
        select_next[i] = select_reg[i];
        drop_ctl[i] = drop_reg[i];
        frame_ctl[i] = frame_reg[i];

        if (!frame_reg[i]) begin
            select_ctl[i] = 0;
            drop_ctl[i] = 1'b1;
            frame_ctl[i] = 1'b1;
            for (j = PORTS-1; j >= 0; j = j - 1) begin
                if (select[i*PORTS+j]) begin
                    select_ctl[i] = j;
                    drop_ctl[i] = 1'b0;
                end
            end
            drop_ctl[i] = drop_ctl[i] | drop[i];
        end

        for (j = 0; j < PORTS; j = j + 1) begin
            out_tlp_valid_int[j*TLP_SEG_COUNT+i] = in_tlp_valid[i] && frame_ctl[i] && !drop_ctl[i] && select_ctl[i] == j;
        end

        if (in_tlp_valid[i] && frame_ctl[i] && !drop_ctl[i]) begin
            port_used[select_ctl[i]] = 1'b1;
        end

        if (in_tlp_ready && in_tlp_valid[i]) begin
            if (in_tlp_eop[i]) begin
                select_next[i] = 0;
                drop_next[i] = 1'b0;
                frame_next[i] = 1'b0;
            end else if (!frame_reg[i]) begin
                select_next[i] = select_ctl[i];
                drop_next[i] = drop_ctl[i];
                frame_next[i] = 1'b1;
            end
        end
    end

    route_ready = 1'b1;
    for (i = 0; i < PORTS; i = i + 1) begin
        if (port_used[i] && out_tlp_valid_reg[i] != 0 && !out_tlp_ready[i]) begin
            route_ready = 1'b0;
        end
    end
end

generate
    genvar n;
    for (n = 0; n < PORTS; n = n + 1) begin : output_registers
        assign out_tlp_data[n*TLP_DATA_WIDTH +: TLP_DATA_WIDTH] = out_tlp_data_reg[n];
        assign out_tlp_strb[n*TLP_STRB_WIDTH +: TLP_STRB_WIDTH] = out_tlp_strb_reg[n];
        assign out_tlp_hdr[n*TLP_SEG_COUNT*TLP_HDR_WIDTH +: TLP_SEG_COUNT*TLP_HDR_WIDTH] = out_tlp_hdr_reg[n];
        assign out_tlp_seq[n*TLP_SEG_COUNT*SEQ_NUM_WIDTH +: TLP_SEG_COUNT*SEQ_NUM_WIDTH] = out_tlp_seq_reg[n];
        assign out_tlp_bar_id[n*TLP_SEG_COUNT*3 +: TLP_SEG_COUNT*3] = out_tlp_bar_id_reg[n];
        assign out_tlp_func_num[n*TLP_SEG_COUNT*8 +: TLP_SEG_COUNT*8] = out_tlp_func_num_reg[n];
        assign out_tlp_error[n*TLP_SEG_COUNT*4 +: TLP_SEG_COUNT*4] = out_tlp_error_reg[n];
        assign out_tlp_valid[n*TLP_SEG_COUNT +: TLP_SEG_COUNT] = out_tlp_valid_reg[n];
        assign out_tlp_sop[n*TLP_SEG_COUNT +: TLP_SEG_COUNT] = out_tlp_sop_reg[n];
        assign out_tlp_eop[n*TLP_SEG_COUNT +: TLP_SEG_COUNT] = out_tlp_eop_reg[n];

        always @(posedge clk) begin
            if (out_tlp_ready[n] || out_tlp_valid_reg[n] == 0) begin
                out_tlp_valid_reg[n] <= 0;
                if (in_tlp_ready && in_tlp_valid != 0) begin
                    out_tlp_data_reg[n] <= in_tlp_data;
                    out_tlp_strb_reg[n] <= in_tlp_strb;
                    out_tlp_hdr_reg[n] <= in_tlp_hdr;
                    out_tlp_seq_reg[n] <= in_tlp_seq;
                    out_tlp_bar_id_reg[n] <= in_tlp_bar_id;
                    out_tlp_func_num_reg[n] <= in_tlp_func_num;
                    out_tlp_error_reg[n] <= in_tlp_error;
                    out_tlp_valid_reg[n] <= out_tlp_valid_int[n*TLP_SEG_COUNT +: TLP_SEG_COUNT];
                    out_tlp_sop_reg[n] <= in_tlp_sop;
                    out_tlp_eop_reg[n] <= in_tlp_eop;
                end
            end

            if (rst) begin
                out_tlp_valid_reg[n] <= 0;
                out_tlp_sop_reg[n] <= 0;
                out_tlp_eop_reg[n] <= 0;
            end
        end
    end
endgenerate

always @(posedge clk) begin
    for (k = 0; k < TLP_SEG_COUNT; k = k + 1) begin
        select_reg[k] <= select_next[k];
    end
    drop_reg <= drop_next;
    frame_reg <= frame_next;

    if (rst) begin
        for (k = 0; k < TLP_SEG_COUNT; k = k + 1) begin
            select_reg[k] <= 0;
        end
        drop_reg <= 0;
        frame_reg <= 0;
    end
end

endmodule

`resetall
