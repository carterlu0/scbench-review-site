/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * PCIe TLP demultiplexer
 */
module pcie_tlp_demux #
(
    parameter PORTS = 2,
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter SEQ_NUM_WIDTH = 6,
    parameter IN_TLP_SEG_COUNT = 1,
    parameter OUT_TLP_SEG_COUNT = IN_TLP_SEG_COUNT,
    parameter FIFO_ENABLE = 0,
    parameter FIFO_DEPTH = 4096,
    parameter FIFO_WATERMARK = FIFO_DEPTH/2
)
(
    input  wire                                                clk,
    input  wire                                                rst,

    input  wire [TLP_DATA_WIDTH-1:0]                           in_tlp_data,
    input  wire [TLP_STRB_WIDTH-1:0]                           in_tlp_strb,
    input  wire [IN_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]           in_tlp_hdr,
    input  wire [IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]           in_tlp_seq,
    input  wire [IN_TLP_SEG_COUNT*3-1:0]                       in_tlp_bar_id,
    input  wire [IN_TLP_SEG_COUNT*8-1:0]                       in_tlp_func_num,
    input  wire [IN_TLP_SEG_COUNT*4-1:0]                       in_tlp_error,
    input  wire [IN_TLP_SEG_COUNT-1:0]                         in_tlp_valid,
    input  wire [IN_TLP_SEG_COUNT-1:0]                         in_tlp_sop,
    input  wire [IN_TLP_SEG_COUNT-1:0]                         in_tlp_eop,
    output wire                                                in_tlp_ready,

    output wire [PORTS*TLP_DATA_WIDTH-1:0]                     out_tlp_data,
    output wire [PORTS*TLP_STRB_WIDTH-1:0]                     out_tlp_strb,
    output wire [PORTS*OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]    out_tlp_hdr,
    output wire [PORTS*OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]    out_tlp_seq,
    output wire [PORTS*OUT_TLP_SEG_COUNT*3-1:0]                out_tlp_bar_id,
    output wire [PORTS*OUT_TLP_SEG_COUNT*8-1:0]                out_tlp_func_num,
    output wire [PORTS*OUT_TLP_SEG_COUNT*4-1:0]                out_tlp_error,
    output wire [PORTS*OUT_TLP_SEG_COUNT-1:0]                  out_tlp_valid,
    output wire [PORTS*OUT_TLP_SEG_COUNT-1:0]                  out_tlp_sop,
    output wire [PORTS*OUT_TLP_SEG_COUNT-1:0]                  out_tlp_eop,
    input  wire [PORTS-1:0]                                    out_tlp_ready,

    output wire [IN_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]           match_tlp_hdr,
    output wire [IN_TLP_SEG_COUNT*3-1:0]                       match_tlp_bar_id,
    output wire [IN_TLP_SEG_COUNT*8-1:0]                       match_tlp_func_num,

    input  wire                                                enable,
    input  wire [IN_TLP_SEG_COUNT-1:0]                         drop,
    input  wire [PORTS*IN_TLP_SEG_COUNT-1:0]                   select,

    output wire [PORTS-1:0]                                    fifo_half_full,
    output wire [PORTS-1:0]                                    fifo_watermark
);

localparam CL_PORTS = PORTS <= 1 ? 1 : $clog2(PORTS);
localparam FIFO_DEPTH_INT = FIFO_ENABLE ? FIFO_DEPTH : 2;
localparam COUNT_WIDTH = $clog2(FIFO_DEPTH_INT+1);

initial begin
    if (PORTS < 1 || IN_TLP_SEG_COUNT < 1 || OUT_TLP_SEG_COUNT < 1) begin
        $error("Error: port and segment counts must be positive (instance %m)");
        $finish;
    end
    if (TLP_STRB_WIDTH*32 != TLP_DATA_WIDTH ||
            TLP_DATA_WIDTH % IN_TLP_SEG_COUNT != 0 ||
            TLP_DATA_WIDTH % OUT_TLP_SEG_COUNT != 0 ||
            (TLP_DATA_WIDTH/IN_TLP_SEG_COUNT) % 32 != 0 ||
            (TLP_DATA_WIDTH/OUT_TLP_SEG_COUNT) % 32 != 0) begin
        $error("Error: each segment must contain an integral number of dwords (instance %m)");
        $finish;
    end
end

reg [CL_PORTS-1:0] select_reg[IN_TLP_SEG_COUNT-1:0];
reg [CL_PORTS-1:0] select_ctl[IN_TLP_SEG_COUNT-1:0];
reg [CL_PORTS-1:0] select_next[IN_TLP_SEG_COUNT-1:0];
reg [IN_TLP_SEG_COUNT-1:0] drop_reg = 0;
reg [IN_TLP_SEG_COUNT-1:0] drop_ctl;
reg [IN_TLP_SEG_COUNT-1:0] drop_next;
reg [IN_TLP_SEG_COUNT-1:0] frame_reg = 0;
reg [IN_TLP_SEG_COUNT-1:0] frame_ctl;
reg [IN_TLP_SEG_COUNT-1:0] frame_next;

reg [PORTS*IN_TLP_SEG_COUNT-1:0] route_valid;
reg [PORTS-1:0] port_used;
reg route_ready;
wire [PORTS-1:0] fifo_in_ready;
wire [PORTS*COUNT_WIDTH-1:0] fifo_count;

assign match_tlp_hdr = in_tlp_hdr;
assign match_tlp_bar_id = in_tlp_bar_id;
assign match_tlp_func_num = in_tlp_func_num;
assign in_tlp_ready = !rst && enable && route_ready;

integer i;
integer j;
integer k;
always @* begin
    route_valid = 0;
    port_used = 0;
    drop_next = drop_reg;
    frame_next = frame_reg;

    for (i = 0; i < IN_TLP_SEG_COUNT; i = i+1) begin
        select_ctl[i] = select_reg[i];
        select_next[i] = select_reg[i];
        drop_ctl[i] = drop_reg[i];
        frame_ctl[i] = frame_reg[i];

        if (!frame_reg[i]) begin
            select_ctl[i] = 0;
            drop_ctl[i] = 1'b1;
            frame_ctl[i] = 1'b1;
            for (j = PORTS-1; j >= 0; j = j-1) begin
                if (select[i*PORTS+j]) begin
                    select_ctl[i] = j;
                    drop_ctl[i] = 1'b0;
                end
            end
            drop_ctl[i] = drop_ctl[i] | drop[i];
        end

        for (j = 0; j < PORTS; j = j+1) begin
            route_valid[j*IN_TLP_SEG_COUNT+i] = in_tlp_valid[i] && frame_ctl[i] &&
                !drop_ctl[i] && select_ctl[i] == j;
        end

        if (in_tlp_valid[i] && frame_ctl[i] && !drop_ctl[i]) begin
            port_used[select_ctl[i]] = 1'b1;
        end

        if (in_tlp_ready && in_tlp_valid[i]) begin
            if (in_tlp_eop[i]) begin
                select_next[i] = 0;
                drop_next[i] = 1'b0;
                frame_next[i] = 1'b0;
            end else if (!frame_reg[i]) begin
                select_next[i] = select_ctl[i];
                drop_next[i] = drop_ctl[i];
                frame_next[i] = 1'b1;
            end
        end
    end

    route_ready = 1'b1;
    for (i = 0; i < PORTS; i = i+1) begin
        if (port_used[i] && !fifo_in_ready[i]) begin
            route_ready = 1'b0;
        end
    end
end

initial begin
    for (k = 0; k < IN_TLP_SEG_COUNT; k = k+1) begin
        select_reg[k] = 0;
    end
end

always @(posedge clk) begin
    for (k = 0; k < IN_TLP_SEG_COUNT; k = k+1) begin
        select_reg[k] <= select_next[k];
    end
    drop_reg <= drop_next;
    frame_reg <= frame_next;
    if (rst) begin
        for (k = 0; k < IN_TLP_SEG_COUNT; k = k+1) begin
            select_reg[k] <= 0;
        end
        drop_reg <= 0;
        frame_reg <= 0;
    end
end

genvar n;
generate
    for (n = 0; n < PORTS; n = n+1) begin : output_fifos
        wire [IN_TLP_SEG_COUNT-1:0] fifo_valid;
        assign fifo_valid = route_valid[n*IN_TLP_SEG_COUNT +: IN_TLP_SEG_COUNT] &
            {IN_TLP_SEG_COUNT{in_tlp_ready}};

        if (!FIFO_ENABLE && IN_TLP_SEG_COUNT == OUT_TLP_SEG_COUNT) begin : direct
            reg [TLP_DATA_WIDTH-1:0] data_reg = 0;
            reg [TLP_STRB_WIDTH-1:0] strb_reg = 0;
            reg [IN_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0] hdr_reg = 0;
            reg [IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0] seq_reg = 0;
            reg [IN_TLP_SEG_COUNT*3-1:0] bar_id_reg = 0;
            reg [IN_TLP_SEG_COUNT*8-1:0] func_num_reg = 0;
            reg [IN_TLP_SEG_COUNT*4-1:0] error_reg = 0;
            reg [IN_TLP_SEG_COUNT-1:0] valid_reg = 0;
            reg [IN_TLP_SEG_COUNT-1:0] sop_reg = 0;
            reg [IN_TLP_SEG_COUNT-1:0] eop_reg = 0;

            assign fifo_in_ready[n] = out_tlp_ready[n] || valid_reg == 0;
            assign fifo_count[n*COUNT_WIDTH +: COUNT_WIDTH] = 0;
            assign out_tlp_data[n*TLP_DATA_WIDTH +: TLP_DATA_WIDTH] = data_reg;
            assign out_tlp_strb[n*TLP_STRB_WIDTH +: TLP_STRB_WIDTH] = strb_reg;
            assign out_tlp_hdr[n*IN_TLP_SEG_COUNT*TLP_HDR_WIDTH +: IN_TLP_SEG_COUNT*TLP_HDR_WIDTH] = hdr_reg;
            assign out_tlp_seq[n*IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH +: IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH] = seq_reg;
            assign out_tlp_bar_id[n*IN_TLP_SEG_COUNT*3 +: IN_TLP_SEG_COUNT*3] = bar_id_reg;
            assign out_tlp_func_num[n*IN_TLP_SEG_COUNT*8 +: IN_TLP_SEG_COUNT*8] = func_num_reg;
            assign out_tlp_error[n*IN_TLP_SEG_COUNT*4 +: IN_TLP_SEG_COUNT*4] = error_reg;
            assign out_tlp_valid[n*IN_TLP_SEG_COUNT +: IN_TLP_SEG_COUNT] = valid_reg;
            assign out_tlp_sop[n*IN_TLP_SEG_COUNT +: IN_TLP_SEG_COUNT] = sop_reg;
            assign out_tlp_eop[n*IN_TLP_SEG_COUNT +: IN_TLP_SEG_COUNT] = eop_reg;

            always @(posedge clk) begin
                if (out_tlp_ready[n] || valid_reg == 0) begin
                    valid_reg <= 0;
                    sop_reg <= 0;
                    eop_reg <= 0;
                    if (in_tlp_ready) begin
                        data_reg <= in_tlp_data;
                        strb_reg <= in_tlp_strb;
                        hdr_reg <= in_tlp_hdr;
                        seq_reg <= in_tlp_seq;
                        bar_id_reg <= in_tlp_bar_id;
                        func_num_reg <= in_tlp_func_num;
                        error_reg <= in_tlp_error;
                        valid_reg <= fifo_valid;
                        sop_reg <= in_tlp_sop;
                        eop_reg <= in_tlp_eop;
                    end
                end
                if (rst) begin
                    valid_reg <= 0;
                    sop_reg <= 0;
                    eop_reg <= 0;
                end
            end
        end else begin : buffered
            pcie_tlp_fifo #(
                .DEPTH(FIFO_DEPTH_INT),
                .TLP_DATA_WIDTH(TLP_DATA_WIDTH),
                .TLP_STRB_WIDTH(TLP_STRB_WIDTH),
                .TLP_HDR_WIDTH(TLP_HDR_WIDTH),
                .SEQ_NUM_WIDTH(SEQ_NUM_WIDTH),
                .IN_TLP_SEG_COUNT(IN_TLP_SEG_COUNT),
                .OUT_TLP_SEG_COUNT(OUT_TLP_SEG_COUNT)
            ) fifo_inst (
                .clk(clk), .rst(rst),
                .in_tlp_data(in_tlp_data), .in_tlp_strb(in_tlp_strb),
                .in_tlp_hdr(in_tlp_hdr), .in_tlp_seq(in_tlp_seq),
                .in_tlp_bar_id(in_tlp_bar_id), .in_tlp_func_num(in_tlp_func_num),
                .in_tlp_error(in_tlp_error), .in_tlp_valid(fifo_valid),
                .in_tlp_sop(in_tlp_sop), .in_tlp_eop(in_tlp_eop),
                .in_tlp_ready(fifo_in_ready[n]),
                .out_tlp_data(out_tlp_data[n*TLP_DATA_WIDTH +: TLP_DATA_WIDTH]),
                .out_tlp_strb(out_tlp_strb[n*TLP_STRB_WIDTH +: TLP_STRB_WIDTH]),
                .out_tlp_hdr(out_tlp_hdr[n*OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH +: OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH]),
                .out_tlp_seq(out_tlp_seq[n*OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH +: OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH]),
                .out_tlp_bar_id(out_tlp_bar_id[n*OUT_TLP_SEG_COUNT*3 +: OUT_TLP_SEG_COUNT*3]),
                .out_tlp_func_num(out_tlp_func_num[n*OUT_TLP_SEG_COUNT*8 +: OUT_TLP_SEG_COUNT*8]),
                .out_tlp_error(out_tlp_error[n*OUT_TLP_SEG_COUNT*4 +: OUT_TLP_SEG_COUNT*4]),
                .out_tlp_valid(out_tlp_valid[n*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT]),
                .out_tlp_sop(out_tlp_sop[n*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT]),
                .out_tlp_eop(out_tlp_eop[n*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT]),
                .out_tlp_ready(out_tlp_ready[n]),
                .status_count(fifo_count[n*COUNT_WIDTH +: COUNT_WIDTH])
            );
        end

        assign fifo_half_full[n] = FIFO_ENABLE &&
            fifo_count[n*COUNT_WIDTH +: COUNT_WIDTH] >= FIFO_DEPTH_INT/2;
        assign fifo_watermark[n] = FIFO_ENABLE && FIFO_WATERMARK > 0 &&
            fifo_count[n*COUNT_WIDTH +: COUNT_WIDTH] >= FIFO_WATERMARK;
    end
endgenerate

endmodule

`resetall
