/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * PCIe TLP FIFO with independent input and output segment counts
 */
module pcie_tlp_fifo #
(
    parameter DEPTH = 4096,
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter SEQ_NUM_WIDTH = 6,
    parameter IN_TLP_SEG_COUNT = 1,
    parameter OUT_TLP_SEG_COUNT = IN_TLP_SEG_COUNT
)
(
    input  wire                                            clk,
    input  wire                                            rst,

    input  wire [TLP_DATA_WIDTH-1:0]                       in_tlp_data,
    input  wire [TLP_STRB_WIDTH-1:0]                       in_tlp_strb,
    input  wire [IN_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]       in_tlp_hdr,
    input  wire [IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]       in_tlp_seq,
    input  wire [IN_TLP_SEG_COUNT*3-1:0]                   in_tlp_bar_id,
    input  wire [IN_TLP_SEG_COUNT*8-1:0]                   in_tlp_func_num,
    input  wire [IN_TLP_SEG_COUNT*4-1:0]                   in_tlp_error,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_valid,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_sop,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_eop,
    output wire                                            in_tlp_ready,

    output wire [TLP_DATA_WIDTH-1:0]                       out_tlp_data,
    output wire [TLP_STRB_WIDTH-1:0]                       out_tlp_strb,
    output wire [OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]      out_tlp_hdr,
    output wire [OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]      out_tlp_seq,
    output wire [OUT_TLP_SEG_COUNT*3-1:0]                  out_tlp_bar_id,
    output wire [OUT_TLP_SEG_COUNT*8-1:0]                  out_tlp_func_num,
    output wire [OUT_TLP_SEG_COUNT*4-1:0]                  out_tlp_error,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_valid,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_sop,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_eop,
    input  wire                                            out_tlp_ready,

    output wire [$clog2(DEPTH+1)-1:0]                      status_count
);

initial begin
    if (DEPTH < 2) begin
        $error("Error: DEPTH must be at least 2 (instance %m)");
        $finish;
    end
    if (TLP_DATA_WIDTH < 32 || TLP_STRB_WIDTH*32 != TLP_DATA_WIDTH) begin
        $error("Error: PCIe interface requires dword granularity (instance %m)");
        $finish;
    end
    if (IN_TLP_SEG_COUNT < 1 || OUT_TLP_SEG_COUNT < 1 ||
            TLP_DATA_WIDTH % IN_TLP_SEG_COUNT != 0 ||
            TLP_DATA_WIDTH % OUT_TLP_SEG_COUNT != 0 ||
            (TLP_DATA_WIDTH/IN_TLP_SEG_COUNT) % 32 != 0 ||
            (TLP_DATA_WIDTH/OUT_TLP_SEG_COUNT) % 32 != 0) begin
        $error("Error: each segment must contain an integral number of dwords (instance %m)");
        $finish;
    end
end

generate
    if (IN_TLP_SEG_COUNT == OUT_TLP_SEG_COUNT) begin : same_segment_count
        pcie_tlp_fifo_raw #(
            .DEPTH(DEPTH),
            .TLP_DATA_WIDTH(TLP_DATA_WIDTH),
            .TLP_STRB_WIDTH(TLP_STRB_WIDTH),
            .TLP_HDR_WIDTH(TLP_HDR_WIDTH),
            .SEQ_NUM_WIDTH(SEQ_NUM_WIDTH),
            .TLP_SEG_COUNT(IN_TLP_SEG_COUNT)
        ) pcie_tlp_fifo_raw_inst (
            .clk(clk), .rst(rst),
            .in_tlp_data(in_tlp_data), .in_tlp_strb(in_tlp_strb),
            .in_tlp_hdr(in_tlp_hdr), .in_tlp_seq(in_tlp_seq),
            .in_tlp_bar_id(in_tlp_bar_id), .in_tlp_func_num(in_tlp_func_num),
            .in_tlp_error(in_tlp_error), .in_tlp_valid(in_tlp_valid),
            .in_tlp_sop(in_tlp_sop), .in_tlp_eop(in_tlp_eop),
            .in_tlp_ready(in_tlp_ready),
            .out_tlp_data(out_tlp_data), .out_tlp_strb(out_tlp_strb),
            .out_tlp_hdr(out_tlp_hdr), .out_tlp_seq(out_tlp_seq),
            .out_tlp_bar_id(out_tlp_bar_id), .out_tlp_func_num(out_tlp_func_num),
            .out_tlp_error(out_tlp_error), .out_tlp_valid(out_tlp_valid),
            .out_tlp_sop(out_tlp_sop), .out_tlp_eop(out_tlp_eop),
            .out_tlp_ready(out_tlp_ready), .status_count(status_count)
        );
    end else begin : convert_segment_count
        pcie_tlp_fifo_convert #(
            .DEPTH(DEPTH),
            .TLP_DATA_WIDTH(TLP_DATA_WIDTH),
            .TLP_STRB_WIDTH(TLP_STRB_WIDTH),
            .TLP_HDR_WIDTH(TLP_HDR_WIDTH),
            .SEQ_NUM_WIDTH(SEQ_NUM_WIDTH),
            .IN_TLP_SEG_COUNT(IN_TLP_SEG_COUNT),
            .OUT_TLP_SEG_COUNT(OUT_TLP_SEG_COUNT)
        ) pcie_tlp_fifo_convert_inst (
            .clk(clk), .rst(rst),
            .in_tlp_data(in_tlp_data), .in_tlp_strb(in_tlp_strb),
            .in_tlp_hdr(in_tlp_hdr), .in_tlp_seq(in_tlp_seq),
            .in_tlp_bar_id(in_tlp_bar_id), .in_tlp_func_num(in_tlp_func_num),
            .in_tlp_error(in_tlp_error), .in_tlp_valid(in_tlp_valid),
            .in_tlp_sop(in_tlp_sop), .in_tlp_eop(in_tlp_eop),
            .in_tlp_ready(in_tlp_ready),
            .out_tlp_data(out_tlp_data), .out_tlp_strb(out_tlp_strb),
            .out_tlp_hdr(out_tlp_hdr), .out_tlp_seq(out_tlp_seq),
            .out_tlp_bar_id(out_tlp_bar_id), .out_tlp_func_num(out_tlp_func_num),
            .out_tlp_error(out_tlp_error), .out_tlp_valid(out_tlp_valid),
            .out_tlp_sop(out_tlp_sop), .out_tlp_eop(out_tlp_eop),
            .out_tlp_ready(out_tlp_ready), .status_count(status_count)
        );
    end
endgenerate

endmodule

/*
 * Packet-ordered segment count converter.  Each input segment has an
 * independent record FIFO.  The output scheduler locks to one input segment
 * until EOP, preventing concurrent TLPs on different input segments from
 * being interleaved when they are resized into output segment zero.
 */
module pcie_tlp_fifo_convert #
(
    parameter DEPTH = 4096,
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter SEQ_NUM_WIDTH = 6,
    parameter IN_TLP_SEG_COUNT = 1,
    parameter OUT_TLP_SEG_COUNT = 2
)
(
    input  wire                                            clk,
    input  wire                                            rst,

    input  wire [TLP_DATA_WIDTH-1:0]                       in_tlp_data,
    input  wire [TLP_STRB_WIDTH-1:0]                       in_tlp_strb,
    input  wire [IN_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]       in_tlp_hdr,
    input  wire [IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]       in_tlp_seq,
    input  wire [IN_TLP_SEG_COUNT*3-1:0]                   in_tlp_bar_id,
    input  wire [IN_TLP_SEG_COUNT*8-1:0]                   in_tlp_func_num,
    input  wire [IN_TLP_SEG_COUNT*4-1:0]                   in_tlp_error,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_valid,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_sop,
    input  wire [IN_TLP_SEG_COUNT-1:0]                     in_tlp_eop,
    output wire                                            in_tlp_ready,

    output wire [TLP_DATA_WIDTH-1:0]                       out_tlp_data,
    output wire [TLP_STRB_WIDTH-1:0]                       out_tlp_strb,
    output wire [OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]      out_tlp_hdr,
    output wire [OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]      out_tlp_seq,
    output wire [OUT_TLP_SEG_COUNT*3-1:0]                  out_tlp_bar_id,
    output wire [OUT_TLP_SEG_COUNT*8-1:0]                  out_tlp_func_num,
    output wire [OUT_TLP_SEG_COUNT*4-1:0]                  out_tlp_error,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_valid,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_sop,
    output wire [OUT_TLP_SEG_COUNT-1:0]                    out_tlp_eop,
    input  wire                                            out_tlp_ready,

    output wire [$clog2(DEPTH+1)-1:0]                      status_count
);

localparam IN_SEG_DATA_WIDTH = TLP_DATA_WIDTH/IN_TLP_SEG_COUNT;
localparam OUT_SEG_DATA_WIDTH = TLP_DATA_WIDTH/OUT_TLP_SEG_COUNT;
localparam IN_SEG_STRB_WIDTH = IN_SEG_DATA_WIDTH/32;
localparam OUT_SEG_STRB_WIDTH = OUT_SEG_DATA_WIDTH/32;
localparam CL_IN_SEG = IN_TLP_SEG_COUNT <= 1 ? 1 : $clog2(IN_TLP_SEG_COUNT);
localparam COUNT_WIDTH = $clog2(DEPTH+1);
localparam TOKEN_DEPTH = DEPTH*IN_TLP_SEG_COUNT;
localparam TOKEN_PTR_WIDTH = $clog2(TOKEN_DEPTH);
localparam TOKEN_COUNT_WIDTH = $clog2(TOKEN_DEPTH+1);

wire [IN_TLP_SEG_COUNT-1:0] lane_in_ready;
reg [IN_TLP_SEG_COUNT-1:0] lane_out_ready;
wire [TLP_DATA_WIDTH-1:0] lane_data;
wire [TLP_STRB_WIDTH-1:0] lane_strb;
wire [IN_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0] lane_hdr;
wire [IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0] lane_seq;
wire [IN_TLP_SEG_COUNT*3-1:0] lane_bar_id;
wire [IN_TLP_SEG_COUNT*8-1:0] lane_func_num;
wire [IN_TLP_SEG_COUNT*4-1:0] lane_error;
wire [IN_TLP_SEG_COUNT-1:0] lane_valid;
wire [IN_TLP_SEG_COUNT-1:0] lane_sop;
wire [IN_TLP_SEG_COUNT-1:0] lane_eop;
wire [IN_TLP_SEG_COUNT*COUNT_WIDTH-1:0] lane_count;

reg [CL_IN_SEG-1:0] token_mem[TOKEN_DEPTH-1:0];
reg [TOKEN_PTR_WIDTH-1:0] token_wr_ptr_reg = 0;
reg [TOKEN_PTR_WIDTH-1:0] token_rd_ptr_reg = 0;
reg [TOKEN_COUNT_WIDTH-1:0] token_count_reg = 0;
reg [TOKEN_COUNT_WIDTH-1:0] token_push_count;
wire token_push = (in_tlp_valid & in_tlp_sop) != 0 && in_tlp_ready;
wire token_pop;

assign in_tlp_ready = !rst && &lane_in_ready &&
    token_count_reg <= TOKEN_DEPTH-IN_TLP_SEG_COUNT;

genvar g;
generate
    for (g = 0; g < IN_TLP_SEG_COUNT; g = g+1) begin : input_fifos
        pcie_tlp_fifo_raw #(
            .DEPTH(DEPTH),
            .TLP_DATA_WIDTH(IN_SEG_DATA_WIDTH),
            .TLP_STRB_WIDTH(IN_SEG_STRB_WIDTH),
            .TLP_HDR_WIDTH(TLP_HDR_WIDTH),
            .SEQ_NUM_WIDTH(SEQ_NUM_WIDTH),
            .TLP_SEG_COUNT(1)
        ) fifo_inst (
            .clk(clk), .rst(rst),
            .in_tlp_data(in_tlp_data[g*IN_SEG_DATA_WIDTH +: IN_SEG_DATA_WIDTH]),
            .in_tlp_strb(in_tlp_strb[g*IN_SEG_STRB_WIDTH +: IN_SEG_STRB_WIDTH]),
            .in_tlp_hdr(in_tlp_hdr[g*TLP_HDR_WIDTH +: TLP_HDR_WIDTH]),
            .in_tlp_seq(in_tlp_seq[g*SEQ_NUM_WIDTH +: SEQ_NUM_WIDTH]),
            .in_tlp_bar_id(in_tlp_bar_id[g*3 +: 3]),
            .in_tlp_func_num(in_tlp_func_num[g*8 +: 8]),
            .in_tlp_error(in_tlp_error[g*4 +: 4]),
            .in_tlp_valid(in_tlp_valid[g] && in_tlp_ready),
            .in_tlp_sop(in_tlp_sop[g]), .in_tlp_eop(in_tlp_eop[g]),
            .in_tlp_ready(lane_in_ready[g]),
            .out_tlp_data(lane_data[g*IN_SEG_DATA_WIDTH +: IN_SEG_DATA_WIDTH]),
            .out_tlp_strb(lane_strb[g*IN_SEG_STRB_WIDTH +: IN_SEG_STRB_WIDTH]),
            .out_tlp_hdr(lane_hdr[g*TLP_HDR_WIDTH +: TLP_HDR_WIDTH]),
            .out_tlp_seq(lane_seq[g*SEQ_NUM_WIDTH +: SEQ_NUM_WIDTH]),
            .out_tlp_bar_id(lane_bar_id[g*3 +: 3]),
            .out_tlp_func_num(lane_func_num[g*8 +: 8]),
            .out_tlp_error(lane_error[g*4 +: 4]),
            .out_tlp_valid(lane_valid[g]), .out_tlp_sop(lane_sop[g]),
            .out_tlp_eop(lane_eop[g]), .out_tlp_ready(lane_out_ready[g]),
            .status_count(lane_count[g*COUNT_WIDTH +: COUNT_WIDTH])
        );
    end
endgenerate

function [TOKEN_PTR_WIDTH-1:0] wrapped_token_ptr;
    input integer value;
    begin
        if (value >= TOKEN_DEPTH) begin
            wrapped_token_ptr = value-TOKEN_DEPTH;
        end else begin
            wrapped_token_ptr = value;
        end
    end
endfunction

integer token_i;
integer token_write_index;
always @* begin
    token_push_count = 0;
    for (token_i = 0; token_i < IN_TLP_SEG_COUNT; token_i = token_i+1) begin
        if (in_tlp_valid[token_i] && in_tlp_sop[token_i]) begin
            token_push_count = token_push_count+1'b1;
        end
    end
end

always @(posedge clk) begin
    if (token_push) begin
        token_write_index = 0;
        for (token_i = 0; token_i < IN_TLP_SEG_COUNT; token_i = token_i+1) begin
            if (in_tlp_valid[token_i] && in_tlp_sop[token_i]) begin
                token_mem[wrapped_token_ptr(token_wr_ptr_reg+token_write_index)] <= token_i;
                token_write_index = token_write_index+1;
            end
        end
        token_wr_ptr_reg <= wrapped_token_ptr(token_wr_ptr_reg+token_push_count);
    end
    if (token_pop) begin
        token_rd_ptr_reg <= wrapped_token_ptr(token_rd_ptr_reg+1);
    end
    case ({token_push, token_pop})
        2'b10: token_count_reg <= token_count_reg+token_push_count;
        2'b01: token_count_reg <= token_count_reg-1'b1;
        2'b11: token_count_reg <= token_count_reg+token_push_count-1'b1;
        default: token_count_reg <= token_count_reg;
    endcase
    if (rst) begin
        token_wr_ptr_reg <= 0;
        token_rd_ptr_reg <= 0;
        token_count_reg <= 0;
    end
end

reg [COUNT_WIDTH-1:0] max_count;
integer s;
always @* begin
    max_count = 0;
    for (s = 0; s < IN_TLP_SEG_COUNT; s = s+1) begin
        if (lane_count[s*COUNT_WIDTH +: COUNT_WIDTH] > max_count) begin
            max_count = lane_count[s*COUNT_WIDTH +: COUNT_WIDTH];
        end
    end
end
assign status_count = max_count;

reg active_reg = 0;
reg [CL_IN_SEG-1:0] active_lane_reg = 0;
reg [CL_IN_SEG-1:0] current_lane;
reg current_lane_valid;

always @* begin
    current_lane = 0;
    current_lane_valid = 1'b0;
    if (active_reg) begin
        current_lane = active_lane_reg;
        current_lane_valid = 1'b1;
    end else if (token_count_reg != 0) begin
        current_lane = token_mem[token_rd_ptr_reg];
        current_lane_valid = 1'b1;
    end
end

wire [IN_SEG_DATA_WIDTH-1:0] current_data = lane_data[current_lane*IN_SEG_DATA_WIDTH +: IN_SEG_DATA_WIDTH];
wire [IN_SEG_STRB_WIDTH-1:0] current_strb = lane_strb[current_lane*IN_SEG_STRB_WIDTH +: IN_SEG_STRB_WIDTH];
wire [TLP_HDR_WIDTH-1:0] current_hdr = lane_hdr[current_lane*TLP_HDR_WIDTH +: TLP_HDR_WIDTH];
wire [SEQ_NUM_WIDTH-1:0] current_seq = lane_seq[current_lane*SEQ_NUM_WIDTH +: SEQ_NUM_WIDTH];
wire [2:0] current_bar_id = lane_bar_id[current_lane*3 +: 3];
wire [7:0] current_func_num = lane_func_num[current_lane*8 +: 8];
wire [3:0] current_error = lane_error[current_lane*4 +: 4];
wire current_valid = current_lane_valid && lane_valid[current_lane];
wire current_sop = lane_sop[current_lane];
wire current_eop = lane_eop[current_lane];

function integer record_words;
    input [IN_SEG_STRB_WIDTH-1:0] strb;
    integer n;
    begin
        record_words = 0;
        for (n = 0; n < IN_SEG_STRB_WIDTH; n = n+1) begin
            if (strb[n]) begin
                record_words = n+1;
            end
        end
    end
endfunction

reg pop;
reg advance;
assign token_pop = pop && current_eop;
always @* begin
    lane_out_ready = 0;
    if (pop) begin
        lane_out_ready[current_lane] = 1'b1;
    end
end

always @(posedge clk) begin
    if (advance) begin
        if (pop && current_eop) begin
            active_reg <= 1'b0;
        end else begin
            active_reg <= 1'b1;
            active_lane_reg <= current_lane;
        end
    end
    if (rst) begin
        active_reg <= 1'b0;
        active_lane_reg <= 0;
    end
end

reg [TLP_DATA_WIDTH-1:0] out_tlp_data_reg = 0;
reg [TLP_STRB_WIDTH-1:0] out_tlp_strb_reg = 0;
reg [OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0] out_tlp_hdr_reg = 0;
reg [OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0] out_tlp_seq_reg = 0;
reg [OUT_TLP_SEG_COUNT*3-1:0] out_tlp_bar_id_reg = 0;
reg [OUT_TLP_SEG_COUNT*8-1:0] out_tlp_func_num_reg = 0;
reg [OUT_TLP_SEG_COUNT*4-1:0] out_tlp_error_reg = 0;
reg [OUT_TLP_SEG_COUNT-1:0] out_tlp_valid_reg = 0;
reg [OUT_TLP_SEG_COUNT-1:0] out_tlp_sop_reg = 0;
reg [OUT_TLP_SEG_COUNT-1:0] out_tlp_eop_reg = 0;

assign out_tlp_data = out_tlp_data_reg;
assign out_tlp_strb = out_tlp_strb_reg;
assign out_tlp_hdr = out_tlp_hdr_reg;
assign out_tlp_seq = out_tlp_seq_reg;
assign out_tlp_bar_id = out_tlp_bar_id_reg;
assign out_tlp_func_num = out_tlp_func_num_reg;
assign out_tlp_error = out_tlp_error_reg;
assign out_tlp_valid = out_tlp_valid_reg;
assign out_tlp_sop = out_tlp_sop_reg;
assign out_tlp_eop = out_tlp_eop_reg;

generate
    if (IN_SEG_STRB_WIDTH <= OUT_SEG_STRB_WIDTH) begin : widen
        reg [OUT_SEG_DATA_WIDTH-1:0] acc_data = 0;
        reg [OUT_SEG_STRB_WIDTH-1:0] acc_strb = 0;
        reg acc_sop = 0;
        integer acc_count = 0;
        reg [TLP_HDR_WIDTH-1:0] packet_hdr = 0;
        reg [SEQ_NUM_WIDTH-1:0] packet_seq = 0;
        reg [2:0] packet_bar_id = 0;
        reg [7:0] packet_func_num = 0;
        reg [3:0] packet_error = 0;

        reg [OUT_SEG_DATA_WIDTH-1:0] emit_data;
        reg [OUT_SEG_STRB_WIDTH-1:0] emit_strb;
        reg [TLP_HDR_WIDTH-1:0] emit_hdr;
        reg [SEQ_NUM_WIDTH-1:0] emit_seq;
        reg [2:0] emit_bar_id;
        reg [7:0] emit_func_num;
        reg [3:0] emit_error;
        reg emit_sop;
        reg emit_eop;
        reg will_emit;
        integer rec_words;
        integer total_words;
        integer n;

        always @* begin
            pop = 1'b0;
            advance = 1'b0;
            rec_words = current_valid ? record_words(current_strb) : 0;
            total_words = acc_count+rec_words;
            will_emit = current_valid && (current_eop || total_words >= OUT_SEG_STRB_WIDTH);
            emit_data = acc_data;
            emit_strb = acc_strb;
            emit_sop = acc_sop;
            emit_eop = 1'b0;
            emit_hdr = packet_hdr;
            emit_seq = packet_seq;
            emit_bar_id = packet_bar_id;
            emit_func_num = packet_func_num;
            emit_error = packet_error;

            if (current_valid) begin
                if (current_sop) begin
                    emit_hdr = current_hdr;
                    emit_seq = current_seq;
                    emit_bar_id = current_bar_id;
                    emit_func_num = current_func_num;
                    emit_error = current_error;
                end
                if (!rst && (!will_emit || out_tlp_ready || out_tlp_valid_reg == 0)) begin
                    pop = 1'b1;
                    advance = 1'b1;
                    emit_sop = acc_sop | current_sop;
                    emit_eop = current_eop;
                    for (n = 0; n < IN_SEG_STRB_WIDTH; n = n+1) begin
                        if (n < rec_words && acc_count+n < OUT_SEG_STRB_WIDTH) begin
                            emit_data[(acc_count+n)*32 +: 32] = current_data[n*32 +: 32];
                            emit_strb[acc_count+n] = current_strb[n];
                        end
                    end
                end
            end
        end

        always @(posedge clk) begin
            if (out_tlp_valid_reg != 0 && out_tlp_ready) begin
                out_tlp_valid_reg <= 0;
                out_tlp_sop_reg <= 0;
                out_tlp_eop_reg <= 0;
            end
            if (pop) begin
                if (current_sop) begin
                    packet_hdr <= current_hdr;
                    packet_seq <= current_seq;
                    packet_bar_id <= current_bar_id;
                    packet_func_num <= current_func_num;
                    packet_error <= current_error;
                end
                if (will_emit) begin
                    out_tlp_data_reg <= 0;
                    out_tlp_strb_reg <= 0;
                    out_tlp_hdr_reg <= 0;
                    out_tlp_seq_reg <= 0;
                    out_tlp_bar_id_reg <= 0;
                    out_tlp_func_num_reg <= 0;
                    out_tlp_error_reg <= 0;
                    out_tlp_valid_reg <= 0;
                    out_tlp_sop_reg <= 0;
                    out_tlp_eop_reg <= 0;
                    out_tlp_data_reg[0 +: OUT_SEG_DATA_WIDTH] <= emit_data;
                    out_tlp_strb_reg[0 +: OUT_SEG_STRB_WIDTH] <= emit_strb;
                    out_tlp_hdr_reg[0 +: TLP_HDR_WIDTH] <= emit_hdr;
                    out_tlp_seq_reg[0 +: SEQ_NUM_WIDTH] <= emit_seq;
                    out_tlp_bar_id_reg[0 +: 3] <= emit_bar_id;
                    out_tlp_func_num_reg[0 +: 8] <= emit_func_num;
                    out_tlp_error_reg[0 +: 4] <= emit_error;
                    out_tlp_valid_reg[0] <= 1'b1;
                    out_tlp_sop_reg[0] <= emit_sop;
                    out_tlp_eop_reg[0] <= emit_eop;
                    acc_data <= 0;
                    acc_strb <= 0;
                    acc_sop <= 0;
                    acc_count <= 0;
                end else begin
                    acc_data <= emit_data;
                    acc_strb <= emit_strb;
                    acc_sop <= emit_sop;
                    acc_count <= total_words;
                end
            end
            if (rst) begin
                out_tlp_valid_reg <= 0;
                out_tlp_sop_reg <= 0;
                out_tlp_eop_reg <= 0;
                acc_data <= 0;
                acc_strb <= 0;
                acc_sop <= 0;
                acc_count <= 0;
            end
        end
    end else begin : narrow
        integer rd_offset = 0;
        integer rec_words;
        integer take_words;
        reg last_chunk;
        reg generate_output;
        reg [OUT_SEG_DATA_WIDTH-1:0] emit_data;
        reg [OUT_SEG_STRB_WIDTH-1:0] emit_strb;
        integer n;

        always @* begin
            pop = 1'b0;
            advance = 1'b0;
            rec_words = current_valid ? record_words(current_strb) : 0;
            take_words = rec_words-rd_offset;
            if (take_words > OUT_SEG_STRB_WIDTH) begin
                take_words = OUT_SEG_STRB_WIDTH;
            end
            if (take_words < 0) begin
                take_words = 0;
            end
            last_chunk = rd_offset+take_words >= rec_words;
            generate_output = 1'b0;
            emit_data = 0;
            emit_strb = 0;
            if (current_valid && !rst && (out_tlp_ready || out_tlp_valid_reg == 0)) begin
                generate_output = 1'b1;
                advance = 1'b1;
                pop = last_chunk;
                for (n = 0; n < OUT_SEG_STRB_WIDTH; n = n+1) begin
                    if (n < take_words) begin
                        emit_data[n*32 +: 32] = current_data[(rd_offset+n)*32 +: 32];
                        emit_strb[n] = current_strb[rd_offset+n];
                    end
                end
            end
        end

        always @(posedge clk) begin
            if (out_tlp_ready || out_tlp_valid_reg == 0) begin
                out_tlp_valid_reg <= 0;
                out_tlp_sop_reg <= 0;
                out_tlp_eop_reg <= 0;
                if (generate_output) begin
                    out_tlp_data_reg <= 0;
                    out_tlp_strb_reg <= 0;
                    out_tlp_hdr_reg <= 0;
                    out_tlp_seq_reg <= 0;
                    out_tlp_bar_id_reg <= 0;
                    out_tlp_func_num_reg <= 0;
                    out_tlp_error_reg <= 0;
                    out_tlp_data_reg[0 +: OUT_SEG_DATA_WIDTH] <= emit_data;
                    out_tlp_strb_reg[0 +: OUT_SEG_STRB_WIDTH] <= emit_strb;
                    out_tlp_hdr_reg[0 +: TLP_HDR_WIDTH] <= current_hdr;
                    out_tlp_seq_reg[0 +: SEQ_NUM_WIDTH] <= current_seq;
                    out_tlp_bar_id_reg[0 +: 3] <= current_bar_id;
                    out_tlp_func_num_reg[0 +: 8] <= current_func_num;
                    out_tlp_error_reg[0 +: 4] <= current_error;
                    out_tlp_valid_reg[0] <= 1'b1;
                    out_tlp_sop_reg[0] <= current_sop && rd_offset == 0;
                    out_tlp_eop_reg[0] <= current_eop && last_chunk;
                    if (last_chunk) begin
                        rd_offset <= 0;
                    end else begin
                        rd_offset <= rd_offset+take_words;
                    end
                end
            end
            if (rst) begin
                out_tlp_valid_reg <= 0;
                out_tlp_sop_reg <= 0;
                out_tlp_eop_reg <= 0;
                rd_offset <= 0;
            end
        end
    end
endgenerate

endmodule

`resetall
