/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * Buffered PCIe TLP multiplexer
 */
module pcie_tlp_fifo_mux #
(
    parameter PORTS = 2,
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter SEQ_NUM_WIDTH = 6,
    parameter IN_TLP_SEG_COUNT = 1,
    parameter OUT_TLP_SEG_COUNT = IN_TLP_SEG_COUNT,
    parameter ARB_TYPE_ROUND_ROBIN = 0,
    parameter ARB_LSB_HIGH_PRIORITY = 1,
    parameter FIFO_DEPTH = 4096,
    parameter FIFO_WATERMARK = FIFO_DEPTH/2
)
(
    input  wire                                                clk,
    input  wire                                                rst,

    input  wire [PORTS*TLP_DATA_WIDTH-1:0]                     in_tlp_data,
    input  wire [PORTS*TLP_STRB_WIDTH-1:0]                     in_tlp_strb,
    input  wire [PORTS*IN_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]     in_tlp_hdr,
    input  wire [PORTS*IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]     in_tlp_seq,
    input  wire [PORTS*IN_TLP_SEG_COUNT*3-1:0]                 in_tlp_bar_id,
    input  wire [PORTS*IN_TLP_SEG_COUNT*8-1:0]                 in_tlp_func_num,
    input  wire [PORTS*IN_TLP_SEG_COUNT*4-1:0]                 in_tlp_error,
    input  wire [PORTS*IN_TLP_SEG_COUNT-1:0]                   in_tlp_valid,
    input  wire [PORTS*IN_TLP_SEG_COUNT-1:0]                   in_tlp_sop,
    input  wire [PORTS*IN_TLP_SEG_COUNT-1:0]                   in_tlp_eop,
    output wire [PORTS-1:0]                                    in_tlp_ready,

    output wire [TLP_DATA_WIDTH-1:0]                           out_tlp_data,
    output wire [TLP_STRB_WIDTH-1:0]                           out_tlp_strb,
    output wire [OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]          out_tlp_hdr,
    output wire [OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]          out_tlp_seq,
    output wire [OUT_TLP_SEG_COUNT*3-1:0]                      out_tlp_bar_id,
    output wire [OUT_TLP_SEG_COUNT*8-1:0]                      out_tlp_func_num,
    output wire [OUT_TLP_SEG_COUNT*4-1:0]                      out_tlp_error,
    output wire [OUT_TLP_SEG_COUNT-1:0]                        out_tlp_valid,
    output wire [OUT_TLP_SEG_COUNT-1:0]                        out_tlp_sop,
    output wire [OUT_TLP_SEG_COUNT-1:0]                        out_tlp_eop,
    input  wire                                                out_tlp_ready,

    output wire [PORTS*OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]    sel_tlp_seq,
    output wire [PORTS*OUT_TLP_SEG_COUNT-1:0]                  sel_tlp_seq_valid,
    output wire [PORTS-1:0]                                    fifo_half_full,
    output wire [PORTS-1:0]                                    fifo_watermark
);

localparam COUNT_WIDTH = $clog2(FIFO_DEPTH+1);

genvar n;
generate
    for (n = 0; n < PORTS; n = n+1) begin : input_fifos
        wire [COUNT_WIDTH-1:0] count;

        pcie_tlp_fifo #(
            .DEPTH(FIFO_DEPTH),
            .TLP_DATA_WIDTH(TLP_DATA_WIDTH),
            .TLP_STRB_WIDTH(TLP_STRB_WIDTH),
            .TLP_HDR_WIDTH(TLP_HDR_WIDTH),
            .SEQ_NUM_WIDTH(SEQ_NUM_WIDTH),
            .IN_TLP_SEG_COUNT(IN_TLP_SEG_COUNT),
            .OUT_TLP_SEG_COUNT(OUT_TLP_SEG_COUNT)
        ) fifo_inst (
            .clk(clk), .rst(rst),
            .in_tlp_data(in_tlp_data[n*TLP_DATA_WIDTH +: TLP_DATA_WIDTH]),
            .in_tlp_strb(in_tlp_strb[n*TLP_STRB_WIDTH +: TLP_STRB_WIDTH]),
            .in_tlp_hdr(in_tlp_hdr[n*IN_TLP_SEG_COUNT*TLP_HDR_WIDTH +: IN_TLP_SEG_COUNT*TLP_HDR_WIDTH]),
            .in_tlp_seq(in_tlp_seq[n*IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH +: IN_TLP_SEG_COUNT*SEQ_NUM_WIDTH]),
            .in_tlp_bar_id(in_tlp_bar_id[n*IN_TLP_SEG_COUNT*3 +: IN_TLP_SEG_COUNT*3]),
            .in_tlp_func_num(in_tlp_func_num[n*IN_TLP_SEG_COUNT*8 +: IN_TLP_SEG_COUNT*8]),
            .in_tlp_error(in_tlp_error[n*IN_TLP_SEG_COUNT*4 +: IN_TLP_SEG_COUNT*4]),
            .in_tlp_valid(in_tlp_valid[n*IN_TLP_SEG_COUNT +: IN_TLP_SEG_COUNT]),
            .in_tlp_sop(in_tlp_sop[n*IN_TLP_SEG_COUNT +: IN_TLP_SEG_COUNT]),
            .in_tlp_eop(in_tlp_eop[n*IN_TLP_SEG_COUNT +: IN_TLP_SEG_COUNT]),
            .in_tlp_ready(in_tlp_ready[n]),
            .out_tlp_data(mux_in_data[n*TLP_DATA_WIDTH +: TLP_DATA_WIDTH]),
            .out_tlp_strb(mux_in_strb[n*TLP_STRB_WIDTH +: TLP_STRB_WIDTH]),
            .out_tlp_hdr(mux_in_hdr[n*OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH +: OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH]),
            .out_tlp_seq(mux_in_seq[n*OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH +: OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH]),
            .out_tlp_bar_id(mux_in_bar_id[n*OUT_TLP_SEG_COUNT*3 +: OUT_TLP_SEG_COUNT*3]),
            .out_tlp_func_num(mux_in_func_num[n*OUT_TLP_SEG_COUNT*8 +: OUT_TLP_SEG_COUNT*8]),
            .out_tlp_error(mux_in_error[n*OUT_TLP_SEG_COUNT*4 +: OUT_TLP_SEG_COUNT*4]),
            .out_tlp_valid(mux_in_valid[n*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT]),
            .out_tlp_sop(mux_in_sop[n*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT]),
            .out_tlp_eop(mux_in_eop[n*OUT_TLP_SEG_COUNT +: OUT_TLP_SEG_COUNT]),
            .out_tlp_ready(mux_in_ready[n]),
            .status_count(count)
        );

        assign fifo_half_full[n] = count >= FIFO_DEPTH/2;
        assign fifo_watermark[n] = FIFO_WATERMARK > 0 && count >= FIFO_WATERMARK;
    end
endgenerate

wire [PORTS*TLP_DATA_WIDTH-1:0] mux_in_data;
wire [PORTS*TLP_STRB_WIDTH-1:0] mux_in_strb;
wire [PORTS*OUT_TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0] mux_in_hdr;
wire [PORTS*OUT_TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0] mux_in_seq;
wire [PORTS*OUT_TLP_SEG_COUNT*3-1:0] mux_in_bar_id;
wire [PORTS*OUT_TLP_SEG_COUNT*8-1:0] mux_in_func_num;
wire [PORTS*OUT_TLP_SEG_COUNT*4-1:0] mux_in_error;
wire [PORTS*OUT_TLP_SEG_COUNT-1:0] mux_in_valid;
wire [PORTS*OUT_TLP_SEG_COUNT-1:0] mux_in_sop;
wire [PORTS*OUT_TLP_SEG_COUNT-1:0] mux_in_eop;
wire [PORTS-1:0] mux_in_ready;

pcie_tlp_mux #(
    .PORTS(PORTS),
    .TLP_DATA_WIDTH(TLP_DATA_WIDTH),
    .TLP_STRB_WIDTH(TLP_STRB_WIDTH),
    .TLP_HDR_WIDTH(TLP_HDR_WIDTH),
    .SEQ_NUM_WIDTH(SEQ_NUM_WIDTH),
    .TLP_SEG_COUNT(OUT_TLP_SEG_COUNT),
    .ARB_TYPE_ROUND_ROBIN(ARB_TYPE_ROUND_ROBIN),
    .ARB_LSB_HIGH_PRIORITY(ARB_LSB_HIGH_PRIORITY)
) mux_inst (
    .clk(clk), .rst(rst),
    .in_tlp_data(mux_in_data), .in_tlp_strb(mux_in_strb),
    .in_tlp_hdr(mux_in_hdr), .in_tlp_seq(mux_in_seq),
    .in_tlp_bar_id(mux_in_bar_id), .in_tlp_func_num(mux_in_func_num),
    .in_tlp_error(mux_in_error), .in_tlp_valid(mux_in_valid),
    .in_tlp_sop(mux_in_sop), .in_tlp_eop(mux_in_eop),
    .in_tlp_ready(mux_in_ready),
    .out_tlp_data(out_tlp_data), .out_tlp_strb(out_tlp_strb),
    .out_tlp_hdr(out_tlp_hdr), .out_tlp_seq(out_tlp_seq),
    .out_tlp_bar_id(out_tlp_bar_id), .out_tlp_func_num(out_tlp_func_num),
    .out_tlp_error(out_tlp_error), .out_tlp_valid(out_tlp_valid),
    .out_tlp_sop(out_tlp_sop), .out_tlp_eop(out_tlp_eop),
    .out_tlp_ready(out_tlp_ready), .sel_tlp_seq(sel_tlp_seq),
    .sel_tlp_seq_valid(sel_tlp_seq_valid)
);

endmodule

`resetall
