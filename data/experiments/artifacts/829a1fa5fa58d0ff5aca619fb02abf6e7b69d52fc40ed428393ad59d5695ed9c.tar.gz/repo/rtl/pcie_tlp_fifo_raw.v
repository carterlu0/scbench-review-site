/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * PCIe TLP FIFO, raw segmented interface
 */
module pcie_tlp_fifo_raw #
(
    parameter DEPTH = 4096,
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter SEQ_NUM_WIDTH = 6,
    parameter TLP_SEG_COUNT = 1
)
(
    input  wire                                         clk,
    input  wire                                         rst,

    input  wire [TLP_DATA_WIDTH-1:0]                    in_tlp_data,
    input  wire [TLP_STRB_WIDTH-1:0]                    in_tlp_strb,
    input  wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]       in_tlp_hdr,
    input  wire [TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]       in_tlp_seq,
    input  wire [TLP_SEG_COUNT*3-1:0]                   in_tlp_bar_id,
    input  wire [TLP_SEG_COUNT*8-1:0]                   in_tlp_func_num,
    input  wire [TLP_SEG_COUNT*4-1:0]                   in_tlp_error,
    input  wire [TLP_SEG_COUNT-1:0]                     in_tlp_valid,
    input  wire [TLP_SEG_COUNT-1:0]                     in_tlp_sop,
    input  wire [TLP_SEG_COUNT-1:0]                     in_tlp_eop,
    output wire                                         in_tlp_ready,

    output wire [TLP_DATA_WIDTH-1:0]                    out_tlp_data,
    output wire [TLP_STRB_WIDTH-1:0]                    out_tlp_strb,
    output wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]       out_tlp_hdr,
    output wire [TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]       out_tlp_seq,
    output wire [TLP_SEG_COUNT*3-1:0]                   out_tlp_bar_id,
    output wire [TLP_SEG_COUNT*8-1:0]                   out_tlp_func_num,
    output wire [TLP_SEG_COUNT*4-1:0]                   out_tlp_error,
    output wire [TLP_SEG_COUNT-1:0]                     out_tlp_valid,
    output wire [TLP_SEG_COUNT-1:0]                     out_tlp_sop,
    output wire [TLP_SEG_COUNT-1:0]                     out_tlp_eop,
    input  wire                                         out_tlp_ready,

    output wire [$clog2(DEPTH+1)-1:0]                   status_count
);

localparam PTR_WIDTH = $clog2(DEPTH);
localparam COUNT_WIDTH = $clog2(DEPTH+1);
localparam FIFO_WIDTH = TLP_DATA_WIDTH+TLP_STRB_WIDTH+
    TLP_SEG_COUNT*(TLP_HDR_WIDTH+SEQ_NUM_WIDTH+3+8+4+3);

reg [FIFO_WIDTH-1:0] mem[DEPTH-1:0];
reg [PTR_WIDTH-1:0] wr_ptr_reg = 0;
reg [PTR_WIDTH-1:0] rd_ptr_reg = 0;
reg [COUNT_WIDTH-1:0] count_reg = 0;

wire [FIFO_WIDTH-1:0] in_fifo_data;
wire [FIFO_WIDTH-1:0] out_fifo_data;
wire [TLP_SEG_COUNT-1:0] out_fifo_valid;

assign in_fifo_data = {
    in_tlp_data, in_tlp_strb, in_tlp_hdr, in_tlp_seq,
    in_tlp_bar_id, in_tlp_func_num, in_tlp_error,
    in_tlp_valid, in_tlp_sop, in_tlp_eop
};

assign out_fifo_data = mem[rd_ptr_reg];

assign {
    out_tlp_data, out_tlp_strb, out_tlp_hdr, out_tlp_seq,
    out_tlp_bar_id, out_tlp_func_num, out_tlp_error,
    out_fifo_valid, out_tlp_sop, out_tlp_eop
} = out_fifo_data;

assign out_tlp_valid = out_fifo_valid & {TLP_SEG_COUNT{count_reg != 0}};
assign in_tlp_ready = !rst && count_reg < DEPTH;
assign status_count = count_reg;

wire write = in_tlp_valid != 0 && in_tlp_ready;
wire read = out_tlp_valid != 0 && out_tlp_ready;

always @(posedge clk) begin
    if (write) begin
        mem[wr_ptr_reg] <= in_fifo_data;
        if (wr_ptr_reg == DEPTH-1) begin
            wr_ptr_reg <= 0;
        end else begin
            wr_ptr_reg <= wr_ptr_reg + 1'b1;
        end
    end

    if (read) begin
        if (rd_ptr_reg == DEPTH-1) begin
            rd_ptr_reg <= 0;
        end else begin
            rd_ptr_reg <= rd_ptr_reg + 1'b1;
        end
    end

    case ({write, read})
        2'b10: count_reg <= count_reg + 1'b1;
        2'b01: count_reg <= count_reg - 1'b1;
        default: count_reg <= count_reg;
    endcase

    if (rst) begin
        wr_ptr_reg <= 0;
        rd_ptr_reg <= 0;
        count_reg <= 0;
    end
end

endmodule

`resetall
