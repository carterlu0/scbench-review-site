/*

Copyright (c) 2021 Alex Forencich

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

*/

// Language: Verilog 2001

`resetall
`timescale 1ns / 1ps
`default_nettype none

/*
 * PCIe TLP multiplexer
 */
module pcie_tlp_mux #
(
    parameter PORTS = 2,
    parameter TLP_DATA_WIDTH = 256,
    parameter TLP_STRB_WIDTH = TLP_DATA_WIDTH/32,
    parameter TLP_HDR_WIDTH = 128,
    parameter SEQ_NUM_WIDTH = 6,
    parameter TLP_SEG_COUNT = 1,
    parameter ARB_TYPE_ROUND_ROBIN = 0,
    parameter ARB_LSB_HIGH_PRIORITY = 1
)
(
    input  wire                                          clk,
    input  wire                                          rst,

    input  wire [PORTS*TLP_DATA_WIDTH-1:0]               in_tlp_data,
    input  wire [PORTS*TLP_STRB_WIDTH-1:0]               in_tlp_strb,
    input  wire [PORTS*TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]  in_tlp_hdr,
    input  wire [PORTS*TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]  in_tlp_seq,
    input  wire [PORTS*TLP_SEG_COUNT*3-1:0]              in_tlp_bar_id,
    input  wire [PORTS*TLP_SEG_COUNT*8-1:0]              in_tlp_func_num,
    input  wire [PORTS*TLP_SEG_COUNT*4-1:0]              in_tlp_error,
    input  wire [PORTS*TLP_SEG_COUNT-1:0]                in_tlp_valid,
    input  wire [PORTS*TLP_SEG_COUNT-1:0]                in_tlp_sop,
    input  wire [PORTS*TLP_SEG_COUNT-1:0]                in_tlp_eop,
    output reg  [PORTS-1:0]                              in_tlp_ready,

    output wire [TLP_DATA_WIDTH-1:0]                     out_tlp_data,
    output wire [TLP_STRB_WIDTH-1:0]                     out_tlp_strb,
    output wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0]        out_tlp_hdr,
    output wire [TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]        out_tlp_seq,
    output wire [TLP_SEG_COUNT*3-1:0]                    out_tlp_bar_id,
    output wire [TLP_SEG_COUNT*8-1:0]                    out_tlp_func_num,
    output wire [TLP_SEG_COUNT*4-1:0]                    out_tlp_error,
    output wire [TLP_SEG_COUNT-1:0]                      out_tlp_valid,
    output wire [TLP_SEG_COUNT-1:0]                      out_tlp_sop,
    output wire [TLP_SEG_COUNT-1:0]                      out_tlp_eop,
    input  wire                                          out_tlp_ready,

    output reg  [PORTS*TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0]  sel_tlp_seq,
    output reg  [PORTS*TLP_SEG_COUNT-1:0]                sel_tlp_seq_valid
);

localparam CL_PORTS = PORTS <= 1 ? 1 : $clog2(PORTS);

initial begin
    if (PORTS < 1 || TLP_SEG_COUNT < 1) begin
        $error("Error: PORTS and TLP_SEG_COUNT must be positive (instance %m)");
        $finish;
    end
    if (TLP_STRB_WIDTH*32 != TLP_DATA_WIDTH ||
            TLP_DATA_WIDTH % TLP_SEG_COUNT != 0 ||
            (TLP_DATA_WIDTH/TLP_SEG_COUNT) % 32 != 0) begin
        $error("Error: each segment must contain an integral number of dwords (instance %m)");
        $finish;
    end
end

wire [PORTS-1:0] request;
genvar g;
generate
    for (g = 0; g < PORTS; g = g+1) begin : requests
        assign request[g] = |in_tlp_valid[g*TLP_SEG_COUNT +: TLP_SEG_COUNT];
    end
endgenerate

reg lock_reg = 0;
reg [CL_PORTS-1:0] lock_port_reg = 0;
reg [TLP_SEG_COUNT-1:0] active_reg = 0;
reg [CL_PORTS-1:0] rr_ptr_reg = ARB_LSB_HIGH_PRIORITY ? 0 : PORTS-1;

reg arb_valid;
reg [CL_PORTS-1:0] arb_port;
reg found;
integer offset;
integer index;

always @* begin
    arb_valid = lock_reg;
    arb_port = lock_port_reg;
    found = 0;
    index = 0;

    if (!lock_reg) begin
        for (offset = 0; offset < PORTS; offset = offset+1) begin
            if (ARB_TYPE_ROUND_ROBIN) begin
                if (ARB_LSB_HIGH_PRIORITY) begin
                    index = rr_ptr_reg+offset;
                    if (index >= PORTS) begin
                        index = index-PORTS;
                    end
                end else begin
                    index = rr_ptr_reg-offset;
                    if (index < 0) begin
                        index = index+PORTS;
                    end
                end
            end else begin
                index = ARB_LSB_HIGH_PRIORITY ? offset : PORTS-1-offset;
            end
            if (!found && request[index]) begin
                arb_valid = 1'b1;
                arb_port = index;
                found = 1'b1;
            end
        end
        if (!found) begin
            arb_valid = 1'b0;
            arb_port = 0;
        end
    end
end

wire [TLP_DATA_WIDTH-1:0] current_data = in_tlp_data[arb_port*TLP_DATA_WIDTH +: TLP_DATA_WIDTH];
wire [TLP_STRB_WIDTH-1:0] current_strb = in_tlp_strb[arb_port*TLP_STRB_WIDTH +: TLP_STRB_WIDTH];
wire [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0] current_hdr = in_tlp_hdr[arb_port*TLP_SEG_COUNT*TLP_HDR_WIDTH +: TLP_SEG_COUNT*TLP_HDR_WIDTH];
wire [TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0] current_seq = in_tlp_seq[arb_port*TLP_SEG_COUNT*SEQ_NUM_WIDTH +: TLP_SEG_COUNT*SEQ_NUM_WIDTH];
wire [TLP_SEG_COUNT*3-1:0] current_bar_id = in_tlp_bar_id[arb_port*TLP_SEG_COUNT*3 +: TLP_SEG_COUNT*3];
wire [TLP_SEG_COUNT*8-1:0] current_func_num = in_tlp_func_num[arb_port*TLP_SEG_COUNT*8 +: TLP_SEG_COUNT*8];
wire [TLP_SEG_COUNT*4-1:0] current_error = in_tlp_error[arb_port*TLP_SEG_COUNT*4 +: TLP_SEG_COUNT*4];
wire [TLP_SEG_COUNT-1:0] current_valid = in_tlp_valid[arb_port*TLP_SEG_COUNT +: TLP_SEG_COUNT];
wire [TLP_SEG_COUNT-1:0] current_sop = in_tlp_sop[arb_port*TLP_SEG_COUNT +: TLP_SEG_COUNT];
wire [TLP_SEG_COUNT-1:0] current_eop = in_tlp_eop[arb_port*TLP_SEG_COUNT +: TLP_SEG_COUNT];

reg [TLP_DATA_WIDTH-1:0] out_tlp_data_reg = 0;
reg [TLP_STRB_WIDTH-1:0] out_tlp_strb_reg = 0;
reg [TLP_SEG_COUNT*TLP_HDR_WIDTH-1:0] out_tlp_hdr_reg = 0;
reg [TLP_SEG_COUNT*SEQ_NUM_WIDTH-1:0] out_tlp_seq_reg = 0;
reg [TLP_SEG_COUNT*3-1:0] out_tlp_bar_id_reg = 0;
reg [TLP_SEG_COUNT*8-1:0] out_tlp_func_num_reg = 0;
reg [TLP_SEG_COUNT*4-1:0] out_tlp_error_reg = 0;
reg [TLP_SEG_COUNT-1:0] out_tlp_valid_reg = 0;
reg [TLP_SEG_COUNT-1:0] out_tlp_sop_reg = 0;
reg [TLP_SEG_COUNT-1:0] out_tlp_eop_reg = 0;
reg [CL_PORTS-1:0] out_port_reg = 0;

assign out_tlp_data = out_tlp_data_reg;
assign out_tlp_strb = out_tlp_strb_reg;
assign out_tlp_hdr = out_tlp_hdr_reg;
assign out_tlp_seq = out_tlp_seq_reg;
assign out_tlp_bar_id = out_tlp_bar_id_reg;
assign out_tlp_func_num = out_tlp_func_num_reg;
assign out_tlp_error = out_tlp_error_reg;
assign out_tlp_valid = out_tlp_valid_reg;
assign out_tlp_sop = out_tlp_sop_reg;
assign out_tlp_eop = out_tlp_eop_reg;

wire load_output = out_tlp_ready || out_tlp_valid_reg == 0;
wire accept_beat = load_output && arb_valid && current_valid != 0;

reg [TLP_SEG_COUNT-1:0] active_after;
integer i;
always @* begin
    in_tlp_ready = 0;
    if (!rst && load_output && arb_valid) begin
        in_tlp_ready[arb_port] = 1'b1;
    end

    active_after = lock_reg ? active_reg : 0;
    for (i = 0; i < TLP_SEG_COUNT; i = i+1) begin
        if (current_valid[i] && current_sop[i] && !current_eop[i]) begin
            active_after[i] = 1'b1;
        end else if (current_valid[i] && current_eop[i]) begin
            active_after[i] = 1'b0;
        end
    end

    sel_tlp_seq = 0;
    sel_tlp_seq_valid = 0;
    for (i = 0; i < PORTS; i = i+1) begin
        if (out_port_reg == i) begin
            sel_tlp_seq[i*TLP_SEG_COUNT*SEQ_NUM_WIDTH +: TLP_SEG_COUNT*SEQ_NUM_WIDTH] = out_tlp_seq_reg;
            if (out_tlp_ready) begin
                sel_tlp_seq_valid[i*TLP_SEG_COUNT +: TLP_SEG_COUNT] = out_tlp_valid_reg;
            end
        end
    end
end

always @(posedge clk) begin
    if (load_output) begin
        if (arb_valid) begin
            out_tlp_data_reg <= current_data;
            out_tlp_strb_reg <= current_strb;
            out_tlp_hdr_reg <= current_hdr;
            out_tlp_seq_reg <= current_seq;
            out_tlp_bar_id_reg <= current_bar_id;
            out_tlp_func_num_reg <= current_func_num;
            out_tlp_error_reg <= current_error;
            out_tlp_valid_reg <= current_valid;
            out_tlp_sop_reg <= current_sop;
            out_tlp_eop_reg <= current_eop;
            out_port_reg <= arb_port;
        end else begin
            out_tlp_valid_reg <= 0;
            out_tlp_sop_reg <= 0;
            out_tlp_eop_reg <= 0;
        end
    end

    if (accept_beat) begin
        active_reg <= active_after;
        if (active_after != 0) begin
            lock_reg <= 1'b1;
            lock_port_reg <= arb_port;
        end else begin
            lock_reg <= 1'b0;
            if (ARB_LSB_HIGH_PRIORITY) begin
                if (arb_port == PORTS-1) begin
                    rr_ptr_reg <= 0;
                end else begin
                    rr_ptr_reg <= arb_port+1'b1;
                end
            end else begin
                if (arb_port == 0) begin
                    rr_ptr_reg <= PORTS-1;
                end else begin
                    rr_ptr_reg <= arb_port-1'b1;
                end
            end
        end
    end

    if (rst) begin
        out_tlp_valid_reg <= 0;
        out_tlp_sop_reg <= 0;
        out_tlp_eop_reg <= 0;
        lock_reg <= 1'b0;
        lock_port_reg <= 0;
        active_reg <= 0;
        rr_ptr_reg <= ARB_LSB_HIGH_PRIORITY ? 0 : PORTS-1;
        out_port_reg <= 0;
    end
end

endmodule

`resetall
