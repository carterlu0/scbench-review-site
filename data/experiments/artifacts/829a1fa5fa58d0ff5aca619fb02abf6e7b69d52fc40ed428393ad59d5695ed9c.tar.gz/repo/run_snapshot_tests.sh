#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

python3 - <<'PY'
import json
from pathlib import Path
meta = json.loads(Path('SNAPSHOT.json').read_text())
print(f"commit={meta['commit']} role={meta['role']} env_group={meta['environment_group']}")
print("focused_tests=" + ",".join(meta['focused_tests']))
PY

python3 --version
tox --version | sed -n '1,1p'
iverilog -V | sed -n '1,1p'

mapfile -t tests < <(python3 - <<'PY'
import json
from pathlib import Path
for item in json.loads(Path('SNAPSHOT.json').read_text())['focused_tests']:
    print(item)
PY
)

if [[ "${#tests[@]}" -eq 0 ]]; then
  echo "No focused tests are defined for this baseline snapshot."
  exit 0
fi

tox -- --verbose "${tests[@]}"
