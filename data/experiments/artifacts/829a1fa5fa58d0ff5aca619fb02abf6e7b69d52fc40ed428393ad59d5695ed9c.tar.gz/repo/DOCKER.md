# 2022-06-13_pcie_tlp_baseline_2d48255p

Source commit: `056500dbf43af2c77a72580e1636e74ecbe0392e`

Subject: Avoid zero-width replication

Environment group: `a589ebb9c7e4`

Workflow runner: `ubuntu-20.04`

Workflow Python version: `3.9`

Docker image: `rtlbench-verilog-pcie-t3-offline-v1-056500d`

Base image: `ubuntu@sha256:8feb4d8ca5354def3d8fce243717141ce31e2c428701f6682bd2fafe15388214`

Resolved local base image ID: `sha256:b7bab04fd9aa0c771e5720bf0cc7cbf993fd6946645983d9096126e5af45d713`

Build:

```bash
docker build -t rtlbench-verilog-pcie-t3-offline-v1-056500d .
```

Run focused tests:

```bash
docker run --rm rtlbench-verilog-pcie-t3-offline-v1-056500d
```

Environment hashes:

- `tox.ini`: `353a3038f40a262786b81b1faf2bfd16a330e1ca6a95b284bb923d98bd279bee`
- `.github/workflows/regression-tests.yml`: `c768dda14d6829bad305a5be10c53adc72287d93dd57537f74abafb9cb9c72df`

Focused tests:

- baseline snapshot: no scored focused tests
